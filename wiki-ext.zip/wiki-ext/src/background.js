// Side panel "đi theo tab": chỉ hiện ở tab Confluence (citigo.atlassian.net), sang tab khác tự ẩn.
// Cơ chế: bật/tắt panel theo từng tabId qua chrome.sidePanel.setOptions dựa trên URL tab.
// (URL tab Confluence đọc được nhờ host_permissions; tab khác url rỗng → coi như không hợp lệ → tắt.)
const ALLOWED = /^https:\/\/citigo\.atlassian\.net\//;

// Mở Side Panel khi bấm icon extension (chỉ mở được ở tab đang bật panel).
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// Bật panel cho tab Confluence, tắt cho tab khác → Chrome tự ẩn panel khi tab active bị tắt.
async function syncPanel(tabId, url) {
  if (tabId == null) return;
  try {
    if (ALLOWED.test(url || "")) {
      await chrome.sidePanel.setOptions({
        tabId,
        path: "index.html",
        enabled: true,
      });
    } else {
      await chrome.sidePanel.setOptions({ tabId, enabled: false });
    }
  } catch (e) {
    /* tab đã đóng hoặc không truy cập được → bỏ qua */
  }
}

// Đổi tab đang xem → cập nhật panel theo URL tab đó.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    syncPanel(tabId, tab.url);
  } catch (e) {
    /* ignore */
  }
});

// Tab điều hướng/đổi URL (kể cả SPA) → cập nhật lại.
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.url || info.status === "complete") syncPanel(tabId, tab.url);
});
