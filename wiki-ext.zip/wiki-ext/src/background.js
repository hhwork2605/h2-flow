// Mở Side Panel (cửa sổ bên phải) khi bấm vào icon extension
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));
