import { useState, useEffect, useRef } from "react";
import {
  extractComponents,
  extractChecklistBelow,
  extractGoliveTags,
  manipulateGoliveTableDOM,
} from "./features/create/injected.js";
import { QUICK, isComplete, TABLE_LABEL } from "./features/create/config.js";
import {
  slugify,
  PROJECT_MAP,
  trimSlash,
  DEFAULT_JENKINS_CFG,
  isCfgReady,
  loadJenkinsCfg,
  saveJenkinsCfg,
  loadProjectMap,
  saveProjectMap,
  isBuildDisabled,
  fetchJobs,
  fetchProjectTags,
  jobApiUrl,
  tagJobUrl,
  buildJob,
  buildWithParameters,
  fetchStatusAt,
  fetchLastBuildByParams,
  pollBuild,
} from "./features/buildtag/jenkins.js";
import {
  buildJobWithApp,
  fetchLastBuildByApp,
} from "./features/buildtag/appname.js";
import { detectBuildType } from "./features/buildtag/buildtype.js";
import { fetchParamForm } from "./features/buildtag/params.js";
import { FETCH, TOAST_MS } from "./config.js";
import { SUPPORT_ACCOUNT } from "./features/support/config.js";
import {
  fetchNotShowBonusList,
  isBonusExcluded,
} from "./features/support/bonus.js";

/* ============================================================================
   useGolive — gom toàn bộ state + handler của panel vào một hook.
   GolivePanel gọi 1 lần rồi truyền object trả về xuống các feature view,
   tránh prop-drilling và tách render khỏi logic.
   ============================================================================ */

// Tìm phần tử trong `list` khớp với tag wiki — khoan dung khác biệt hoa/thường và tiền tố "v"
// (vd wiki "v2.144.2" ↔ Jenkins "2.144.2"). Trả về phần tử THẬT trong list (để build đúng tên),
// "" nếu không khớp. Tránh trượt auto-select chỉ vì lệch định dạng nhỏ.
const matchWikiTag = (wt, list) => {
  if (!Array.isArray(list) || !wt) return "";
  const w = String(wt).trim();
  if (list.includes(w)) return w; // khớp tuyệt đối trước
  const norm = (s) => String(s).trim().toLowerCase().replace(/^v/, "");
  const nw = norm(w);
  return list.find((t) => norm(t) === nw) || "";
};

export function useGolive() {
  const [components, setComponents] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState({}); // { [name]: true }
  const [expanded, setExpanded] = useState(new Set());
  const [query, setQuery] = useState("");
  const [step, setStep] = useState(1); // 1 | 2
  const [activeKey, setActiveKey] = useState("golive");
  const [updatingTarget, setUpdatingTarget] = useState(null);
  const [dragIndex, setDragIndex] = useState(null);
  const [overIndex, setOverIndex] = useState(null);
  const [checklistBelow, setChecklistBelow] = useState([]);
  const [isConfluenceTab, setIsConfluenceTab] = useState(true);
  const [confMode, setConfMode] = useState("view");
  const [toast, setToast] = useState(null);
  const [values, setValues] = useState({
    golive: {},
    rollback: {},
    checklist: {},
  });

  // ---- feature switching + Build tag ----
  const [feature, setFeature] = useState("create"); // "create" | "tag"
  const [showSupport, setShowSupport] = useState(false); // modal ủng hộ tác giả — bật sau khi check jsonbin (tránh nháy với user đã loại)
  const [buildStatus, setBuildStatus] = useState({}); // name -> idle|queued|building|success|failed
  const [buildUrl, setBuildUrl] = useState({}); // name -> URL build trên Jenkins
  const [buildingNames, setBuildingNames] = useState(() => new Set()); // component đang build (độc lập)
  const isBuilding = (nm) => buildingNames.has(nm);
  const anyBuilding = buildingNames.size > 0;
  const [jenkinsCfg, setJenkinsCfg] = useState(DEFAULT_JENKINS_CFG);
  const [showSettings, setShowSettings] = useState(false);
  const [projectMap, setProjectMap] = useState({}); // component -> job fullName (đã lưu)
  const [appMap, setAppMap] = useState({}); // component -> app đã chọn (job có APP_NAME)
  const [paramMap, setParamMap] = useState({}); // component -> { paramName: value } (job param)
  const [tagMap, setTagMap] = useState({}); // component -> tag đã chọn (đã lưu)
  const [jobs, setJobs] = useState([]); // danh sách job buildable lấy từ Jenkins
  const [jobsLoading, setJobsLoading] = useState(false);
  const [jobsError, setJobsError] = useState("");
  const [tagsByProject, setTagsByProject] = useState({}); // project -> [tag]
  const [jobMeta, setJobMeta] = useState({}); // job fullName -> { type, params, apps } (lazy)
  const [paramLoadingJobs, setParamLoadingJobs] = useState(new Set()); // job đang scrape choices
  const [wikiTags, setWikiTags] = useState({}); // component -> tag lấy từ bảng golive trên wiki
  const tagsLoadingRef = useRef(new Set());
  const jobMetaLoadingRef = useRef(new Set());
  const paramScrapeRef = useRef(new Set()); // job đã scrape form (tránh lặp)
  const statusKeyRef = useRef({}); // component -> chữ ký lựa chọn đã GET trạng thái (đổi → check lại)

  const setVal = (table, name, field, val) =>
    setValues((prev) => ({
      ...prev,
      [table]: {
        ...prev[table],
        [name]: { ...(prev[table][name] || {}), [field]: val },
      },
    }));
  const quickFill = (table, names) =>
    setValues((prev) => {
      const next = { ...prev[table] };
      names.forEach((nm) => {
        next[nm] = QUICK[table].apply(next[nm] || {});
      });
      return { ...prev, [table]: next };
    });
  // Áp dụng 1 giá trị field cho tất cả component đang chọn trong bảng
  const applyToAll = (table, field, value) =>
    setValues((prev) => {
      const next = { ...prev[table] };
      selectedNames.forEach((nm) => {
        next[nm] = { ...(next[nm] || {}), [field]: value };
      });
      return { ...prev, [table]: next };
    });

  const [retryAttempt, setRetryAttempt] = useState(0); // lần thử lại hiện tại (0 = không retry)

  const loadedPageIdRef = useRef(null);
  const isUpdatingRef = useRef(false);
  const toastTimer = useRef(null);
  const retryTimerRef = useRef(null);
  const retryCountRef = useRef(0);

  const MAX_RETRY = FETCH.MAX_RETRY;
  const RETRY_MS = FETCH.RETRY_MS;
  const cancelRetry = () => {
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  };

  const getPageId = (url) => {
    const m = (url || "").match(/\/pages\/(?:edit-v2\/)?(\d+)/);
    return m ? m[1] : null;
  };
  const modeOf = (url) =>
    /\/edit-v2\/|\/edit\//.test(url || "") ? "edit" : "view";

  const showToast = (t) => {
    setToast(t);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), TOAST_MS);
  };

  // Lên lịch thử lại (bảng Jira render chậm) — tối đa MAX_RETRY lần, cách RETRY_MS
  const scheduleRetry = (errMsg) => {
    cancelRetry();
    if (retryCountRef.current < MAX_RETRY) {
      retryCountRef.current += 1;
      setRetryAttempt(retryCountRef.current);
      setComponents([]);
      setSelected({});
      setError("");
      setLoading(true);
      retryTimerRef.current = setTimeout(() => handleGet(true), RETRY_MS);
    } else {
      setRetryAttempt(0);
      setLoading(false);
      setComponents([]);
      setSelected({});
      setError(
        errMsg || `Chưa lấy được component nào sau ${MAX_RETRY} lần thử.`,
      );
    }
  };

  const handleGet = async (isRetry = false) => {
    if (!isRetry) {
      retryCountRef.current = 0;
      cancelRetry();
      setRetryAttempt(0);
    }
    setLoading(true);
    setError("");
    setExpanded(new Set());

    let isConf = false;
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab || !tab.id) throw new Error("Không tìm thấy tab đang mở.");
      isConf = /^https:\/\/citigo\.atlassian\.net\//.test(tab.url || "");
      setIsConfluenceTab(isConf);
      setConfMode(modeOf(tab.url));
      if (!isConf) {
        loadedPageIdRef.current = null;
        cancelRetry();
        setRetryAttempt(0);
        setComponents([]);
        setSelected({});
        setError(
          "Hãy mở trang Confluence (citigo.atlassian.net) chứa bảng golive rồi thử lại.",
        );
        setLoading(false);
        return;
      }
      loadedPageIdRef.current = getPageId(tab.url);
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractComponents,
      });
      const data = (results && results[0] && results[0].result) || {};
      const comps = data.components || [];

      if (comps.length > 0) {
        cancelRetry();
        setRetryAttempt(0);
        setComponents(comps);
        // Đọc tag đang có trên bảng golive của wiki để auto-select sau khi load tag/choices.
        chrome.scripting
          .executeScript({ target: { tabId: tab.id }, func: extractGoliveTags })
          .then((r) => {
            const t = r && r[0] && r[0].result && r[0].result.tags;
            if (t) setWikiTags(t);
          })
          .catch(() => {});
        const all = {};
        comps.forEach((c) => (all[c.name] = true));
        setSelected(all);
        setStep(1);
        setLoading(false);
        showToast({
          type: "ok",
          t: `Đã lấy ${comps.length} components`,
          d: "Lấy từ bảng Danh sách ticket golive.",
        });
        return;
      }
      // Đang ở Confluence nhưng chưa có component (bảng có thể đang render) → thử lại
      scheduleRetry(data.error);
    } catch (e) {
      if (isConf) {
        scheduleRetry(e?.message);
      } else {
        cancelRetry();
        setRetryAttempt(0);
        setError(e?.message || "Có lỗi xảy ra khi lấy components.");
        setComponents([]);
        setSelected({});
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    handleGet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Đổi tab → reload theo pageId; tab không phải Confluence → báo
  useEffect(() => {
    const reloadIfPageChanged = async () => {
      if (isUpdatingRef.current) return;
      try {
        const [tab] = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        const url = (tab && tab.url) || "";
        const isConf = /^https:\/\/citigo\.atlassian\.net\//.test(url);
        setIsConfluenceTab(isConf);
        setConfMode(modeOf(url));
        if (!isConf) {
          loadedPageIdRef.current = null;
          cancelRetry();
          setRetryAttempt(0);
          setLoading(false);
          setComponents([]);
          setSelected({});
          setStep(1);
          setError(
            "Hãy chuyển sang tab https://citigo.atlassian.net/ để lấy components.",
          );
          return;
        }
        const pid = getPageId(url);
        if (pid !== loadedPageIdRef.current) {
          setStep(1);
          handleGet();
        }
      } catch (e) {
        /* ignore */
      }
    };
    const onActivated = () => reloadIfPageChanged();
    const onUpdated = (tabId, changeInfo, tab) => {
      if (
        tab &&
        tab.active &&
        (changeInfo.url || changeInfo.status === "complete")
      )
        reloadIfPageChanged();
    };
    chrome.tabs.onActivated.addListener(onActivated);
    chrome.tabs.onUpdated.addListener(onUpdated);
    return () => {
      chrome.tabs.onActivated.removeListener(onActivated);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      cancelRetry();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleSelect = (name) =>
    setSelected((p) => ({ ...p, [name]: !p[name] }));
  const toggleExpand = (name) =>
    setExpanded((s) => {
      const n = new Set(s);
      n.has(name) ? n.delete(name) : n.add(name);
      return n;
    });
  const handleRemove = (name) => {
    setComponents((p) => p.filter((c) => c.name !== name));
    setSelected((p) => {
      const n = { ...p };
      delete n[name];
      return n;
    });
    setExpanded((s) => {
      const n = new Set(s);
      n.delete(name);
      return n;
    });
  };

  // drag reorder
  const handleDragStart = (i) => (e) => {
    setDragIndex(i);
    setExpanded(new Set());
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragOver = (i) => (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (i !== overIndex) setOverIndex(i);
  };
  const handleDrop = (i) => (e) => {
    e.preventDefault();
    if (dragIndex !== null && dragIndex !== i) {
      setComponents((prev) => {
        const arr = [...prev];
        const [moved] = arr.splice(dragIndex, 1);
        arr.splice(i, 0, moved);
        return arr;
      });
    }
    setDragIndex(null);
    setOverIndex(null);
  };
  const handleDragEnd = () => {
    setDragIndex(null);
    setOverIndex(null);
  };

  const selectedList = components.filter((c) => selected[c.name]);
  const selectedNames = selectedList.map((c) => c.name);
  const selCount = selectedNames.length;
  const allSel = selCount === components.length && components.length > 0;
  const someSel = selCount > 0 && !allSel;

  const selectAll = () => {
    const n = {};
    components.forEach((c) => (n[c.name] = true));
    setSelected(n);
  };
  const deselectAll = () => setSelected({});

  const fetchChecklistBelow = async () => {
    setChecklistBelow([]);
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractChecklistBelow,
      });
      const data = results[0].result;
      setChecklistBelow(data && data.below ? data.below : []);
    } catch (e) {
      setChecklistBelow([]);
    }
  };

  const goStep2 = () => {
    setStep(2);
    document.querySelector(".g-body")?.scrollTo(0, 0);
    if (activeKey === "checklist") fetchChecklistBelow();
  };
  const setActive = (key) => {
    setActiveKey(key);
    if (key === "checklist") fetchChecklistBelow();
  };

  const handleUpdateTable = async (target) => {
    setUpdatingTarget(target);
    setError("");
    isUpdatingRef.current = true;
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      const url = tab && tab.url ? tab.url : "";
      if (!url.includes("/edit-v2/") && !url.includes("/edit/")) {
        const pageIdMatch = url.match(/\/pages\/(\d+)/);
        if (!pageIdMatch)
          throw new Error(
            "Không tìm thấy Page ID! Hãy mở trang Confluence trước.",
          );
        const pageId = pageIdMatch[1];
        const spaceMatch = url.match(/\/spaces\/([^/]+)/);
        const space = spaceMatch ? spaceMatch[1] : "";
        const editUrl = `https://citigo.atlassian.net/wiki/spaces/${space}/pages/edit-v2/${pageId}`;
        await chrome.tabs.update(tab.id, { url: editUrl });
        await new Promise((res) => setTimeout(res, FETCH.EDIT_MODE_WAIT_MS));
      }
      const [updatedTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      // Ghép giá trị đã nhập theo từng component thành rows để chèn
      const rows = selectedNames.map((nm) => ({
        name: nm,
        ...(values[target][nm] || {}),
      }));
      const results = await chrome.scripting.executeScript({
        target: { tabId: updatedTab.id },
        func: manipulateGoliveTableDOM,
        args: [rows, target],
      });
      const data = results[0].result;
      if (data.error) throw new Error(data.error);
      setConfMode("edit");
      showToast({
        type: "ok",
        t: `Đã cập nhật ${TABLE_LABEL[target]}`,
        d: `${data.count} dòng · trang đã chuyển sang Edit. Nhớ bấm Publish.`,
      });
    } catch (e) {
      showToast({
        type: "err",
        t: "Không cập nhật được",
        d: e?.message || "Có lỗi xảy ra.",
      });
    } finally {
      setUpdatingTarget(null);
      isUpdatingRef.current = false;
    }
  };

  // ---- Build tag (Jenkins API) ----
  // Project (job multibranch) hiệu lực: ưu tiên lựa chọn đã lưu, không có thì gợi ý mặc định.
  const resolveProject = (nm) =>
    (projectMap[nm] || "").trim() || PROJECT_MAP[nm] || slugify(nm);
  // Đã chọn project (job) hay chưa — chỉ tính lựa chọn thật của người dùng, không tính fallback.
  const hasProject = (nm) => !!(projectMap[nm] || "").trim();
  // App hiệu lực (job có bước APP_NAME). Rỗng = không có/chưa chọn.
  const resolveApp = (nm) => (appMap[nm] || "").trim();
  // Tag hiệu lực: tag đã chọn, không có thì lấy tag mới nhất của project.
  const tagsOf = (nm) => tagsByProject[resolveProject(nm)] || [];
  const resolveTag = (nm) => (tagMap[nm] || "").trim() || tagsOf(nm)[0] || "";

  // Meta nhận diện của job đang resolve cho component (type/params/apps).
  const metaOf = (nm) => jobMeta[resolveProject(nm)] || null;
  const typeOf = (nm) => metaOf(nm)?.type || "tag"; // chưa nhận diện xong → coi như tag
  const paramsOf = (nm) => metaOf(nm)?.params || [];
  const appsOf = (nm) => metaOf(nm)?.apps || [];

  // Chuỗi hiển thị ở ô Project: "job" hoặc "job/app" (gộp app vào job).
  const projectDisplay = (nm) => {
    const p = (projectMap[nm] || "").trim();
    if (!p) return "";
    const a = (appMap[nm] || "").trim();
    return a ? p + "/" + a : p;
  };
  // Tách ngược chuỗi nhập/chọn thành { project, app } dựa trên app đã biết (jobMeta).
  const splitProjectApp = (val) => {
    const v = (val || "").trim();
    if (!v) return { project: "", app: "" };
    for (const job of Object.keys(jobMeta)) {
      const apps = jobMeta[job]?.apps;
      if (!Array.isArray(apps)) continue;
      for (const a of apps)
        if (v === job + "/" + a) return { project: job, app: a };
    }
    return { project: v, app: "" };
  };

  // Nhận diện loại build của 1 job (lazy, cache, tránh gọi trùng).
  const ensureJobMeta = async (job) => {
    if (
      !job ||
      jobMeta[job] !== undefined ||
      jobMetaLoadingRef.current.has(job) ||
      !isCfgReady(jenkinsCfg)
    )
      return;
    jobMetaLoadingRef.current.add(job);
    try {
      const meta = await detectBuildType(jenkinsCfg, job);
      setJobMeta((p) => ({ ...p, [job]: meta }));
    } catch {
      setJobMeta((p) => ({
        ...p,
        [job]: { type: "plain", params: [], apps: [] },
      }));
    } finally {
      jobMetaLoadingRef.current.delete(job);
    }
  };

  // Lấy danh sách choices của job param bằng cách mở form trong tab ẩn (chỉ khi cần).
  // Gọi khi người dùng mở form tham số; merge choices/defs vào jobMeta.
  const loadParamChoices = async (nm) => {
    const job = resolveProject(nm);
    const meta = jobMeta[job];
    if (!job || !meta || meta.type !== "param" || !isCfgReady(jenkinsCfg))
      return;
    const needs = meta.params.some(
      (p) =>
        (p.kind === "choice" || p.kind === "multiselect") &&
        !(p.choices && p.choices.length),
    );
    if (!needs || paramScrapeRef.current.has(job)) return;
    paramScrapeRef.current.add(job);
    setParamLoadingJobs((s) => new Set(s).add(job));
    try {
      const form = await fetchParamForm(jenkinsCfg, job);
      if (form.length) {
        const byName = {};
        form.forEach((f) => {
          byName[f.name] = f;
        });
        setJobMeta((prev) => {
          const m = prev[job];
          if (!m) return prev;
          const params = m.params.map((p) => {
            const f = byName[p.name];
            if (f && f.choices && f.choices.length) {
              return {
                ...p,
                kind: f.kind,
                choices: f.choices,
                defs: p.defs && p.defs.length ? p.defs : f.defs,
                def: p.def || f.def,
              };
            }
            return p;
          });
          return { ...prev, [job]: { ...m, params } };
        });
      }
    } finally {
      setParamLoadingJobs((s) => {
        const n = new Set(s);
        n.delete(job);
        return n;
      });
    }
  };
  const isParamLoading = (nm) => paramLoadingJobs.has(resolveProject(nm));

  // Ô Project nhận chuỗi "job" hoặc "job/app" → lưu tách projectMap + appMap.
  const handleProjectInput = (nm, val) => {
    const { project, app } = splitProjectApp(val);
    const projectChanged = project !== (projectMap[nm] || "");
    setProjectMap((prev) => {
      const next = { ...prev };
      if (project) next[nm] = project;
      else delete next[nm];
      saveProjectMap(next);
      return next;
    });
    setAppMap((prev) => {
      const next = { ...prev };
      if (app) next[nm] = app;
      else delete next[nm];
      return next;
    });
    if (projectChanged) {
      setTagMap((prev) => {
        // đổi project → bỏ tag cũ
        if (!prev[nm]) return prev;
        const next = { ...prev };
        delete next[nm];
        return next;
      });
      setParamMap((prev) => {
        // đổi project → bỏ tham số cũ
        if (!prev[nm]) return prev;
        const next = { ...prev };
        delete next[nm];
        return next;
      });
    }
    if (project) ensureJobMeta(project);
  };
  const handleTagChange = (nm, val) => {
    setTagMap((prev) => {
      const next = { ...prev };
      if (val.trim()) next[nm] = val;
      else delete next[nm];
      return next;
    });
  };

  // Giá trị 1 tham số của component (đã chọn hoặc default theo jobMeta + kiểu).
  const paramVal = (nm, p) => {
    const saved = paramMap[nm] && paramMap[nm][p.name];
    if (saved !== undefined) return saved;
    if (p.kind === "multiselect") return p.defs || [];
    if (p.kind === "boolean") return p.def === true || p.def === "true";
    if (p.kind === "choice") return p.def || (p.choices && p.choices[0]) || "";
    return p.def ?? "";
  };
  const setParam = (nm, name, val) =>
    setParamMap((prev) => ({
      ...prev,
      [nm]: { ...(prev[nm] || {}), [name]: val },
    }));
  // Gom giá trị tham số để gửi build. Mảng (multiselect) GIỮ NGUYÊN → buildWithParameters
  // lặp key (Run_Steps=Build&Run_Steps=Deploy); boolean → "true"/"false".
  const paramValues = (nm) => {
    const out = {};
    paramsOf(nm).forEach((p) => {
      if (p.kind === "file") return; // upload file không gửi được qua URL params
      let v = paramVal(nm, p);
      if (typeof v === "boolean") v = v ? "true" : "false";
      out[p.name] = v; // mảng để nguyên
    });
    return out;
  };

  // Lấy danh sách job buildable từ Jenkins (cho ô chọn project).
  const refetchJobs = async (cfg = jenkinsCfg) => {
    if (!isCfgReady(cfg)) {
      setJobs([]);
      setJobsError("");
      return;
    }
    setJobsLoading(true);
    setJobsError("");
    try {
      setJobs(await fetchJobs(cfg));
    } catch (e) {
      setJobs([]);
      setJobsError(e?.message || "Không tải được danh sách job.");
      if (e?.unauthorized) setShowSettings(true); // 401/403 → mở settings để nhập lại user/token
    } finally {
      setJobsLoading(false);
    }
  };

  // Nút reload góc phải: làm mới TOÀN BỘ như lần đầu vào Build tag — xoá cache (tag/loại build/
  // trạng thái) + lựa chọn phiên (tag/app/param/wiki), rồi tải lại danh sách job và lấy lại
  // components (kéo theo prefetch tag, nhận diện loại, auto-select, GET trạng thái chạy lại).
  const reloadAll = () => {
    statusKeyRef.current = {};
    tagsLoadingRef.current = new Set();
    jobMetaLoadingRef.current = new Set();
    paramScrapeRef.current = new Set();
    setTagsByProject({});
    setJobMeta({});
    setBuildStatus({});
    setBuildUrl({});
    setTagMap({});
    setAppMap({});
    setParamMap({});
    setWikiTags({});
    refetchJobs();
    handleGet();
  };

  // Nút reload phần Tạo component: làm mới như lần đầu vào — xoá dữ liệu đã điền (golive/rollback/
  // checklist) + ô tìm kiếm, rồi lấy lại components (handleGet đặt lại selected/step/expanded).
  const reloadCreate = () => {
    setValues({ golive: {}, rollback: {}, checklist: {} });
    setQuery("");
    handleGet();
  };

  // Tải tag của 1 project (cache, tránh gọi trùng).
  const ensureTags = async (project) => {
    if (
      !project ||
      tagsByProject[project] ||
      tagsLoadingRef.current.has(project) ||
      !isCfgReady(jenkinsCfg)
    )
      return;
    tagsLoadingRef.current.add(project);
    try {
      const tags = await fetchProjectTags(jenkinsCfg, project);
      setTagsByProject((p) => ({ ...p, [project]: tags }));
    } catch {
      setTagsByProject((p) => ({ ...p, [project]: [] }));
    } finally {
      tagsLoadingRef.current.delete(project);
    }
  };

  useEffect(() => {
    loadProjectMap().then(setProjectMap);
    // appMap, tagMap & paramMap KHÔNG load từ storage — để trống, chọn lại mỗi lần vào.
    loadJenkinsCfg().then((cfg) => {
      setJenkinsCfg(cfg);
      refetchJobs(cfg);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Vào Build tag mà chưa cấu hình Jenkins (thiếu URL/user/token) → tự mở settings để nhập.
  useEffect(() => {
    if (feature === "tag" && !isCfgReady(jenkinsCfg)) setShowSettings(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feature, jenkinsCfg]);

  // Khi vào Build tag và đã có cấu hình → tải tag cho các project đang dùng.
  useEffect(() => {
    if (feature !== "tag" || !isCfgReady(jenkinsCfg)) return;
    // Chỉ prefetch cho job ĐÃ chọn thật — tránh gọi vào tên đoán mặc định (404 rác).
    const projects = new Set(
      components
        .filter((c) => hasProject(c.name))
        .map((c) => resolveProject(c.name)),
    );
    projects.forEach((p) => {
      ensureTags(p);
      ensureJobMeta(p);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feature, components, projectMap, jenkinsCfg, jobs]);

  // URL job để GET trạng thái build gần nhất theo loại: tag/app dùng job-tag, param/plain dùng job gốc.
  const statusUrlOf = (nm) => {
    const project = resolveProject(nm);
    if (!project) return "";
    const type = typeOf(nm);
    if (type === "tag" || type === "app") {
      const tag = resolveTag(nm);
      return tag ? tagJobUrl(jenkinsCfg, project, tag) : "";
    }
    return jobApiUrl(jenkinsCfg, project);
  };

  // GET trạng thái build gần nhất của từng dòng để hiển thị sẵn (trước khi bấm Build).
  useEffect(() => {
    if (feature !== "tag" || !isCfgReady(jenkinsCfg) || anyBuilding) return;
    components.forEach((c) => {
      const nm = c.name;
      if (!hasProject(nm)) return; // chưa chọn job → không GET (tránh 404 vào tên đoán)
      // Nguồn trạng thái theo loại: app → quét consoleText tìm build đúng app; param → tìm last
      // build khớp tham số; tag/plain → lastBuild của job. Chữ ký (sig) để bỏ qua fetch khi không đổi.
      const type = typeOf(nm);
      let req, sig;
      if (type === "app") {
        const tag = resolveTag(nm),
          app = resolveApp(nm);
        if (!tag || !app) return; // thiếu tag/app → không suy ra được
        sig = "app::" + resolveProject(nm) + "::" + tag + "::" + app;
        req = fetchLastBuildByApp(jenkinsCfg, resolveProject(nm), tag, app);
      } else if (type === "param") {
        const vals = paramValues(nm);
        sig = "param::" + resolveProject(nm) + "::" + JSON.stringify(vals);
        req = fetchLastBuildByParams(jenkinsCfg, resolveProject(nm), vals);
      } else {
        const url = statusUrlOf(nm); // tag → job-tag, plain → job gốc
        if (!url) return;
        sig = "ls::" + url;
        req = fetchStatusAt(jenkinsCfg, url);
      }
      if (statusKeyRef.current[nm] === sig) return;
      statusKeyRef.current[nm] = sig;
      req
        .then((s) => {
          // Lựa chọn (tag/app/tham số) đã đổi giữa chừng → bỏ kết quả cũ, tránh request đến
          // sau ghi đè trạng thái đúng (vd fetch tag sai 404 về sau fetch tag đúng → "chưa build" giả).
          if (statusKeyRef.current[nm] !== sig) return;
          setBuildStatus((p) =>
            p[nm] === "queued" || p[nm] === "building"
              ? p
              : { ...p, [nm]: s.status },
          );
          if (s.url) setBuildUrl((p) => ({ ...p, [nm]: s.url }));
          // Job đang chạy sẵn lúc mở panel → bám theo tới khi xong (không thì kẹt ở "Đang build").
          if (s.status === "building" && s.url) {
            pollBuild(jenkinsCfg, s.url)
              .then((r) => {
                if (statusKeyRef.current[nm] !== sig) return;
                setBuildStatus((p) => ({
                  ...p,
                  [nm]: /SUCCESS/i.test(r.result || "") ? "success" : "failed",
                }));
              })
              .catch(() => {});
          }
        })
        .catch(() => {});
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    feature,
    components,
    projectMap,
    tagMap,
    appMap,
    paramMap,
    tagsByProject,
    jobMeta,
    jenkinsCfg,
  ]);

  // Auto-select TAG theo wiki: khi tag của project đã tải, nếu tag wiki có trong danh sách
  // và component chưa chọn tag → chọn luôn. Không có trong list → để trống (không ép).
  useEffect(() => {
    if (feature !== "tag") return;
    components.forEach((c) => {
      const nm = c.name;
      const wt = (wikiTags[nm] || "").trim();
      if (!wt || (tagMap[nm] || "").trim()) return;
      const hit = matchWikiTag(wt, tagsByProject[resolveProject(nm)]);
      if (hit) {
        setTagMap((prev) => {
          if ((prev[nm] || "").trim()) return prev;
          return { ...prev, [nm]: hit };
        });
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feature, components, wikiTags, tagsByProject, projectMap]);

  // Auto-select tham số dạng version (vd Tag_Version) theo wiki: nếu choices chứa tag wiki
  // và chưa chọn → chọn luôn. Không có → để mặc định (không ép).
  useEffect(() => {
    if (feature !== "tag") return;
    components.forEach((c) => {
      const nm = c.name;
      const wt = (wikiTags[nm] || "").trim();
      if (!wt) return;
      const meta = jobMeta[resolveProject(nm)];
      if (!meta || meta.type !== "param") return;
      meta.params.forEach((p) => {
        if (p.kind !== "choice" || !/version|tag/i.test(p.name)) return;
        const hit = matchWikiTag(wt, p.choices);
        if (!hit) return;
        const cur = paramMap[nm] && paramMap[nm][p.name];
        if (cur !== undefined && cur !== "") return; // đã chọn (kể cả người dùng) → giữ nguyên
        setParam(nm, p.name, hit);
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feature, components, wikiTags, jobMeta, projectMap]);

  const handleSaveCfg = async (cfg) => {
    await saveJenkinsCfg(cfg);
    setJenkinsCfg(cfg);
    setTagsByProject({}); // đổi cấu hình → tải lại tag
    showToast({ type: "ok", t: "Đã lưu cấu hình Jenkins", d: cfg.baseUrl });
    refetchJobs(cfg);
  };

  // Sao chép số tài khoản ủng hộ + toast cảm ơn, rồi đóng modal.
  const copyAccount = () => {
    try {
      navigator.clipboard &&
        navigator.clipboard.writeText(SUPPORT_ACCOUNT.number);
    } catch (e) {
      /* ignore */
    }
    showToast({
      type: "ok",
      t: "Đã sao chép số tài khoản",
      d: "Cảm ơn bạn đã ủng hộ! ❤️",
    });
    setShowSupport(false);
  };

  // Khi mở extension: hỏi jsonbin danh sách notShowBonusPopup. User (username Jenkins
  // trong config) nằm trong đó → không hiện. Lỗi/chưa cấu hình bin → hiện (mặc định).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [cfg, list] = await Promise.all([
          loadJenkinsCfg(),
          fetchNotShowBonusList(),
        ]);
        if (cancelled) return;
        if (!isBonusExcluded(list, cfg.user)) setShowSupport(true);
      } catch {
        if (!cancelled) setShowSupport(true);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openJenkins = () => {
    const url = trimSlash(jenkinsCfg.baseUrl);
    if (url) chrome.tabs.create({ url });
    else {
      setShowSettings(true);
    }
  };

  // Trigger build theo loại đã nhận diện rồi poll tới khi xong.
  const triggerAndPoll = async (nm, project, tag) => {
    const onPhase = (phase, url) => {
      setBuildStatus((p) => ({ ...p, [nm]: phase }));
      if (url) setBuildUrl((p) => ({ ...p, [nm]: url }));
    };
    const type = typeOf(nm);
    let r;
    if (type === "param")
      r = await buildWithParameters(
        jenkinsCfg,
        project,
        paramValues(nm),
        onPhase,
      );
    else if (type === "app")
      r = await buildJobWithApp(
        jenkinsCfg,
        project,
        tag,
        resolveApp(nm),
        onPhase,
      );
    else
      r = await buildJob(
        jenkinsCfg,
        project,
        type === "tag" ? tag : "",
        onPhase,
      ); // tag | plain
    const ok = /SUCCESS/i.test(r.result || "");
    setBuildStatus((p) => ({ ...p, [nm]: ok ? "success" : "failed" }));
    if (r.buildUrl) setBuildUrl((p) => ({ ...p, [nm]: r.buildUrl }));
    return ok;
  };

  // Build 1 dòng. force=false: GET kết quả trước cho MỌI loại (đã build thành công/thất bại thì
  // báo luôn, đang build thì bám theo) → tránh build lại bản đã thành công. force=true (Retry):
  // build lại bất kể. Trả về { ok, already }.
  const runOne = async (nm, force) => {
    const project = resolveProject(nm);
    const type = typeOf(nm);
    const needTag = type === "tag" || type === "app";
    const tag = resolveTag(nm);
    if (!project || (needTag && !tag)) {
      setBuildStatus((p) => ({ ...p, [nm]: "idle" }));
      return { ok: false, already: false };
    }
    setBuildingNames((s) => new Set(s).add(nm)); // đánh dấu dòng này đang build (độc lập với dòng khác)
    try {
      // Pre-check "đã build chưa" cho mọi loại (trừ khi force/Retry). Nguồn trạng thái theo loại:
      //   app   → quét consoleText tìm build đúng app (app submit qua input step, không phải parameter).
      //   param → tìm last build khớp đúng tham số (Jenkins lưu tham số trong build).
      //   tag/plain → lastBuild của job (định danh đúng job).
      if (!force) {
        setBuildStatus((p) => ({ ...p, [nm]: "queued" }));
        let cur = null;
        if (type === "app") {
          cur = await fetchLastBuildByApp(
            jenkinsCfg,
            project,
            tag,
            resolveApp(nm),
          );
        } else if (type === "param") {
          cur = await fetchLastBuildByParams(
            jenkinsCfg,
            project,
            paramValues(nm),
          );
        } else {
          const url = statusUrlOf(nm); // tag → job-tag, plain → job gốc
          if (url) cur = await fetchStatusAt(jenkinsCfg, url);
        }
        if (cur && cur.url) setBuildUrl((p) => ({ ...p, [nm]: cur.url }));
        if (cur && (cur.status === "success" || cur.status === "failed")) {
          setBuildStatus((p) => ({ ...p, [nm]: cur.status }));
          return { ok: cur.status === "success", already: true };
        }
        if (cur && cur.status === "building") {
          setBuildStatus((p) => ({ ...p, [nm]: "building" }));
          const r = await pollBuild(jenkinsCfg, cur.url);
          const ok = /SUCCESS/i.test(r.result || "");
          setBuildStatus((p) => ({ ...p, [nm]: ok ? "success" : "failed" }));
          return { ok, already: true };
        }
      }
      setBuildStatus((p) => ({ ...p, [nm]: "queued" }));
      const ok = await triggerAndPoll(nm, project, tag);
      return { ok, already: false };
    } catch (e) {
      setBuildStatus((p) => ({ ...p, [nm]: "failed" }));
      return { ok: false, already: false };
    } finally {
      setBuildingNames((s) => {
        const n = new Set(s);
        n.delete(nm);
        return n;
      });
    }
  };

  // Build tất cả tag đã chọn (kiểm tra trước khi build).
  const runBuilds = async () => {
    const all = selectedNames.filter((nm) => !isBuildDisabled(nm)); // bỏ component chỉ-hiển-thị
    if (!all.length) return;
    if (!isCfgReady(jenkinsCfg)) {
      setShowSettings(true);
      showToast({
        type: "err",
        t: "Chưa cấu hình Jenkins",
        d: "Nhập URL, Username và API Token để build.",
      });
      return;
    }
    // Bỏ qua: chưa chọn project (job) HOẶC đang build/đang trong hàng chờ.
    const inProgress = (nm) =>
      isBuilding(nm) ||
      buildStatus[nm] === "queued" ||
      buildStatus[nm] === "building";
    const skipped = all.filter((nm) => !hasProject(nm));
    const targets = all.filter((nm) => hasProject(nm) && !inProgress(nm));
    if (!targets.length) {
      showToast({
        type: "err",
        t: "Không có dòng nào để build",
        d: "Tất cả đã chọn đang build/trong hàng chờ, hoặc chưa chọn project.",
      });
      return;
    }
    const needsTag = (nm) => {
      const t = typeOf(nm);
      return t === "tag" || t === "app";
    };
    const missing = targets.filter((nm) => needsTag(nm) && !resolveTag(nm));
    if (missing.length) {
      showToast({
        type: "err",
        t: "Thiếu tag",
        d: `Chọn tag cho: ${missing.join(", ")}`,
      });
      return;
    }
    const results = await Promise.all(targets.map((nm) => runOne(nm, false)));

    const totalN = results.length;
    const failed = results.filter((r) => !r.ok).length;
    const already = results.filter((r) => r.already).length;
    const skipNote = skipped.length
      ? ` · bỏ qua ${skipped.length} chưa chọn project`
      : "";
    const detail = (already ? ` (${already} đã build sẵn)` : "") + skipNote;
    showToast(
      failed
        ? {
            type: "err",
            t: `Xong: ${totalN - failed} thành công, ${failed} thất bại${detail}`,
            d: "Bấm Retry ở dòng lỗi để build lại.",
          }
        : {
            type: "ok",
            t: `${totalN} tag thành công${detail}`,
            d: "Tất cả tag đã có kết quả thành công.",
          },
    );
  };

  // Retry 1 tag: build lại bất kể đã build hay chưa.
  const retryOne = async (nm) => {
    if (!isCfgReady(jenkinsCfg)) {
      setShowSettings(true);
      return;
    }
    if (!hasProject(nm)) {
      showToast({
        type: "err",
        t: "Chưa chọn project",
        d: `Chọn job Jenkins cho ${nm}`,
      });
      return;
    }
    const t = typeOf(nm);
    if ((t === "tag" || t === "app") && !resolveTag(nm)) {
      showToast({ type: "err", t: "Thiếu tag", d: `Chọn tag cho ${nm}` });
      return;
    }
    const r = await runOne(nm, true);
    showToast(
      r.ok
        ? {
            type: "ok",
            t: `Build lại ${nm} thành công`,
            d: resolveProject(nm) + "/" + resolveTag(nm),
          }
        : {
            type: "err",
            t: `Build lại ${nm} thất bại`,
            d: "Xem log trên Jenkins.",
          },
    );
  };

  const ready = components.length > 0;
  const allNames = components.map((c) => c.name);
  const filtered = components.filter((c) =>
    c.name.toLowerCase().includes(query.trim().toLowerCase()),
  );
  const completed = selectedNames.filter((nm) =>
    isComplete(activeKey, values[activeKey][nm]),
  ).length;
  const pct = selCount ? Math.round((completed / selCount) * 100) : 0;

  return {
    // feature / chrome
    feature,
    setFeature,
    showSupport,
    setShowSupport,
    copyAccount,
    isConfluenceTab,
    confMode,
    // fetch state
    loading,
    error,
    ready,
    retryAttempt,
    MAX_RETRY,
    handleGet,
    reloadCreate,
    // step 1 — components
    components,
    query,
    setQuery,
    filtered,
    expanded,
    toggleExpand,
    toggleSelect,
    handleRemove,
    selected,
    selCount,
    allSel,
    someSel,
    selectAll,
    deselectAll,
    dragIndex,
    overIndex,
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    // step 2 — tables
    step,
    setStep,
    activeKey,
    setActive,
    goStep2,
    values,
    setVal,
    applyToAll,
    quickFill,
    selectedList,
    selectedNames,
    checklistBelow,
    completed,
    pct,
    updatingTarget,
    handleUpdateTable,
    // build tag
    allNames,
    buildStatus,
    buildUrl,
    building: anyBuilding,
    isBuilding,
    projectMap,
    appMap,
    projectDisplay,
    handleProjectInput,
    tagMap,
    handleTagChange,
    tagsByProject,
    jobMeta,
    resolveProject,
    typeOf,
    paramsOf,
    paramVal,
    setParam,
    loadParamChoices,
    isParamLoading,
    jobs,
    jobsLoading,
    jobsError,
    refetchJobs,
    reloadAll,
    runBuilds,
    retryOne,
    openJenkins,
    // jenkins settings + toast
    jenkinsCfg,
    showSettings,
    setShowSettings,
    handleSaveCfg,
    toast,
    setToast,
  };
}
