/* ============================================================================
   CONFIG TẬP TRUNG — đổi số/giá trị ở đây để tinh chỉnh hành vi (không cần sửa logic).
   Lưu ý: hàm trong features/create/injected.js chạy ở context trang web (serialize bằng
   .toString()) nên KHÔNG import được — vài số timeout/scroll trong đó phải sửa trực tiếp.
   ============================================================================ */

/* ---- Jenkins ----------------------------------------------------------- */
// Cấu hình mặc định khi chưa lưu (URL có thể đổi; user/token nhập trong modal ⚙).
export const DEFAULT_JENKINS_CFG = {
  baseUrl: "https://booking-jenkins-hub.citigo.net",
  user: "",
  token: "",
  folders: [], // folder được chọn để quét job (rỗng = quét tất cả job có quyền)
};

/* ---- Poll theo dõi build (ms = mili-giây) ------------------------------ */
export const POLL = {
  BUILD_INTERVAL_MS: 15000, // pollBuild: chu kỳ hỏi trạng thái 1 build đang chạy
  BUILD_MAX_TRIES: 600, // pollBuild: số lần tối đa (600 × 3s ≈ 30 phút) → quá thì báo timeout
  QUEUE_INTERVAL_MS: 2000, // triggerBuild: chu kỳ hỏi hàng đợi (queue) → URL build
  QUEUE_MAX_TRIES: 40, // (40 × 2s ≈ 80s)
  NEWBUILD_INTERVAL_MS: 2000, // triggerBuild: chu kỳ dò build MỚI qua lastBuild (khi không có Location)
  NEWBUILD_MAX_TRIES: 45, // (45 × 2s ≈ 90s)
  APPINPUT_INTERVAL_MS: 3000, // buildJobWithApp: chu kỳ chờ pipeline pause ở bước "Choose APP_NAME"
  APPINPUT_MAX_TRIES: 80, // (80 × 3s ≈ 4 phút)
};

/* ---- Lấy danh sách job (fetchJobs) ------------------------------------- */
export const JOBS = {
  MAX_DEPTH: 4, // độ sâu đệ quy folder Jenkins
  EXCLUDE: [/hotel-locale/i, /booking-autotags/i], // job/folder chứa các pattern này bị loại
};

/* ---- Build tag --------------------------------------------------------- */
// Số build gần nhất quét khi tìm "last build khớp tham số" của job param (fetchLastBuildByParams).
// Build cũ hơn ngưỡng này (hoặc đã bị Jenkins xoá theo retention) sẽ không tìm thấy → build lại.
export const PARAM_MATCH_MAX = 40;

// Số build gần nhất quét khi tìm "last build đúng app" của job app (fetchLastBuildByApp) — mỗi
// build phải tải consoleText để dò app nên đặt nhỏ hơn param cho nhẹ.
export const APP_MATCH_MAX = 20;

// Component CHỈ HIỂN THỊ trong Build tag (không cho thao tác/không build — build tay nơi khác).
export const BUILD_DISABLED = [
  "Database",
  "Booking Core",
  "booking mobile core",
];

/* ---- Lấy components từ Confluence (useGolive) -------------------------- */
export const FETCH = {
  MAX_RETRY: 5, // số lần thử lại khi bảng Jira/Confluence render chậm
  RETRY_MS: 5000, // khoảng cách giữa các lần thử lại
  EDIT_MODE_WAIT_MS: 5000, // chờ trang chuyển sang chế độ Edit trước khi ghi bảng golive
};

/* ---- UI ---------------------------------------------------------------- */
export const TOAST_MS = 3600; // thời gian hiển thị toast (ms)
