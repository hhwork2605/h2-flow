import React from "react";
import { createRoot } from "react-dom/client";
import GolivePanel from "./GolivePanel";
import "../styles/colors_and_type.css";
import "../styles/golive.css";


createRoot(document.getElementById("root")).render(<GolivePanel />)
