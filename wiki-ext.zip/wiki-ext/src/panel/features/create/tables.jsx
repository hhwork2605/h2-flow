import React from "react";
import { SCHEMA, isComplete } from "./config.js";
import { CellControl } from "../../shared/ui.jsx";
import { SvgCheck } from "../../shared/icons.jsx";

/* ============================================================================
   Step 2 — bảng điền (golive / rollback / checklist)
   ============================================================================ */
export function EditTable({ target, names, values, setVal, applyToAll }) {
  const sch = SCHEMA[target];
  return (
    <div className="g-tablewrap">
      <table className="g-wiki">
        <thead>
          <tr>
            <th className="col-num">#</th>
            <th className="col-nm">{sch.nm}</th>
            {sch.fields.map((f) => (
              <th key={f.id} className={f.type === "text" ? "col-t" : "col-yn"}>{f.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {names.map((nm, i) => {
            const v = values[nm] || {};
            const full = isComplete(target, v);
            return (
              <tr key={nm} className={full ? "full" : ""}>
                <td className="col-num">{i + 1}</td>
                <td className="col-nm"><span className="cn">"{nm}"</span>{full && <span className="ok"><SvgCheck s={13} /></span>}</td>
                {sch.fields.map((f) => (
                  <td key={f.id} className={f.type === "text" ? "col-t" : "col-yn"}>
                    <CellControl
                      field={f}
                      value={v[f.id]}
                      onChange={(val) => setVal(target, nm, f.id, val)}
                      onApplyAll={f.type === "text" ? (val) => applyToAll(target, f.id, val) : undefined}
                    />
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function ChecklistEdit({ names, values, setVal, belowRows }) {
  const sch = SCHEMA.checklist;
  return (
    <div className="g-tablewrap">
      <table className="g-wiki">
        <thead>
          <tr><th>Công cụ</th><th>Thành phần</th><th>Kết quả theo dõi</th><th>Ghi chú</th></tr>
        </thead>
        <tbody>
          {names.map((nm, i) => {
            const v = values[nm] || {};
            return (
              <tr key={"n-" + nm}>
                <td>{i === 0 ? "Opensearch" : ""}</td>
                <td><span className="cn">"{nm}"</span></td>
                <td><CellControl field={sch.fields[0]} value={v.result} onChange={(val) => setVal("checklist", nm, "result", val)} /></td>
                <td><CellControl field={sch.fields[1]} value={v.note} onChange={(val) => setVal("checklist", nm, "note", val)} /></td>
              </tr>
            );
          })}
          {belowRows.map((r, i) => (
            <tr key={"b-" + i} className="below">
              <td>{r.tool}</td><td><span className="cn">{r.comp}</span></td><td>{r.result || ""}</td><td>{r.note || ""}</td>
            </tr>
          ))}
          {belowRows.length === 0 && (
            <tr className="below">
              <td colSpan={4} style={{ textAlign: "center", padding: "12px", fontStyle: "italic" }}>
                (Chưa đọc được các nhóm giữ nguyên — mở đúng trang có bảng Checklist)
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
