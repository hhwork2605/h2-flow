/* ============================================================================
   Config bảng cho tính năng "Tạo component" (golive / rollback / checklist)
   ============================================================================ */
import { SvgRocket, SvgRefresh, SvgList } from "../../shared/icons.jsx";

export const TABS = [
  { key: "golive", label: "Golive", Icon: SvgRocket },
  { key: "rollback", label: "Rollback", Icon: SvgRefresh },
  { key: "checklist", label: "Checklist", Icon: SvgList },
];

export const TABLE_LABEL = {
  golive: "bảng Golive",
  rollback: "bảng Rollback",
  checklist: "Checklist (Opensearch)",
};

export const BLURB = {
  golive: "Bảng kịch bản go-live — chèn các thành phần đã chọn (checkbox để trống để team điền trên Confluence).",
  rollback: "Bảng thành phần rollback — chèn các thành phần đã chọn vào mục Kịch bản Rollback.",
  checklist: "Checklist sau golive — chỉ thay nhóm Opensearch, các nhóm khác giữ nguyên.",
};

// Schema cột (đúng cột Confluence thật) — type: yn (Yes/No) | text | chk (1 checkbox)
export const SCHEMA = {
  golive: {
    nm: "Thành phần golive",
    fields: [
      { id: "build", label: "Build?", type: "yn" },
      { id: "branch", label: "Git branch", type: "text", mono: true, ph: "release/24.12" },
      { id: "tag", label: "Tag go-live", type: "text", mono: true, ph: "v24.12.0" },
      { id: "package", label: "Package created?", type: "yn" },
      { id: "config", label: "Config/script", type: "text", ph: "Không / link" },
    ],
  },
  rollback: {
    nm: "Thành phần rollback",
    fields: [
      { id: "build", label: "Build?", type: "yn" },
      { id: "branch", label: "Git branch", type: "text", mono: true, ph: "hotfix/rollback" },
      { id: "tag", label: "Tag rollback", type: "text", mono: true, ph: "v24.11.3" },
      { id: "package", label: "Package created?", type: "yn" },
      { id: "config", label: "Config/script", type: "text", ph: "Không / link" },
    ],
  },
  checklist: {
    nm: "Thành phần",
    fields: [
      { id: "result", label: "Kết quả theo dõi", type: "chk", on: "bình thường" },
      { id: "note", label: "Ghi chú", type: "text", ph: "Không bắt buộc" },
    ],
  },
};

export const QUICK = {
  golive: { label: "Điền nhanh branch & tag mặc định", apply: (v) => ({ ...v, branch: v.branch || "release/24.12", tag: v.tag || "v24.12.0", build: v.build ?? true, package: v.package ?? true }) },
  rollback: { label: "Đánh dấu tất cả đã build", apply: (v) => ({ ...v, build: v.build ?? true, package: v.package ?? true }) },
  checklist: { label: "Đánh dấu tất cả bình thường", apply: (v) => ({ ...v, result: true }) },
};

export function isComplete(target, v) {
  if (!v) return false;
  if (target === "checklist") return v.result === true;
  return (v.build === true || v.build === false) && (v.package === true || v.package === false);
}
