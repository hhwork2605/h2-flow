/* ============================================================================
   Injected page functions — chạy bên trong tab Confluence (chrome.scripting).
   QUAN TRỌNG: mỗi hàm phải SELF-CONTAINED (không tham chiếu import/closure ngoài)
   vì được serialize bằng .toString() rồi inject vào trang.
   ============================================================================ */

// Lấy danh sách component + ticket từ bảng "Danh sách ticket golive".
// async: chờ bảng render + cuộn xuống đáy để infinite-loading nạp hết dòng.
export async function extractComponents() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const customOrder = [
    "Feature Management", "Database", "MHQL", "Mobile Api", "Booking Authorization",
    "Booking Auth Mobile", "Audit Trail Api", "Audit Trail", "Report Api", "Promotion Api",
    "LoyaltySmsService", "Loyalty Api", "KatScanChangedDataService", "TaxDeclarationExportService",
    "Booking Partner Api", "Booking Inventory Api", "Booking Identity Api", "Whats App Api",
    "Booking Integration Service", "Booking Integration API", "EInvoice-Api", "Analytic API",
    "Sync Event Api", "Command Worker", "Booking Schedule Web", "Booking Schedule Service",
    "Booking Process", "Zalo Service", "Booking Clear Data Service", "Whats App Service",
    "Online Booking Api", "Notification Service", "Mqtt Broker", "Mqtt Bridge", "Mqtt Auth",
    "Sms Service", "Update CRM", "Redis Multi Cache Service", "Tracking Service", "Import/Export",
    "AutoCustomerService", "MHQL_V2", "MHBH", "MHBH_V2", "Sale online", "Cpanel",
    "AdministrativeAreaService", "Booking Cpanel Core", "Booking Core", "booking mobile core",
    "Kat Integration Api", "TaxDeclarationExportService", "KatScanChangedDataService",
  ];

  // Tìm bảng dưới heading "Danh sách ticket golive"
  const findTable = () => {
    const mainContent = document.querySelector("#AkMainContent") || document.body;
    let found = null;
    mainContent.querySelectorAll("h1").forEach((h) => {
      if (found) return;
      if (h.innerText.trim() === "Danh sách ticket golive") {
        let next = h.nextElementSibling;
        let attempts = 0;
        while (next && attempts < 10) {
          if (next.tagName === "TABLE") { found = next; return; }
          const tbl = next.querySelector && next.querySelector("table");
          if (tbl) { found = tbl; return; }
          next = next.nextElementSibling;
          attempts++;
        }
      }
    });
    return found;
  };

  // Tìm phần tử cuộn (scroll container) bao quanh bảng
  const getScroller = (el) => {
    let n = el;
    while (n && n !== document.body && n !== document.documentElement) {
      const st = getComputedStyle(n);
      if (/(auto|scroll)/.test(st.overflowY + st.overflow) && n.scrollHeight > n.clientHeight + 4) return n;
      n = n.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  };

  // 1) Chờ bảng xuất hiện (tối đa ~6s)
  let targetTable = findTable();
  for (let i = 0; i < 12 && !targetTable; i++) {
    await sleep(500);
    targetTable = findTable();
  }
  if (!targetTable)
    return { error: 'Không tìm thấy bảng "Danh sách ticket golive"!' };

  // 2) Cuộn xuống đáy lặp lại tới khi số dòng ổn định (infinite loading nạp hết)
  let prevCount = -1;
  let stable = 0;
  for (let i = 0; i < 20; i++) {
    targetTable = findTable() || targetTable;
    const rowCount = targetTable.querySelectorAll("tr").length;
    if (rowCount === prevCount) {
      stable += 1;
      if (stable >= 2) break; // 2 lần liên tiếp không tăng → đã nạp hết
    } else {
      stable = 0;
      prevCount = rowCount;
    }
    const scroller = getScroller(targetTable);
    scroller.scrollTop = scroller.scrollHeight;
    window.scrollTo(0, document.body.scrollHeight);
    const trs = targetTable.querySelectorAll("tr");
    if (trs.length) trs[trs.length - 1].scrollIntoView({ block: "end" });
    await sleep(600);
  }

  // 3) Trích xuất
  targetTable = findTable() || targetTable;
  const map = {};
  targetTable.querySelectorAll("tr").forEach((r, i) => {
    if (i === 0) return;
    const compCell = r.children[5];
    if (!compCell) return;

    const comps = compCell.innerText
      .split(/[,\n]/)
      .map((c) => c.trim())
      .filter((c) => c && c !== "Components" && !c.includes("Mobile App"));
    if (!comps.length) return;

    const anchors = Array.from(r.querySelectorAll("a[href]")).filter(
      (a) => !compCell.contains(a)
    );
    const issueAnchor =
      anchors.find((a) => /browse\/|selectedIssue|\/jira\/|atlassian\.net/i.test(a.href)) ||
      anchors[0] || null;
    const href = issueAnchor ? issueAnchor.href : "";

    const isKey = (s) => /^[A-Z][A-Z0-9]+-\d+$/.test(s);
    let summary = "";
    Array.from(r.children).forEach((cell, ci) => {
      if (ci === 5) return;
      const txt = (cell.innerText || "").trim().replace(/\s+/g, " ");
      if (!txt || isKey(txt)) return;
      if (txt.length > summary.length) summary = txt;
    });
    if (!summary && issueAnchor) summary = (issueAnchor.innerText || "").trim();

    let ticket = null;
    if (summary || href) ticket = { text: summary || href, href };

    comps.forEach((c) => {
      if (!map[c]) map[c] = [];
      if (ticket) {
        const key = ticket.href + "|" + ticket.text;
        if (!map[c].some((t) => t.href + "|" + t.text === key)) map[c].push(ticket);
      }
    });
  });

  const components = Object.keys(map)
    .sort((a, b) => {
      const ia = customOrder.indexOf(a);
      const ib = customOrder.indexOf(b);
      return (ia === -1 ? 9999 : ia) - (ib === -1 ? 9999 : ib);
    })
    .map((name) => ({ name, tickets: map[name] }));

  return { components };
}

// Đọc map { component: tag } từ bảng "Kịch bản Golive" đang có trên trang (view mode).
// Cột: 0 Component · 1 Build · 2 Branch · 3 Tag · 4 Package · 5 Config.
// Tên component trong bảng có thể bọc nháy/`<code>` → chuẩn hoá bỏ nháy + trim.
export function extractGoliveTags() {
  const norm = (s) => (s || "").trim().replace(/^["']+|["']+$/g, "").trim();
  const root =
    document.querySelector(".ak-editor-content-area") ||
    document.querySelector('[contenteditable="true"]') ||
    document.querySelector("#AkMainContent") ||
    document.body;

  // Header của bảng golive: có cột Tag + (Build/Branch/Package/Component…).
  const isGoliveTable = (t) => {
    const head = (t.querySelector("tr") && t.querySelector("tr").innerText) || "";
    return /tag/i.test(head) && /(build|branch|package|component|thành phần)/i.test(head);
  };

  const rowCountOf = (t) => t.querySelectorAll("tr").length;
  // Chọn bảng golive NHIỀU DÒNG NHẤT trong tập ứng viên (tránh bảng header nổi chỉ 1 dòng).
  const pickBest = (list) => {
    let best = null, max = -1;
    for (const t of list) {
      if (!isGoliveTable(t)) continue;
      const rc = rowCountOf(t);
      if (rc > max) { max = rc; best = t; }
    }
    return best;
  };

  // 1) Gom mọi bảng nằm sau heading "Kịch bản Golive".
  let via = "none";
  let candidates = [];
  const els = root.querySelectorAll("h1, h2, h3, h4, p, span");
  for (const h of els) {
    if (candidates.length) break;
    if (!/Kịch bản Golive/i.test((h.innerText || "").trim())) continue;
    let next = (h.closest("p, h1, h2, h3, h4") && h.closest("p, h1, h2, h3, h4").nextElementSibling) || h.nextElementSibling;
    let n = 0;
    while (next && n < 15) {
      if (next.tagName === "TABLE") candidates.push(next);
      if (next.querySelectorAll) candidates.push(...next.querySelectorAll("table"));
      next = next.nextElementSibling;
      n++;
    }
    if (candidates.length) via = "heading";
  }
  let table = pickBest(candidates);
  // 2) Fallback: quét mọi bảng golive trong trang, chọn bảng nhiều dòng nhất.
  if (!table) { table = pickBest(Array.from(root.querySelectorAll("table"))); if (table) via = "fallback"; }
  if (!table) return { tags: {}, found: false, debug: { via, rootTag: root.tagName, tableCount: root.querySelectorAll("table").length } };

  // Xác định index cột Component / Tag từ header (không cứng index).
  let nameIdx = 0, tagIdx = 3;
  const headRow = table.querySelector("tr");
  const header = headRow ? Array.from(headRow.children).map((c) => (c.innerText || "").trim()) : [];
  {
    const hs = header.map((x) => x.toLowerCase());
    const ni = hs.findIndex((x) => /component|thành phần/.test(x)); if (ni >= 0) nameIdx = ni;
    const ti = hs.findIndex((x) => /\btag\b|tag\s*go|tag\s*rollback/.test(x)); if (ti >= 0) tagIdx = ti;
  }

  const allRows = Array.from(table.querySelectorAll("tr"));
  const tags = {};
  allRows.forEach((r, i) => {
    if (i === 0) return; // header
    const cells = r.children;
    if (!cells || cells.length <= Math.max(nameIdx, tagIdx)) return;
    const name = norm(cells[nameIdx].innerText);
    const tag = (cells[tagIdx].innerText || "").trim();
    if (name && tag) tags[name] = tag;
  });
  const sample = allRows.slice(0, 4).map((r) => Array.from(r.children).map((c) => (c.innerText || "").trim()));
  return { tags, found: true, debug: { via, header, nameIdx, tagIdx, rowCount: allRows.length, sample } };
}

// Đọc các dòng PHÍA DƯỚI nhóm Opensearch trong bảng Checklist (phần giữ nguyên).
// Quét mọi bảng, tìm bảng có dòng "Công cụ" = Opensearch (bền hơn so với dò heading).
export function extractChecklistBelow() {
  const root =
    document.querySelector(".ak-editor-content-area") ||
    document.querySelector('[contenteditable="true"]') ||
    document.querySelector("#AkMainContent") ||
    document.body;

  const norm = (s) => (s || "").trim().replace(/\s+/g, " ");
  const toolText = (r) => (r.children[0] ? norm(r.children[0].innerText) : "");

  const tables = Array.from(root.querySelectorAll("table"));
  let rows = null;
  let start = -1;
  for (const t of tables) {
    const tb = t.querySelector("tbody") || t;
    const rs = Array.from(tb.querySelectorAll(":scope > tr"));
    const idx = rs.findIndex((r) => /^opensearch$/i.test(toolText(r)));
    if (idx !== -1) { rows = rs; start = idx; break; }
  }
  if (!rows) return { below: [], debug: "no-opensearch-table" };

  // end = dòng kế tiếp có cột Công cụ khác rỗng (biên giới nhóm)
  let end = rows.length;
  for (let j = start + 1; j < rows.length; j++) {
    if (toolText(rows[j]) !== "") { end = j; break; }
  }

  const cellText = (r, i) => (r.children[i] ? norm(r.children[i].innerText) : "");
  const below = rows.slice(end).map((r) => ({
    tool: cellText(r, 0), comp: cellText(r, 1), result: cellText(r, 2), note: cellText(r, 3),
  }));

  return { below, debug: `start=${start} end=${end} total=${rows.length}` };
}

// Thao tác DOM editor để điền 1 bảng: golive | rollback | checklist
export function manipulateGoliveTableDOM(components, target) {
  const editor =
    document.querySelector(".ak-editor-content-area") ||
    document.querySelector('[contenteditable="true"]');
  if (!editor) return { error: "Không tìm thấy editor! Hãy mở trang ở chế độ Edit." };

  const uid = () =>
    window.crypto && window.crypto.randomUUID
      ? window.crypto.randomUUID()
      : "id-" + Math.random().toString(36).slice(2);

  const esc = (s) =>
    String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  // 1 task-item; done=true → đánh dấu hoàn thành (tick)
  const taskItem = (label, done) =>
    `<div data-task-local-id="${uid()}" data-task-state="${done ? "DONE" : "TODO"}">${esc(label)}</div>`;
  // Yes/No: tick Yes nếu val===true, tick No nếu val===false
  const taskListYesNo = (val) =>
    `<div data-task-list-local-id="${uid()}">` +
    taskItem("Yes", val === true) +
    taskItem("No", val === false) +
    `</div>`;
  const taskListSingle = (label, done) =>
    `<div data-task-list-local-id="${uid()}">` + taskItem(label, done) + `</div>`;
  const para = (txt) => `<p>${txt ? esc(txt) : ""}</p>`;

  // row = { name, build, branch, tag, package, config }
  const buildRow = (row) => {
    const tr = document.createElement("tr");
    const tdComp = document.createElement("td");
    tdComp.innerHTML = `<p><code>"${esc(row.name)}"</code></p>`;
    const tdBuild = document.createElement("td");
    tdBuild.innerHTML = taskListYesNo(row.build);
    const tdGit = document.createElement("td");
    tdGit.innerHTML = para(row.branch);
    const tdTag = document.createElement("td");
    tdTag.innerHTML = para(row.tag);
    const tdPkg = document.createElement("td");
    tdPkg.innerHTML = taskListYesNo(row.package);
    const tdConfig = document.createElement("td");
    tdConfig.innerHTML = para(row.config);
    tr.appendChild(tdComp); tr.appendChild(tdBuild); tr.appendChild(tdGit);
    tr.appendChild(tdTag); tr.appendChild(tdPkg); tr.appendChild(tdConfig);
    return tr;
  };

  // row = { name, result, note }
  const buildChecklistRow = (row, tool) => {
    const tr = document.createElement("tr");
    const tdTool = document.createElement("td");
    tdTool.innerHTML = para(tool || "");
    const tdComp = document.createElement("td");
    tdComp.innerHTML = `<p><code>"${esc(row.name)}"</code></p>`;
    const tdResult = document.createElement("td");
    tdResult.innerHTML = taskListSingle("bình thường", row.result === true);
    const tdNote = document.createElement("td");
    tdNote.innerHTML = para(row.note);
    const tdX1 = document.createElement("td");
    tdX1.innerHTML = `<p></p>`;
    const tdX2 = document.createElement("td");
    tdX2.innerHTML = `<p></p>`;
    tr.appendChild(tdTool); tr.appendChild(tdComp); tr.appendChild(tdResult);
    tr.appendChild(tdNote); tr.appendChild(tdX1); tr.appendChild(tdX2);
    return tr;
  };

  const findTable = (headingText, headerMatch) => {
    const els = editor.querySelectorAll("h1, h2, h3, h4, p, span");
    for (const el of els) {
      if (el.innerText && el.innerText.trim() === headingText) {
        let next =
          (el.closest("p, h1, h2, h3, h4") && el.closest("p, h1, h2, h3, h4").nextElementSibling) ||
          el.nextElementSibling;
        let attempts = 0;
        while (next && attempts < 20) {
          let candidate =
            next.tagName === "TABLE" ? next : next.querySelector ? next.querySelector("table") : null;
          if (candidate) {
            const headText = (candidate.querySelector("tr") && candidate.querySelector("tr").innerText) || "";
            if (!headerMatch || headText.includes(headerMatch)) return candidate;
          }
          next = next.nextElementSibling;
          attempts++;
        }
      }
    }
    return null;
  };

  const fillTable = (table, comps) => {
    const thead = table.querySelector("thead");
    const tbody = table.querySelector("tbody") || table;
    const dataRows = Array.from(tbody.querySelectorAll(":scope > tr"));
    if (thead) dataRows.forEach((r) => r.remove());
    else dataRows.slice(1).forEach((r) => r.remove());
    comps.forEach((comp) => tbody.appendChild(buildRow(comp)));
    return comps.length;
  };

  const fillChecklistOpensearch = (table, comps) => {
    const tbody = table.querySelector("tbody") || table;
    const rows = Array.from(tbody.querySelectorAll(":scope > tr"));
    const toolText = (r) => (r.children[0] ? r.children[0].innerText.trim() : "");
    let start = rows.findIndex((r) => toolText(r) === "Opensearch");
    if (start === -1) return { error: 'Không tìm thấy nhóm "Opensearch" trong Checklist!' };
    let end = rows.length;
    for (let j = start + 1; j < rows.length; j++) {
      if (toolText(rows[j]) !== "") { end = j; break; }
    }
    const anchor = rows[end] || null;
    for (let k = start; k < end; k++) rows[k].remove();
    comps.forEach((comp, idx) => {
      const tr = buildChecklistRow(comp, idx === 0 ? "Opensearch" : "");
      if (anchor) tbody.insertBefore(tr, anchor);
      else tbody.appendChild(tr);
    });
    return comps.length;
  };

  if (target === "checklist") {
    const t = findTable("Checklist đánh giá hệ thống sau khi golive/rollback", "Kết quả theo dõi");
    if (!t) return { error: 'Không tìm thấy bảng "Checklist đánh giá..." trong editor!' };
    const res = fillChecklistOpensearch(t, components);
    if (res && res.error) return res;
    editor.dispatchEvent(new Event("input", { bubbles: true }));
    return { success: true, target: "checklist", count: res };
  }

  if (target === "rollback") {
    const t = findTable("Kịch bản Rollback", "Thành phần rollback");
    if (!t) return { error: 'Không tìm thấy bảng "Thành phần rollback" trong editor!' };
    const c = fillTable(t, components);
    editor.dispatchEvent(new Event("input", { bubbles: true }));
    return { success: true, target: "rollback", count: c };
  }

  const t = findTable("Kịch bản Golive", "Thành phần");
  if (!t) return { error: 'Không tìm thấy bảng "Kịch bản Golive" trong editor!' };
  const c = fillTable(t, components);
  editor.dispatchEvent(new Event("input", { bubbles: true }));
  return { success: true, target: "golive", count: c };
}
