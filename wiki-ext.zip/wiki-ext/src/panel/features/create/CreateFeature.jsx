import React from "react";
import {
  SvgCheck, SvgFetch, SvgBolt, SvgSearch, SvgX, SvgCaret,
  SvgRefresh, SvgArrowLeft, SvgCloudUp, SvgSwap,
} from "../../shared/icons.jsx";
import { TABS, TABLE_LABEL, BLURB, QUICK } from "./config.js";
import { Check, Tickets } from "../../shared/ui.jsx";
import { EditTable, ChecklistEdit } from "./tables.jsx";

/* ============================================================================
   Tính năng "Tạo component" — chọn component → điền 3 bảng → đẩy lên Confluence
   ============================================================================ */
export function CreateFeature({ g }) {
  const {
    confMode, ready, loading, error, retryAttempt, MAX_RETRY, handleGet, isConfluenceTab,
    step, setStep, selCount, goStep2,
    query, setQuery, components, filtered, expanded, toggleExpand, toggleSelect, handleRemove,
    selected, allSel, someSel, selectAll, deselectAll,
    dragIndex, overIndex, handleDragStart, handleDragOver, handleDrop, handleDragEnd,
    activeKey, setActive, values, setVal, applyToAll, quickFill,
    selectedNames, checklistBelow, completed, pct, updatingTarget, handleUpdateTable,
  } = g;

  return (
    <>
      {/* app bar */}
      <div className="g-bar">
        <div className="g-bar-tt">
          <div className="t">Tạo component</div>
          <div className="s">Golive Components</div>
        </div>
        <span className={"g-mode" + (confMode === "edit" ? " edit" : "")}>
          <span className="dot" />
          <span className="lab">{confMode === "edit" ? "Edit" : "View"}</span>
        </span>
      </div>

      {/* stepper */}
      {ready && (
        <div className="g-steps">
          <div className={"g-step clickable " + (step === 1 ? "active" : "done")} onClick={() => setStep(1)}>
            <span className="num">{step > 1 ? <SvgCheck /> : "1"}</span>
            <span className="lbl">Chọn components</span>
          </div>
          <div className={"g-step-line" + (step > 1 ? " done" : "")} />
          <div className={"g-step " + (step === 2 ? "active" : "") + (selCount ? " clickable" : "")} onClick={() => selCount && goStep2()}>
            <span className="num">2</span>
            <span className="lbl">Điền bảng</span>
          </div>
        </div>
      )}

      {/* body */}
      <div className="g-body">
        {loading && (
          <div className="g-empty">
            <span className="ill"><span className="g-spin brand" style={{ width: 30, height: 30, borderWidth: 3 }} /></span>
            <h3>Đang lấy components…</h3>
            {retryAttempt > 0 ? (
              <p>
                Chưa thấy bảng — đang chờ trang tải xong.
                <br />
                Thử lại lần <b>{retryAttempt}/{MAX_RETRY}</b> (mỗi 5 giây)…
              </p>
            ) : (
              <p>Đang đọc bảng kế hoạch go-live từ trang Confluence.</p>
            )}
          </div>
        )}

        {!loading && !ready && (
          <div className="g-empty">
            <span className="ill"><SvgFetch s={34} /></span>
            <h3>Lấy danh sách Golive</h3>
            <p>Mở trang Confluence của sprint, sau đó lấy các thành phần cần go-live để bắt đầu.</p>
            {error && <div className="err">{error}</div>}
            <button
              className="g-btn primary"
              onClick={handleGet}
              disabled={!isConfluenceTab}
              title={!isConfluenceTab ? "Hãy mở tab https://citigo.atlassian.net/" : ""}
              style={{ marginTop: 4 }}
            >
              <SvgBolt s={16} />Lấy Components
            </button>
          </div>
        )}

        {ready && step === 1 && (
          <>
            <div className="g-tools">
              <div className="g-search">
                <span className="ic"><SvgSearch /></span>
                <input placeholder="Tìm component…" value={query} onChange={(e) => setQuery(e.target.value)} />
                {query && <span className="clr" onClick={() => setQuery("")}><SvgX s={14} /></span>}
              </div>
              <div className="g-toolrow">
                <span className="g-count">Tìm thấy <b>{components.length}</b> · đã chọn <b>{selCount}</b></span>
                <span className="g-draghint">⠿ Kéo để sắp xếp</span>
              </div>
            </div>

            <div className="g-tablewrap list">
              <table className="g-wiki comps">
                <thead>
                  <tr>
                    <th className="col-grip"></th>
                    <th className="col-cb" onClick={() => (allSel ? deselectAll() : selectAll())} title="Chọn tất cả">
                      <Check on={allSel} mixed={someSel} />
                    </th>
                    <th className="col-num">#</th>
                    <th className="col-cname">Component</th>
                    <th className="col-tkt">Ticket</th>
                    <th className="col-x"></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr><td className="g-emptyrow" colSpan={6}>Không có component khớp “{query}”.</td></tr>
                  )}
                  {filtered.map((c) => {
                    const idx = components.indexOf(c);
                    const total = c.tickets.length;
                    const open = expanded.has(c.name);
                    return (
                      <React.Fragment key={c.name}>
                        <tr
                          className={"crow" + (open ? " open" : "") + (dragIndex === idx ? " dragging" : "") + (overIndex === idx && dragIndex !== idx ? " over" : "")}
                          draggable
                          onDragStart={handleDragStart(idx)}
                          onDragOver={handleDragOver(idx)}
                          onDrop={handleDrop(idx)}
                          onDragEnd={handleDragEnd}
                        >
                          <td className="col-grip"><span className="g-grip" title="Kéo để sắp xếp">⠿</span></td>
                          <td className="col-cb" onClick={() => toggleSelect(c.name)}><Check on={!!selected[c.name]} /></td>
                          <td className="col-num">{idx + 1}</td>
                          <td className="col-cname" onClick={() => toggleSelect(c.name)}>{c.name}</td>
                          <td className="col-tkt">
                            <span className={"g-tkt" + (open ? " open" : "") + (total > 1 ? " many" : "")} onClick={() => toggleExpand(c.name)}>
                              <span className="cv"><SvgCaret /></span>{total} ticket
                            </span>
                          </td>
                          <td className="col-x">
                            <button className="g-rm" title="Bỏ khỏi danh sách" onClick={() => handleRemove(c.name)}><SvgX s={13} /></button>
                          </td>
                        </tr>
                        {open && (
                          <tr className="g-tickrow"><td colSpan={6}><Tickets tickets={c.tickets} /></td></tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        {ready && step === 2 && (
          <>
            <div className="g-tabs">
              {TABS.map((t) => (
                <button key={t.key} className={"g-tab" + (t.key === activeKey ? " on" : "")} onClick={() => setActive(t.key)}>
                  <span className="ic"><t.Icon s={14} /></span>{t.label}
                </button>
              ))}
            </div>

            <div className="g-blurb">{BLURB[activeKey]}</div>

            <div className="g-prog">
              <div className="g-prog-bar"><div className="g-prog-fill" style={{ width: pct + "%" }} /></div>
              <div className="g-prog-txt">
                <span>Đã điền <b>{completed}/{selCount}</b> thành phần</span>
                <span>{pct}%</span>
              </div>
            </div>

            <div className="g-quick">
              <SvgBolt s={14} /> Tiết kiệm thời gian
              <span className="lk" onClick={() => quickFill(activeKey, selectedNames)}>{QUICK[activeKey].label}</span>
            </div>

            <div className="g-scrollhint"><span className="ic"><SvgSwap /></span> Vuốt ngang để xem các cột · cột thành phần được ghim</div>

            {activeKey === "checklist" ? (
              <ChecklistEdit names={selectedNames} values={values.checklist} setVal={setVal} belowRows={checklistBelow} />
            ) : (
              <EditTable target={activeKey} names={selectedNames} values={values[activeKey]} setVal={setVal} applyToAll={applyToAll} />
            )}
          </>
        )}
      </div>

      {/* footer */}
      {ready && step === 1 && (
        <div className="g-foot">
          <div className="g-foot-row">
            <button className="g-btn secondary" style={{ flex: "0 0 auto", width: 46 }} onClick={handleGet} disabled={!isConfluenceTab} title={!isConfluenceTab ? "Hãy mở tab https://citigo.atlassian.net/" : "Lấy lại"}><SvgRefresh s={16} /></button>
            <button className="g-btn primary grow2" disabled={!selCount} onClick={goStep2}>
              Tiếp tục — điền bảng<span className="pill">{selCount}</span>
            </button>
          </div>
          <div className="g-hint">Chọn các thành phần cần đưa vào bảng go-live.</div>
        </div>
      )}

      {ready && step === 2 && (
        <div className="g-foot">
          <div className="g-foot-row">
            <button className="g-btn secondary" onClick={() => setStep(1)} disabled={!!updatingTarget}><SvgArrowLeft />Quay lại</button>
            <button className="g-btn primary grow2" onClick={() => handleUpdateTable(activeKey)} disabled={!!updatingTarget || !selCount}>
              {updatingTarget ? <span className="g-spin" /> : <SvgCloudUp s={16} />}
              {updatingTarget ? "Đang cập nhật…" : `Cập nhật ${TABLE_LABEL[activeKey]}`}
            </button>
          </div>
          <div className="g-hint">
            Đang preview <b>{TABLE_LABEL[activeKey]}</b>. Bấm Cập nhật — nếu đang ở chế độ View, extension sẽ tự chuyển sang Edit.
          </div>
        </div>
      )}
    </>
  );
}
