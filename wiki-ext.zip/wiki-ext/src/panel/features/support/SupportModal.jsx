import React from "react";
import { SvgX, SvgCopy } from "../../shared/icons.jsx";
import { SUPPORT_ACCOUNT, SUPPORT_IMG_FILE } from "./config.js";

/* ============================================================================
   Modal "Ủng hộ tác giả" — ảnh donate + thông tin chuyển khoản + nút sao chép.
   Thuần trình bày: nhận onClose + onCopy (sao chép STK kèm toast) từ orchestrator.
   ============================================================================ */
const IMG_SRC = 'https://cdn.jsdelivr.net/gh/hungnx2605/wedding@main/assets/images/anh-xin-tien.png'

export function SupportModal({ onClose, onCopy }) {
  return (
    <div className="g-modal-scrim" onClick={onClose}>
      <div className="g-modal" onClick={(e) => e.stopPropagation()}>
        <button className="g-modal-x" onClick={onClose} aria-label="Đóng">
          <SvgX s={15} />
        </button>
        <div className="g-modal-art">
          <img src={IMG_SRC} alt="Ủng hộ tác giả — +1 đồng +1 feature" />
        </div>
        <div className="g-modal-body">
          <h3>Ủng hộ tác giả ☕</h3>
          <p>
            Extension này được làm miễn phí lúc rảnh. Mỗi đóng góp nhỏ là thêm động lực cho
            tính năng mới — <b>+1 đồng, +1 feature</b>.
          </p>
          <div className="g-donate">
            <div className="g-donate-row">
              <span className="k">Chủ tài khoản</span>
              <span className="v">{SUPPORT_ACCOUNT.holder}</span>
            </div>
            <div className="g-donate-row">
              <span className="k">Số tài khoản</span>
              <span className="v mono">{SUPPORT_ACCOUNT.number}</span>
            </div>
            <div className="g-donate-row">
              <span className="k">Ngân hàng</span>
              <span className="v">{SUPPORT_ACCOUNT.bank}</span>
            </div>
          </div>
          <div className="g-modal-foot">
            <button className="g-btn secondary" onClick={onClose}>Để sau</button>
            <button className="g-btn primary" onClick={onCopy}>
              <SvgCopy s={16} />Sao chép STK
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
