/* ============================================================================
   Gating popup "Ủng hộ tác giả" qua jsonbin.io.
   Bin chứa { "notShowBonusPopup": ["<user>", ...] } — user (username Jenkins
   trong config) nằm trong mảng thì KHÔNG hiện popup.
   Logic miền thuần (không JSX) — useGolive gọi khi mount.
   ============================================================================ */

// ⚙ Điền thông tin bin jsonbin (đọc read-only bằng X-Access-Key).
//   - binId:     Bin ID (phần cuối URL, vd .../v3/b/<BIN_ID>)
//   - accessKey: X-Access-Key read-only (an toàn để nhúng — không ghi được bin)
export const BONUS_BIN = {
  binId: "6a27cbe8da38895dfe9edd41",
  accessKey: "$2a$10$Rw8N2OJGP98q31poDSSaOeOPX3CGoQ6x2/CR1GNBGIKeYm96deqSe",
};

// Đọc mảng notShowBonusPopup từ jsonbin.
// Chưa cấu hình bin / lỗi mạng → ném lỗi để nơi gọi quyết định fallback (mặc định: vẫn hiện).
export async function fetchNotShowBonusList() {
  const { binId, accessKey } = BONUS_BIN;
  if (!binId) return []; // chưa cấu hình → coi như danh sách rỗng (hiện popup cho mọi user)
  const res = await fetch(`https://api.jsonbin.io/v3/b/${binId}/latest`, {
    headers: accessKey ? { "X-Access-Key": accessKey } : {},
  });
  if (!res.ok) throw new Error(`jsonbin HTTP ${res.status}`);
  const json = await res.json();
  const record = json && json.record !== undefined ? json.record : json; // v3 bọc trong .record
  const list = record && record.notShowBonusPopup;
  return Array.isArray(list) ? list : [];
}

// User có bị loại khỏi popup không (so khớp không phân biệt hoa/thường, bỏ khoảng trắng).
export function isBonusExcluded(list, user) {
  const me = String(user || "")
    .trim()
    .toLowerCase();
  if (!me) return false; // chưa có user (chưa cấu hình Jenkins) → không loại → vẫn hiện
  return (list || []).some((u) => String(u).trim().toLowerCase() === me);
}
