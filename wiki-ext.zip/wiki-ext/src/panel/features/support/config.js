/* ============================================================================
   Thông tin ủng hộ tác giả (donate). Tách riêng để cả modal (hiển thị) và
   useGolive (sao chép STK) dùng chung — sửa số tài khoản chỉ ở một chỗ.
   ============================================================================ */
export const SUPPORT_ACCOUNT = {
  holder: "NGUYEN XUAN HUNG",
  number: "1600581219",
  bank: "BIDV — PGD Hồ Tây",
};

// Ảnh đặt ở public/ (crxjs copy ra gốc extension).
export const SUPPORT_IMG_FILE = "support.png";
