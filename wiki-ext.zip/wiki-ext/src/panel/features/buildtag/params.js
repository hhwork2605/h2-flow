/* ============================================================================
   Lấy choices của tham số build bằng cách FETCH trang form /build rồi parse HTML.
   Lưu ý: GET /build trả HTTP 405 (POST-only) NHƯNG body vẫn chứa form (radio/checkbox
   render sẵn) → cứ đọc res.text() bất kể status rồi parse. KHÔNG mở tab, KHÔNG cần cookie.
   KHÔNG JSX. Chi tiết: docs/05-jenkins-api.md.
   ============================================================================ */
import { jobApiUrl, sortTags } from "./jenkins.js";

// Parse HTML form → [{ name, kind, choices, def/defs }] (DOMParser chạy ở trang panel).
function parseParamForm(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const out = [];
  doc.querySelectorAll('input[name="name"]').forEach((h) => {
    const pname = h.value;
    if (!pname) return;
    const block = h.closest('[name="parameter"]') || h.closest(".jenkins-form-item, tr") || h.parentElement;
    if (!block) return;
    const sel = block.querySelector("select");
    const radios = Array.from(block.querySelectorAll("input[type=radio]"));
    const checks = Array.from(block.querySelectorAll("input[type=checkbox]"));
    if (sel) {
      const opts = Array.from(sel.options).map((o) => o.value || o.textContent.trim()).filter(Boolean);
      const defs = Array.from(sel.options).filter((o) => o.selected).map((o) => o.value || o.textContent.trim());
      out.push(sel.multiple ? { name: pname, kind: "multiselect", choices: opts, defs } : { name: pname, kind: "choice", choices: opts, def: defs[0] || opts[0] || "" });
    } else if (radios.length) {
      const choices = radios.map((r) => r.value).filter((v) => v != null && v !== "");
      const def = (radios.find((r) => r.checked) || {}).value || choices[0] || "";
      out.push({ name: pname, kind: "choice", choices, def });
    } else if (checks.length) {
      const valued = checks.filter((c) => c.value && c.value !== "on");
      if (valued.length) out.push({ name: pname, kind: "multiselect", choices: valued.map((c) => c.value), defs: valued.filter((c) => c.checked).map((c) => c.value) });
      else out.push({ name: pname, kind: "boolean", def: !!checks[0].checked });
    } else {
      const ta = block.querySelector("textarea");
      if (ta) { out.push({ name: pname, kind: "text", def: ta.value }); return; }
      const inp = block.querySelector("input:not([type=hidden])");
      out.push({ name: pname, kind: inp && inp.type === "password" ? "password" : "string", def: inp ? inp.value : "" });
    }
  });
  // Sắp xếp choices của param dạng version/tag theo version GIẢM DẦN (mới nhất lên đầu).
  out.forEach((p) => {
    if ((p.kind === "choice" || p.kind === "multiselect") && Array.isArray(p.choices) && /version|tag/i.test(p.name)) {
      p.choices = sortTags(p.choices);
    }
  });
  return out;
}

// Fetch form /build (token) rồi parse — đọc body kể cả khi status 405.
export async function fetchParamForm(cfg, job) {
  const formUrl = `${jobApiUrl(cfg, job)}/build?delay=0sec`;
  try {
    const res = await fetch(formUrl, {
      headers: { Authorization: "Basic " + btoa(`${cfg.user}:${cfg.token}`) },
      credentials: "omit",
    });
    const html = await res.text(); // 405 vẫn kèm body form
    return parseParamForm(html);
  } catch {
    return [];
  }
}
