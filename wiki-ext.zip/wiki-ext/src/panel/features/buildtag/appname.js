/* ============================================================================
   APP_NAME — phát hiện job pipeline có bước "Choose APP_NAME" và build kèm submit app.
   Tách riêng khỏi jenkins.js (logic miền chọn app). KHÔNG JSX.
   Chi tiết: docs/05-jenkins-api.md (mục APP_NAME).
   ============================================================================ */
import {
  trimSlash, authHeader, crumbHeaders, sleep, jobApiUrl, tagJobUrl, pollBuild, triggerBuild,
} from "./jenkins.js";
import { POLL, APP_MATCH_MAX } from "../../config.js";

// Decode các HTML entity hay gặp trong HTML replay trước khi tìm chuỗi.
const decodeEntities = (t) =>
  String(t || "").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&");

// Cắt mảng Groovy `return[ "a", "b", ... ]` thành mảng tên app.
// Chấp nhận cả nháy đơn lẫn nháy kép (Groovy hay dùng nháy đơn) → không JSON.parse.
const parseAppList = (text) => {
  const i = text.indexOf("return[");
  if (i < 0) return [];
  const j = text.indexOf("]", i);
  if (j < 0) return [];
  const inner = text.substring(i + "return[".length, j); // nội dung trong [ ]
  return inner
    .split(",")
    .map((s) => s.trim().replace(/^['"]+|['"]+$/g, "").trim())
    .filter(Boolean);
};

// Tìm base URL có lastBuild để đọc replay:
// - Project multibranch: pipeline nằm ở job con (tag/nhánh) → lấy 1 con ĐÃ có build.
// - Job pipeline thường: chính nó có lastBuild.
async function replayBaseOf(cfg, job) {
  const projectUrl = jobApiUrl(cfg, job);
  try {
    const r = await fetch(`${projectUrl}/api/json?tree=jobs[name,lastBuild[number]]`, { headers: authHeader(cfg), credentials: "omit" });
    if (r.ok) {
      const d = await r.json();
      const child = (d.jobs || []).find((c) => c.lastBuild && c.lastBuild.number);
      if (child) return `${projectUrl}/job/${encodeURIComponent(child.name)}`;
      if ((d.jobs || []).length) return ""; // là multibranch nhưng chưa con nào build → bỏ
    }
  } catch { /* ignore → thử chính job */ }
  return projectUrl; // job pipeline thường
}

// Map 1 build JSON → { status, url, number } (idle | building | success | failed).
const mapBuildStatus = (b) => {
  if (!b) return { status: "idle" };
  const url = trimSlash(b.url || "");
  if (b.building) return { status: "building", url, number: b.number };
  if (b.result) return { status: /SUCCESS/i.test(b.result) ? "success" : "failed", url, number: b.number };
  return { status: "idle", url, number: b.number };
};

// Build này có dùng đúng `app` không — dò dòng `docker build -t <registry>/<app>:<branch>`
// trong consoleText rồi so phần <app> (path segment cuối, trước dấu ':') với app đang chọn.
// App chọn qua input step (KHÔNG phải build parameter) nên phải đọc log mới biết; bắt đúng
// dòng docker build để tránh khớp nhầm vào path Dockerfile / URL git khác trong log.
const consoleMatchesApp = (text, app) => {
  const a = String(app || "").trim().toLowerCase();
  if (!a) return false;
  const re = /docker\s+build\b[^\n]*?-t\s+(\S+)/gi; // bắt image sau cờ -t trên dòng docker build
  let m;
  while ((m = re.exec(String(text || "")))) {
    const seg = m[1].toLowerCase().split(":")[0].split("/").pop(); // <registry>/<app>:<branch> → <app>
    if (seg === a) return true;
  }
  return false;
};

// Tìm build GẦN NHẤT của job-tag đã build đúng `app`, bằng cách quét consoleText các build gần
// đây (mới → cũ). Trả { status, url, number }; idle nếu không thấy / chưa build / log đã xoá.
// Thay cho buildUrlMap ở loại app: app không phải parameter nên phải đọc log để biết app từng build.
// Khớp app qua dòng `docker build -t <registry>/<app>:<branch>` (xem consoleMatchesApp).
// LƯU Ý: build cũ ngoài APP_MATCH_MAX hoặc đã rotate log → coi như chưa build (sẽ build lại).
export async function fetchLastBuildByApp(cfg, project, tag, app) {
  if (!app || !tag) return { status: "idle" };
  const jobUrl = tagJobUrl(cfg, project, tag);
  const headers = authHeader(cfg);
  const res = await fetch(`${jobUrl}/api/json?tree=builds[number,result,building,url]{0,${APP_MATCH_MAX}}`, { headers, credentials: "omit" });
  if (!res.ok) return { status: "idle" };
  const data = await res.json();
  for (const b of (data.builds || [])) { // mới → cũ
    if (!b || !b.url) continue;
    try {
      const c = await fetch(`${trimSlash(b.url)}/consoleText`, { headers, credentials: "omit" });
      if (!c.ok) continue;
      if (consoleMatchesApp(await c.text(), app)) return mapBuildStatus(b);
    } catch { /* bỏ qua build lỗi */ }
  }
  return { status: "idle" };
}

// Lấy danh sách APP_NAME của 1 job (đọc Jenkinsfile qua lastBuild/replay/).
// Trả về [] khi job không có bước APP_NAME, chưa từng build, hoặc lỗi.
export async function fetchJobAppNames(cfg, job) {
  if (!job) return [];
  const base = await replayBaseOf(cfg, job);
  if (!base) return [];
  const res = await fetch(`${base}/lastBuild/replay/`, { headers: authHeader(cfg), credentials: "omit" });
  if (!res.ok) return [];
  const text = decodeEntities(await res.text());
  if (!(/input\s+message/i.test(text) && text.includes("APP_NAME"))) return [];
  return parseAppList(text);
}

// Đọc input đang chờ của 1 build (404/null khi build chưa pause ở bước input).
async function fetchPendingInput(cfg, buildUrl) {
  const res = await fetch(`${trimSlash(buildUrl)}/wfapi/nextPendingInputAction`, { headers: authHeader(cfg), credentials: "omit" });
  if (!res.ok) return null;
  let data;
  try { data = await res.json(); } catch { return null; }
  const action = Array.isArray(data) ? data[0] : data; // tuỳ version: mảng hoặc object
  return action && action.proceedUrl ? action : null;
}

// Build 1 tag của job có APP_NAME: trigger → chờ pipeline pause ở "Choose APP_NAME"
// → POST submit app đã chọn → poll tới khi xong. Trả { result, buildUrl }.
export async function buildJobWithApp(cfg, project, tag, app, onPhase) {
  const jobUrl = tagJobUrl(cfg, project, tag);

  // 1) Trigger build + lấy URL build thật (giống buildJob).
  const { buildUrl } = await triggerBuild(cfg, jobUrl, "build", null, onPhase);

  // 2) Chờ pipeline pause ở bước input rồi submit app. Nếu build xong trước khi
  //    tới input (nhánh này không có bước app) → trả kết quả luôn.
  let submitted = false;
  for (let i = 0; i < POLL.APPINPUT_MAX_TRIES; i++) {
    const st = await fetch(`${buildUrl}/api/json?tree=building,result`, { headers: authHeader(cfg), credentials: "omit" });
    if (st.ok) {
      const sj = await st.json();
      if (!sj.building && sj.result) return { result: sj.result, buildUrl };
    }
    const action = await fetchPendingInput(cfg, buildUrl);
    if (action) {
      await submitInput(cfg, buildUrl, action, app);
      submitted = true;
      break;
    }
    await sleep(POLL.APPINPUT_INTERVAL_MS);
  }
  if (!submitted) throw new Error("Không thấy bước chọn APP_NAME để submit");

  // 3) Poll tới khi build xong.
  const r = await pollBuild(cfg, buildUrl);
  return { result: r.result, buildUrl };
}

// Submit giá trị app vào input đang chờ. Định dạng submit của Jenkins khác nhau
// theo version → thử lần lượt 2 cách, cách nào OK thì dừng:
//   (1) proceedUrl do nextPendingInputAction trả (vd `…/wfapi/inputSubmit?inputId=<id>`)
//   (2) endpoint cổ điển `{buildUrl}/input/{id}/submit` với `proceed` + `json`
async function submitInput(cfg, buildUrl, action, app) {
  const paramName = (action.inputs && action.inputs[0] && action.inputs[0].name) || "APP_NAME";
  const json = JSON.stringify({ parameter: [{ name: paramName, value: app }] });

  // Danh sách (url, body) sẽ thử theo thứ tự.
  const attempts = [];
  if (action.proceedUrl) {
    const u = action.proceedUrl.startsWith("http") ? action.proceedUrl : trimSlash(cfg.baseUrl) + action.proceedUrl;
    attempts.push({ url: u, body: "json=" + encodeURIComponent(json) });
  }
  if (action.id) {
    const proceedText = action.proceedText || "Proceed";
    attempts.push({
      url: `${trimSlash(buildUrl)}/input/${encodeURIComponent(action.id)}/submit`,
      body: "proceed=" + encodeURIComponent(proceedText) + "&json=" + encodeURIComponent(json),
    });
  }
  if (!attempts.length) throw new Error("Không xác định được endpoint submit app");

  let lastErr = "";
  for (const a of attempts) {
    try {
      const headers = await crumbHeaders(cfg, { "Content-Type": "application/x-www-form-urlencoded" });
      const res = await fetch(a.url, { method: "POST", headers, body: a.body, credentials: "omit" });
      if (res.ok || res.status === 302) return; // 302 = Jenkins redirect sau khi proceed
      lastErr = `HTTP ${res.status}`;
    } catch (e) {
      lastErr = e?.message || "lỗi mạng";
    }
  }
  throw new Error(`Submit app thất bại (${lastErr})`);
}
