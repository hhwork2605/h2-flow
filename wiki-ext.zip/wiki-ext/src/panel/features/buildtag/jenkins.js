/* ============================================================================
   Build tag — logic miền + đọc/ghi chrome.storage + gọi Jenkins API (KHÔNG JSX).
   Số/tham số tinh chỉnh nằm ở src/panel/config.js.
   ============================================================================ */
import { POLL, JOBS, DEFAULT_JENKINS_CFG, BUILD_DISABLED, PARAM_MATCH_MAX } from "../../config.js";
// Re-export để các file đang import từ jenkins.js không phải đổi đường dẫn.
export { DEFAULT_JENKINS_CFG, BUILD_DISABLED };

export const slugify = (s) =>
  String(s || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

// Map component (theo đúng tên trên Confluence) -> tên project/job gợi ý mặc định.
// Chỉ dùng làm gợi ý; người dùng chọn job thật từ danh sách Jenkins và lưu đè.
export const PROJECT_MAP = {
  "Database": "kv-booking-database",
  "MHQL": "kv-cashbook",
  "MHQL_V2": "kv-cashbook-v2",
  "MHBH": "kv-pos-sale",
  "MHBH_V2": "kv-pos-sale-v2",
  "Mobile Api": "kv-booking-mobile-api",
  "Booking Core": "kv-booking-core",
  "Booking Cpanel Core": "kv-booking-cpanel-core",
  "booking mobile core": "kv-booking-mobile-core",
  "Booking Schedule Service": "kv-booking-schedule-service",
  "Booking Schedule Web": "kv-booking-schedule-web",
  "Booking Process": "kv-booking-process",
  "Booking Inventory Api": "kv-booking-inventory-api",
  "Booking Identity Api": "kv-booking-identity-api",
  "Booking Partner Api": "kv-booking-partner-api",
  "Booking Integration Service": "kv-booking-integration-service",
  "Booking Integration API": "kv-booking-integration-api",
  "Booking Authorization": "kv-booking-authorization",
  "Booking Auth Mobile": "kv-booking-auth-mobile",
  "Online Booking Api": "kv-online-booking-api",
  "Notification Service": "kv-notification-service",
  "Report Api": "kv-report-api",
  "Promotion Api": "kv-promotion-api",
  "Loyalty Api": "kv-loyalty-api",
  "LoyaltySmsService": "kv-loyalty-sms-service",
  "Analytic API": "kv-analytic-api",
  "Sync Event Api": "kv-sync-event-api",
  "Command Worker": "kv-command-worker",
  "Audit Trail Api": "kv-audit-trail-api",
  "Audit Trail": "kv-audit-trail",
  "EInvoice-Api": "kv-einvoice-api",
  "Import/Export": "kv-import-export",
  "Tracking Service": "kv-tracking-service",
  "Zalo Service": "kv-zalo-service",
  "Sms Service": "kv-sms-service",
  "Whats App Api": "kv-whatsapp-api",
  "Whats App Service": "kv-whatsapp-service",
  "Update CRM": "kv-update-crm",
  "Redis Multi Cache Service": "kv-redis-multi-cache-service",
  "AutoCustomerService": "kv-auto-customer-service",
  "AdministrativeAreaService": "kv-administrative-area-service",
  "Kat Integration Api": "kv-kat-integration-api",
  "KatScanChangedDataService": "kv-kat-scan-changed-data-service",
  "TaxDeclarationExportService": "kv-tax-declaration-export-service",
  "Booking Clear Data Service": "kv-booking-clear-data-service",
  "Feature Management": "kv-feature-management",
  "Sale online": "kv-sale-online",
  "Cpanel": "kv-cpanel",
};

export const defaultProjectOf = (name) => PROJECT_MAP[name] || slugify(name);
export const trimSlash = (u) => String(u || "").replace(/\/+$/, "");

// Component chỉ hiển thị trong Build tag (danh sách ở config.js).
export const isBuildDisabled = (name) =>
  BUILD_DISABLED.some((d) => d.toLowerCase() === String(name || "").trim().toLowerCase());

/* ---- Jenkins config (chrome.storage.local) ----------------------------- */
export const JENKINS_CFG_KEY = "jenkinsConfig";
export const isCfgReady = (cfg) => !!(cfg && cfg.baseUrl && cfg.user && cfg.token);

export const loadJenkinsCfg = () =>
  new Promise((resolve) => {
    try {
      chrome.storage.local.get(JENKINS_CFG_KEY, (r) =>
        resolve({ ...DEFAULT_JENKINS_CFG, ...(r && r[JENKINS_CFG_KEY]) })
      );
    } catch {
      resolve({ ...DEFAULT_JENKINS_CFG });
    }
  });
export const saveJenkinsCfg = (cfg) =>
  new Promise((resolve) => {
    try {
      chrome.storage.local.set({ [JENKINS_CFG_KEY]: cfg }, () => resolve(true));
    } catch {
      resolve(false);
    }
  });

// Mapping component -> job fullName do người dùng chọn (lưu lại để dùng lần sau).
export const PROJECT_MAP_KEY = "projectMap";
export const loadProjectMap = () =>
  new Promise((resolve) => {
    try {
      chrome.storage.local.get(PROJECT_MAP_KEY, (r) => resolve((r && r[PROJECT_MAP_KEY]) || {}));
    } catch {
      resolve({});
    }
  });
export const saveProjectMap = (map) => {
  try { chrome.storage.local.set({ [PROJECT_MAP_KEY]: map }); } catch { /* ignore */ }
};

// appMap (component -> app), tagMap & paramMap KHÔNG lưu storage — chỉ giữ trong state phiên
// (chọn lại mỗi lần vào). Xem useGolive.
// KHÔNG còn buildUrlMap: trạng thái build đọc thẳng từ Jenkins — tag/plain dùng lastBuild,
// param dùng fetchLastBuildByParams, app dùng fetchLastBuildByApp (parse consoleText).


/* ---- Jenkins API ------------------------------------------------------- */
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const authHeader = (cfg) => ({ Authorization: "Basic " + btoa(`${cfg.user}:${cfg.token}`) });

// Header có thêm CSRF crumb (best-effort — Jenkins có thể tắt). Dùng cho mọi POST.
export async function crumbHeaders(cfg, extra = {}) {
  const headers = { ...authHeader(cfg), ...extra };
  try {
    const cr = await fetch(`${trimSlash(cfg.baseUrl)}/crumbIssuer/api/json`, { headers: authHeader(cfg), credentials: "omit" });
    if (cr.ok) { const j = await cr.json(); if (j && j.crumbRequestField) headers[j.crumbRequestField] = j.crumb; }
  } catch { /* ignore */ }
  return headers;
}

// Xin quyền truy cập host Jenkins (optional_host_permissions). Cần user-gesture.
export const requestJenkinsPermission = (baseUrl) =>
  new Promise((resolve) => {
    try {
      const origin = new URL(trimSlash(baseUrl)).origin + "/*";
      chrome.permissions.request({ origins: [origin] }, (granted) => resolve(!!granted));
    } catch {
      resolve(false);
    }
  });

// Kiểm tra ĐÃ có quyền host Jenkins chưa — KHÔNG bật prompt (dùng để auto-load an toàn).
export const hasJenkinsPermission = (baseUrl) =>
  new Promise((resolve) => {
    try {
      const origin = new URL(trimSlash(baseUrl)).origin + "/*";
      chrome.permissions.contains({ origins: [origin] }, (has) => resolve(!!has));
    } catch {
      resolve(false);
    }
  });

// URL API của 1 job theo fullName (hỗ trợ folder: "Booking/kv-cashbook").
export const jobApiUrl = (cfg, fullName) =>
  trimSlash(cfg.baseUrl) + "/job/" + String(fullName).split("/").map(encodeURIComponent).join("/job/");

// URL của 1 tag (job con) trong multibranch project: project + tag (1 segment).
export const tagJobUrl = (cfg, project, tag) =>
  jobApiUrl(cfg, project) + "/job/" + encodeURIComponent(tag);

// Sắp xếp tag: dạng version (vd 2.144.2) lên đầu, mới nhất trước; còn lại theo alpha.
const isVer = (s) => /^v?\d+(\.\d+)*$/i.test(String(s || ""));
const cmpVerDesc = (a, b) => {
  const pa = String(a).replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b).replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pb[i] || 0) !== (pa[i] || 0)) return (pb[i] || 0) - (pa[i] || 0);
  }
  return 0;
};
export const sortTags = (names) =>
  names.slice().sort((a, b) => {
    const va = isVer(a), vb = isVer(b);
    if (va && vb) return cmpVerDesc(a, b);
    if (va) return -1;
    if (vb) return 1;
    return a.localeCompare(b);
  });

// Lấy danh sách tag/nhánh (job con) của 1 multibranch project.
export async function fetchProjectTags(cfg, project) {
  const res = await fetch(`${jobApiUrl(cfg, project)}/api/json?tree=jobs[name]`, { headers: authHeader(cfg), credentials: "omit" });
  if (!res.ok) throw new Error(`Lỗi tải tag (HTTP ${res.status}).`);
  const data = await res.json();
  return sortTags((data.jobs || []).map((j) => j.name).filter(Boolean));
}

// Job/folder chứa các phần này sẽ bị loại khỏi danh sách.
const isExcluded = (name) => JOBS.EXCLUDE.some((re) => re.test(String(name || "")));

// Lấy danh sách job/project mà user có quyền — chỉ lấy project gốc, KHÔNG lấy
// các nhánh/tag con của multibranch (người dùng tự ghép tag sau khi build).
// Nếu cfg.folders có giá trị → CHỈ quét trong các folder đã chọn (tránh quét toàn bộ
// job có quyền cho nhanh); để trống → quét từ gốc như cũ.
export async function fetchJobs(cfg) {
  const base = trimSlash(cfg.baseUrl);
  const headers = authHeader(cfg);
  const out = [];
  const seen = new Set();
  const add = (fullName) => {
    if (fullName && !seen.has(fullName) && !isExcluded(fullName)) { seen.add(fullName); out.push(fullName); }
  };
  const visit = async (apiBase, depth) => {
    if (depth > JOBS.MAX_DEPTH) return;
    const res = await fetch(`${apiBase}/api/json?tree=jobs[name,fullName,url,buildable,_class]`, { headers, credentials: "omit" });
    if (!res.ok) {
      const unauthorized = res.status === 401 || res.status === 403;
      const err = new Error(unauthorized ? "Sai user/token hoặc không có quyền." : `Lỗi tải job (HTTP ${res.status}).`);
      if (unauthorized) err.unauthorized = true;
      throw err;
    }
    const data = await res.json();
    for (const j of (data.jobs || [])) {
      const fullName = j.fullName || j.name;
      const cls = j._class || "";
      if (isExcluded(fullName)) continue; // bỏ qua job/folder bị loại trừ
      if (/multibranch/i.test(cls)) {
        // Multibranch project: lấy chính project, KHÔNG đệ quy vào nhánh/tag con.
        add(fullName);
      } else if (/organizationfolder|folder/i.test(cls)) {
        // Folder/organization folder: chỉ gom nhóm → đi sâu vào trong.
        if (j.url) { try { await visit(trimSlash(j.url), depth + 1); } catch { /* bỏ qua nhánh lỗi */ } }
      } else if (j.buildable) {
        add(fullName);
      }
    }
  };
  // Phạm vi quét: các folder đã chọn (nếu có) hoặc gốc Jenkins.
  const roots = Array.isArray(cfg.folders) && cfg.folders.length
    ? cfg.folders.map((f) => jobApiUrl(cfg, f))
    : [base];
  for (const root of roots) {
    try { await visit(root, 0); }
    catch (e) { if (e && e.unauthorized) throw e; /* folder lỗi → bỏ qua, vẫn lấy folder khác */ }
  }
  return out.sort((a, b) => a.localeCompare(b));
}

// Liệt kê các FOLDER (kể cả folder lồng nhau) để người dùng chọn phạm vi quét job.
// Trả về mảng fullName của folder. KHÔNG đi vào multibranch (đó là project, không phải folder).
export async function fetchFolders(cfg) {
  const base = trimSlash(cfg.baseUrl);
  const headers = authHeader(cfg);
  const out = [];
  const visit = async (apiBase, depth) => {
    if (depth > JOBS.MAX_DEPTH) return;
    const res = await fetch(`${apiBase}/api/json?tree=jobs[name,fullName,url,_class]`, { headers, credentials: "omit" });
    if (!res.ok) {
      const unauthorized = res.status === 401 || res.status === 403;
      const err = new Error(unauthorized ? "Sai user/token hoặc không có quyền." : `Lỗi tải folder (HTTP ${res.status}).`);
      if (unauthorized) err.unauthorized = true;
      throw err;
    }
    const data = await res.json();
    for (const j of (data.jobs || [])) {
      const fullName = j.fullName || j.name;
      const cls = j._class || "";
      if (isExcluded(fullName) || /multibranch/i.test(cls)) continue;
      if (/organizationfolder|folder/i.test(cls)) {
        out.push(fullName);
        if (j.url) { try { await visit(trimSlash(j.url), depth + 1); } catch { /* bỏ qua folder lỗi */ } }
      }
    }
  };
  await visit(base, 0);
  return out.sort((a, b) => a.localeCompare(b));
}

// Đọc số build gần nhất của 1 job (null nếu chưa có).
async function lastBuildNumber(cfg, jobUrl) {
  try {
    const r = await fetch(`${jobUrl}/lastBuild/api/json?tree=number`, { headers: authHeader(cfg), credentials: "omit" });
    if (r.ok) { const j = await r.json(); return j && j.number != null ? j.number : null; }
  } catch { /* ignore */ }
  return null;
}

// POST trigger build tới endpoint của 1 job (build | buildWithParameters), rồi tìm URL build
// thật để theo dõi. body = null | URLSearchParams. Trả { buildUrl }.
// Cách 1: queue item từ header Location → executable.url.
// Cách 2 (khi không có Location, hay gặp ở buildWithParameters): dò lastBuild tới khi xuất
//   hiện build MỚI (number khác lúc trước trigger). Không bao giờ "fake success".
export async function triggerBuild(cfg, jobUrl, endpoint, body, onPhase) {
  const prevNum = await lastBuildNumber(cfg, jobUrl);
  const headers = await crumbHeaders(cfg);
  const res = await fetch(`${jobUrl}/${endpoint}`, { method: "POST", headers, body: body || undefined, credentials: "omit" });
  if (res.status !== 201 && !res.ok) throw new Error(`Trigger lỗi HTTP ${res.status}`);
  const queueUrl = trimSlash(res.headers.get("Location") || "");

  let buildUrl = "";
  // Cách 1: poll queue item.
  for (let i = 0; i < POLL.QUEUE_MAX_TRIES && queueUrl; i++) {
    await sleep(POLL.QUEUE_INTERVAL_MS);
    const q = await fetch(`${queueUrl}/api/json`, { headers: authHeader(cfg), credentials: "omit" });
    if (!q.ok) continue;
    const qj = await q.json();
    if (qj.cancelled) throw new Error("Job bị huỷ trong hàng đợi");
    if (qj.executable && qj.executable.url) { buildUrl = trimSlash(qj.executable.url); break; }
  }
  // Cách 2: không có queue/Location → dò build mới qua lastBuild.
  for (let i = 0; i < POLL.NEWBUILD_MAX_TRIES && !buildUrl; i++) {
    await sleep(POLL.NEWBUILD_INTERVAL_MS);
    try {
      const lb = await fetch(`${jobUrl}/lastBuild/api/json?tree=number,url`, { headers: authHeader(cfg), credentials: "omit" });
      if (lb.ok) {
        const lj = await lb.json();
        if (lj && lj.number != null && lj.number !== prevNum && lj.url) { buildUrl = trimSlash(lj.url); break; }
      }
    } catch { /* ignore */ }
  }
  if (!buildUrl) throw new Error("Không xác định được build sau khi trigger (queue trống, không thấy build mới).");
  if (onPhase) onPhase("building", buildUrl);
  return { buildUrl };
}

// Trigger build tag (job con) của 1 project rồi poll tới khi có kết quả.
// vd project="Hotel/MHQL", tag="2.144.2" → /job/Hotel/job/MHQL/job/2.144.2/build
// onPhase("building", buildUrl) khi job bắt đầu chạy. tag rỗng = build thẳng job (plain).
export async function buildJob(cfg, project, tag, onPhase) {
  const jobUrl = tag ? tagJobUrl(cfg, project, tag) : jobApiUrl(cfg, project);
  const { buildUrl } = await triggerBuild(cfg, jobUrl, "build", null, onPhase);
  const r = await pollBuild(cfg, buildUrl);
  return { result: r.result, buildUrl };
}

// Build "with parameters": POST {job}/buildWithParameters với các PARAM=value.
// values = { paramName: value }. Không có tham số nào → fallback /build.
export async function buildWithParameters(cfg, job, values, onPhase) {
  const jobUrl = jobApiUrl(cfg, job);
  const usp = new URLSearchParams();
  Object.entries(values || {}).forEach(([k, v]) => {
    if (Array.isArray(v)) v.forEach((x) => usp.append(k, x == null ? "" : String(x))); // multiselect → lặp key
    else usp.append(k, v == null ? "" : String(v));
  });
  const hasParams = Array.from(usp.keys()).length > 0;
  const { buildUrl } = await triggerBuild(cfg, jobUrl, hasParams ? "buildWithParameters" : "build", hasParams ? usp : null, onPhase);
  const r = await pollBuild(cfg, buildUrl);
  return { result: r.result, buildUrl };
}

// Map JSON build → { status, url, number }. status: idle | building | success | failed.
const mapBuild = (b) => {
  if (b.building) return { status: "building", url: trimSlash(b.url), number: b.number };
  if (b.result) return { status: /SUCCESS/i.test(b.result) ? "success" : "failed", url: trimSlash(b.url), number: b.number };
  return { status: "idle", url: trimSlash(b.url || ""), number: b.number };
};
async function fetchBuildJson(cfg, url) {
  const res = await fetch(`${url}/api/json?tree=building,result,number,url`, { headers: authHeader(cfg), credentials: "omit" });
  if (res.status === 404) return { status: "idle" }; // chưa có build nào
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return mapBuild(await res.json());
}

// Trạng thái build gần nhất tại 1 job URL (tag job hoặc job thường) — qua lastBuild.
export const fetchStatusAt = (cfg, jobUrl) => fetchBuildJson(cfg, `${trimSlash(jobUrl)}/lastBuild`);

// --- Tìm last build khớp tham số (loại param, thay cho buildUrlMap) ---------
// Chuẩn hoá value để so khớp: mảng (multiselect) → nối phẩy; boolean → "true"/"false".
const normParamVal = (v) => {
  if (Array.isArray(v)) return v.map((x) => String(x == null ? "" : x)).join(",");
  if (typeof v === "boolean") return v ? "true" : "false";
  return String(v == null ? "" : v);
};
// Gom parameters của 1 build (nằm trong actions[]) → { name: normValue }.
const buildParamMap = (b) => {
  const out = {};
  for (const a of (b.actions || [])) {
    for (const p of (a.parameters || [])) {
      if (p && p.name != null) out[p.name] = normParamVal(p.value);
    }
  }
  return out;
};
// Build có khớp ĐÚNG mọi tham số mong muốn không (so trên tập `want`).
const paramsMatch = (got, want) =>
  Object.keys(want).length > 0 &&
  Object.entries(want).every(([k, v]) => got[k] === normParamVal(v));

// Tìm build GẦN NHẤT của job param có parameters khớp đúng `values`. Trả { status, url, number }
// như fetchStatusAt; status "idle" khi không build nào khớp / chưa build / đã bị Jenkins xoá.
// Dùng thay buildUrlMap cho param: tham số được Jenkins lưu trong mỗi build nên query lại được.
// LƯU Ý: password/file param không lộ value trong api/json → không khớp được (sẽ coi như chưa build).
export async function fetchLastBuildByParams(cfg, job, values) {
  const want = values || {};
  if (!Object.keys(want).length) return fetchStatusAt(cfg, jobApiUrl(cfg, job)); // không tham số → như plain
  const tree = `builds[number,result,building,url,actions[parameters[name,value]]]{0,${PARAM_MATCH_MAX}}`;
  const res = await fetch(`${jobApiUrl(cfg, job)}/api/json?tree=${tree}`, { headers: authHeader(cfg), credentials: "omit" });
  if (!res.ok) return { status: "idle" };
  const data = await res.json();
  for (const b of (data.builds || [])) { // builds: mới → cũ
    if (paramsMatch(buildParamMap(b), want)) return mapBuild(b);
  }
  return { status: "idle" };
}

// Poll 1 build đang chạy (URL build) tới khi có kết quả.
export async function pollBuild(cfg, buildUrl) {
  const headers = authHeader(cfg);
  const u = trimSlash(buildUrl);
  for (let j = 0; j < POLL.BUILD_MAX_TRIES; j++) {
    const b = await fetch(`${u}/api/json?tree=building,result`, { headers, credentials: "omit" });
    if (b.ok) {
      const bj = await b.json();
      if (!bj.building && bj.result) return { result: bj.result };
    }
    await sleep(POLL.BUILD_INTERVAL_MS);
  }
  throw new Error("Quá thời gian chờ build");
}
