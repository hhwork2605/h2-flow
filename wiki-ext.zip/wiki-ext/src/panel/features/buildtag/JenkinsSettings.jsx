import React, { useEffect, useState } from "react";
import { SvgGear, SvgX } from "../../shared/icons.jsx";
import { trimSlash, requestJenkinsPermission, hasJenkinsPermission, fetchFolders } from "./jenkins.js";
import { FolderMultiSelect } from "./FolderMultiSelect.jsx";

/* ============================================================================
   Modal cấu hình Jenkins (URL + user + API token + folder quét job) — lưu vào
   chrome.storage.local. Xin quyền truy cập host Jenkins để gọi API trực tiếp.
   Folder hiển thị dạng multi-select (chip + filter); tự tải khi đổi user/token.
   ============================================================================ */
export function JenkinsSettings({ cfg, onClose, onSave }) {
  const [form, setForm] = useState({ folders: [], ...cfg });
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);
  const [folderList, setFolderList] = useState(null); // null = chưa tải
  const [loadingFolders, setLoadingFolders] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const selectedFolders = form.folders || [];

  // Validate URL + creds; trả baseUrl đã chuẩn hoá hoặc "" (kèm set lỗi).
  const validBase = () => {
    const baseUrl = trimSlash(form.baseUrl);
    if (!baseUrl || !/^https?:\/\//.test(baseUrl)) { setErr("Jenkins URL phải bắt đầu bằng http(s)://"); return ""; }
    if (!form.user || !form.token) { setErr("Cần nhập Username và API Token."); return ""; }
    return baseUrl;
  };

  // Tải danh sách folder. interactive=true → xin quyền (cần user-gesture) + báo lỗi rõ;
  // interactive=false (auto) → chỉ chạy khi ĐÃ có quyền, lỗi im lặng (tránh nháy lỗi lúc gõ).
  const loadFolders = async (interactive) => {
    const baseUrl = trimSlash(form.baseUrl);
    if (!baseUrl || !/^https?:\/\//.test(baseUrl) || !form.user || !form.token) return;
    const granted = interactive
      ? await requestJenkinsPermission(baseUrl)
      : await hasJenkinsPermission(baseUrl);
    if (!granted) { if (interactive) setErr("Cần cấp quyền truy cập Jenkins để tải folder."); return; }
    setLoadingFolders(true);
    if (interactive) setErr("");
    try {
      setFolderList(await fetchFolders({ ...form, baseUrl }));
    } catch (e) {
      if (interactive) setErr(e?.message || "Không tải được danh sách folder.");
    } finally {
      setLoadingFolders(false);
    }
  };

  // Tự tải folder khi user/token (hoặc URL) đổi — debounce, chỉ khi đã có quyền host.
  useEffect(() => {
    if (!form.user || !form.token) return;
    const id = setTimeout(() => loadFolders(false), 600);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.baseUrl, form.user, form.token]);

  const submit = async () => {
    const baseUrl = validBase();
    if (!baseUrl) return;
    setSaving(true);
    setErr("");
    const granted = await requestJenkinsPermission(baseUrl);
    if (!granted) { setSaving(false); return setErr("Cần cấp quyền truy cập Jenkins để gọi API."); }
    await onSave({ ...form, baseUrl, folders: selectedFolders });
    setSaving(false);
    onClose();
  };

  return (
    <div className="g-modal-wrap" onClick={onClose}>
      <div className="g-modal" onClick={(e) => e.stopPropagation()}>
        <div className="g-modal-head">
          <span className="g-logo" style={{ width: 30, height: 30 }}><SvgGear s={16} /></span>
          <span className="t">Cấu hình Jenkins</span>
          <button className="g-iconbtn" onClick={onClose}><SvgX s={16} /></button>
        </div>
        <div className="g-modal-body">
          {err && <div className="err">{err}</div>}
          <div className="g-formrow">
            <label>Jenkins URL</label>
            <input className="g-inp mono" placeholder="https://booking-jenkins-hub.citigo.net" value={form.baseUrl} onChange={set("baseUrl")} />
            <span className="hint">Địa chỉ gốc của Jenkins (không kèm /job/...).</span>
          </div>
          <div className="g-formrow">
            <label>Username</label>
            <input className="g-inp" placeholder="tên đăng nhập Jenkins" value={form.user} onChange={set("user")} />
          </div>
          <div className="g-formrow">
            <label>API Token</label>
            <input className="g-inp mono" type="password" placeholder="API token (không phải mật khẩu)" value={form.token} onChange={set("token")} />
            <span className="hint">Tạo tại Jenkins → User → Configure → API Token.</span>
          </div>
          <div className="g-formrow">
            <label>Folder quét job</label>
            <FolderMultiSelect
              options={folderList}
              value={selectedFolders}
              onChange={(folders) => setForm((f) => ({ ...f, folders }))}
              loading={loadingFolders}
              onActivate={() => { if (!folderList) loadFolders(true); }}
              placeholder="Lọc / chọn folder…"
            />
            <span className="hint">Chọn các folder/project <b>thường dùng</b> để chỉ quét trong đó — tránh load nhiều cho nhanh. Để trống = quét tất cả job có quyền (chậm). Tự tải khi nhập Username/Token.</span>
          </div>
          <div className="g-formrow">
            <span className="hint">Build tag sẽ trigger job-tag tương ứng (vd <code>Hotel/MHQL/v24.12.0</code>) qua Jenkins API và theo dõi trạng thái.</span>
          </div>
        </div>
        <div className="g-modal-foot">
          <button className="g-btn secondary" onClick={onClose} disabled={saving}>Huỷ</button>
          <button className="g-btn primary" onClick={submit} disabled={saving}>
            {saving ? <span className="g-spin" /> : null}{saving ? "Đang lưu…" : "Lưu"}
          </button>
        </div>
      </div>
    </div>
  );
}
