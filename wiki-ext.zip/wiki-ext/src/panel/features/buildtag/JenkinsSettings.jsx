import React, { useState } from "react";
import { SvgGear, SvgX } from "../../shared/icons.jsx";
import { trimSlash, requestJenkinsPermission } from "./jenkins.js";

/* ============================================================================
   Modal cấu hình Jenkins (URL + user + API token) — lưu vào chrome.storage.local.
   Xin quyền truy cập host Jenkins để gọi API trực tiếp.
   ============================================================================ */
export function JenkinsSettings({ cfg, onClose, onSave }) {
  const [form, setForm] = useState(cfg);
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    const baseUrl = trimSlash(form.baseUrl);
    if (!baseUrl || !/^https?:\/\//.test(baseUrl)) return setErr("Jenkins URL phải bắt đầu bằng http(s)://");
    if (!form.user || !form.token) return setErr("Cần nhập Username và API Token.");
    setSaving(true);
    setErr("");
    const granted = await requestJenkinsPermission(baseUrl);
    if (!granted) { setSaving(false); return setErr("Cần cấp quyền truy cập Jenkins để gọi API."); }
    await onSave({ ...form, baseUrl });
    setSaving(false);
    onClose();
  };

  return (
    <div className="g-modal-wrap" onClick={onClose}>
      <div className="g-modal" onClick={(e) => e.stopPropagation()}>
        <div className="g-modal-head">
          <span className="g-logo" style={{ width: 30, height: 30 }}><SvgGear s={16} /></span>
          <span className="t">Cấu hình Jenkins</span>
          <button className="g-iconbtn" onClick={onClose}><SvgX s={16} /></button>
        </div>
        <div className="g-modal-body">
          {err && <div className="err">{err}</div>}
          <div className="g-formrow">
            <label>Jenkins URL</label>
            <input className="g-inp mono" placeholder="https://booking-jenkins-hub.citigo.net" value={form.baseUrl} onChange={set("baseUrl")} />
            <span className="hint">Địa chỉ gốc của Jenkins (không kèm /job/...).</span>
          </div>
          <div className="g-formrow">
            <label>Username</label>
            <input className="g-inp" placeholder="tên đăng nhập Jenkins" value={form.user} onChange={set("user")} />
          </div>
          <div className="g-formrow">
            <label>API Token</label>
            <input className="g-inp mono" type="password" placeholder="API token (không phải mật khẩu)" value={form.token} onChange={set("token")} />
            <span className="hint">Tạo tại Jenkins → User → Configure → API Token.</span>
          </div>
          <div className="g-formrow">
            <span className="hint">Build tag sẽ trigger job-tag tương ứng (vd <code>Hotel/MHQL/v24.12.0</code>) qua Jenkins API và theo dõi trạng thái.</span>
          </div>
        </div>
        <div className="g-modal-foot">
          <button className="g-btn secondary" onClick={onClose} disabled={saving}>Huỷ</button>
          <button className="g-btn primary" onClick={submit} disabled={saving}>
            {saving ? <span className="g-spin" /> : null}{saving ? "Đang lưu…" : "Lưu"}
          </button>
        </div>
      </div>
    </div>
  );
}
