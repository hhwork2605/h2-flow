import React, { useState } from "react";
import { Check, BuildChip } from "../../shared/ui.jsx";
import { SvgExternal, SvgRefresh } from "../../shared/icons.jsx";
import { defaultProjectOf, isBuildDisabled } from "./jenkins.js";
import { ParamForm } from "./ParamForm.jsx";

// Nhãn + class badge theo loại build nhận diện được.
const TYPE_BADGE = {
  param: { label: "Tham số", cls: "param" },
  app: { label: "App", cls: "app" },
  tag: { label: "Tag", cls: "tag" },
  plain: { label: "Build", cls: "plain" },
};

/* ============================================================================
   Build tag — bảng Component · Project (job) · Tag · Trạng thái
   Project: chọn job Jenkins. Loại build (tag/app/param/plain) nhận diện tự động →
   badge + cột Tag hiển thị tương ứng (param: form tham số mở rộng dưới dòng).
   ============================================================================ */
export function BuildTag({ names, allNames, selected, buildStatus, buildUrl, building, isBuilding, jobs, jobsLoading, tagsByProject, jobMeta, projectMap, appMap, projectDisplay, onProjectInput, tagMap, onTagChange, onRetry, toggleSelect, toggleAll, typeOf, paramsOf, paramVal, setParam, onLoadParams, isParamLoading }) {
  // Bỏ qua component chỉ-hiển-thị (readonly) khỏi mọi con số đếm.
  const buildableAll = allNames.filter((n) => !isBuildDisabled(n));
  const buildableSel = names.filter((n) => !isBuildDisabled(n));
  const total = buildableAll.length;
  const selCount = buildableSel.length;
  const allSel = selCount === total && total > 0;
  const someSel = selCount > 0 && !allSel;
  const okCount = buildableSel.filter((n) => buildStatus[n] === "success").length;
  const failCount = buildableSel.filter((n) => buildStatus[n] === "failed").length;
  const buildingCount = buildableSel.filter((n) => buildStatus[n] === "building" || buildStatus[n] === "queued").length;
  const effProject = (nm) => ((projectMap[nm] || "").trim()) || defaultProjectOf(nm);

  const [openParams, setOpenParams] = useState(() => new Set()); // component đang mở form tham số
  const toggleParams = (nm) => setOpenParams((s) => {
    const n = new Set(s);
    if (n.has(nm)) n.delete(nm);
    else { n.add(nm); onLoadParams && onLoadParams(nm); } // mở → tải choices (scrape tab nếu cần)
    return n;
  });

  // Mục cho ô Project: job thường + (job có app) các mục "job/app".
  const appEntries = Object.entries(jobMeta || {}).flatMap(([job, m]) =>
    Array.isArray(m?.apps) ? m.apps.map((a) => job + "/" + a) : []);
  const jobOptions = Array.from(new Set([...jobs, ...appEntries]));

  return (
    <>
      <div className="g-prog" style={{ paddingTop: 14 }}>
        <div className="g-prog-txt" style={{ marginTop: 0 }}>
          <span>Đã chọn <b>{selCount}</b> / {total}</span>
          <span>
            {buildingCount > 0 && <b className="g-cnt-building">{buildingCount} đang build</b>}
            {buildingCount > 0 && " · "}
            {okCount} thành công · {failCount} thất bại
          </span>
        </div>
      </div>

      {/* danh sách job (kèm mục job/app) dùng chung cho mọi ô chọn project */}
      <datalist id="g-joblist">
        {jobOptions.map((j) => <option key={j} value={j} />)}
      </datalist>

      <div className="g-tablewrap">
        <table className="g-wiki tag">
          <thead>
            <tr>
              <th className="col-cb" onClick={toggleAll} title="Chọn tất cả"><Check on={allSel} mixed={someSel} /></th>
              <th className="col-num">#</th>
              <th className="col-nm">Component</th>
              <th className="col-proj">Project (job)</th>
              <th className="col-gentag">Tag / Tham số</th>
              <th className="col-st">Trạng thái</th>
            </tr>
          </thead>
          <tbody>
            {allNames.map((nm, i) => {
              const on = selected[nm];
              const st = on ? (buildStatus[nm] || "idle") : "idle";
              const proj = effProject(nm);
              const type = typeOf(nm);
              const badge = TYPE_BADGE[type] || TYPE_BADGE.tag;
              const tags = tagsByProject[proj]; // undefined = chưa tải
              const tagList = tags || [];
              const url = buildUrl[nm];
              const params = paramsOf(nm);
              const paramOpen = openParams.has(nm);
              // Component chỉ hiển thị (không thao tác/không build).
              if (isBuildDisabled(nm)) {
                return (
                  <tr key={nm} className="off g-rowdisabled" title="Chỉ hiển thị — build thủ công ở nơi khác">
                    <td className="col-cb"><Check on={false} /></td>
                    <td className="col-num">{i + 1}</td>
                    <td className="col-nm"><span className="cn">{nm}</span></td>
                    <td className="col-proj"><span className="g-muted">chỉ hiển thị</span></td>
                    <td className="col-gentag"><span className="g-muted">—</span></td>
                    <td className="col-st"><span className="g-muted">—</span></td>
                  </tr>
                );
              }
              return (
                <React.Fragment key={nm}>
                <tr className={on ? "" : "off"}>
                  <td className="col-cb" onClick={() => toggleSelect(nm)}><Check on={!!on} /></td>
                  <td className="col-num">{i + 1}</td>
                  <td className="col-nm"><span className="cn">{nm}</span></td>
                  <td className="col-proj">
                    <div className="g-projcell">
                      <input
                        className="g-cellinp mono"
                        list="g-joblist"
                        value={projectDisplay(nm)}
                        placeholder={jobsLoading ? "Đang tải job…" : "Chọn job Jenkins…"}
                        title={appMap[nm] ? `Job: ${proj} · App: ${appMap[nm]}` : "Chọn job Jenkins (job có app: chọn mục job/app) — tự lưu"}
                        onChange={(e) => onProjectInput(nm, e.target.value)}
                      />
                      {projectMap[nm] && <span className={"g-typebadge " + badge.cls} title={"Loại build: " + badge.label}>{badge.label}</span>}
                    </div>
                  </td>
                  <td className="col-gentag">
                    {type === "param" ? (
                      <button className="g-paramtoggle" title="Nhập tham số build" onClick={() => toggleParams(nm)}>
                        ⚙ {params.length} tham số {paramOpen ? "▴" : "▾"}
                      </button>
                    ) : type === "plain" ? (
                      <span className="g-muted">build thẳng</span>
                    ) : (
                      <>
                        <input
                          className="g-cellinp mono"
                          list={"g-tagopts-" + i}
                          value={tagMap[nm] || ""}
                          placeholder={tags === undefined ? "Đang tải tag…" : (tagList[0] || "Nhập tag…")}
                          title={`Build: ${proj}/${(tagMap[nm] || "").trim() || tagList[0] || "?"}`}
                          onChange={(e) => onTagChange(nm, e.target.value)}
                        />
                        <datalist id={"g-tagopts-" + i}>
                          {tagList.map((t) => <option key={t} value={t} />)}
                        </datalist>
                      </>
                    )}
                  </td>
                  <td className="col-st">
                    <div className="g-stcell">
                      {url && (st === "success" || st === "failed") ? (
                        <a className="g-openjob" href={url} target="_blank" rel="noopener noreferrer" title="Xem build trên Jenkins">
                          <BuildChip status={st} /><SvgExternal s={12} />
                        </a>
                      ) : (
                        <BuildChip status={st} />
                      )}
                      {on && (st === "idle" || st === "success" || st === "failed") && (
                        <button className="g-retry" title="Build lại dòng này" disabled={isBuilding(nm)} onClick={() => onRetry(nm)}>
                          <SvgRefresh s={12} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                {type === "param" && paramOpen && (
                  <tr className={on ? "g-paramtr" : "g-paramtr off"}>
                    <td colSpan={6}>
                      {isParamLoading && isParamLoading(nm) && (
                        <div className="g-muted" style={{ marginBottom: 8 }}>
                          <span className="g-spin brand" style={{ width: 12, height: 12, display: "inline-block", verticalAlign: "middle", marginRight: 6 }} />
                          Đang tải lựa chọn từ Jenkins…
                        </div>
                      )}
                      <ParamForm nm={nm} params={params} paramVal={paramVal} onChange={setParam} disabled={isBuilding(nm)} />
                    </td>
                  </tr>
                )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
