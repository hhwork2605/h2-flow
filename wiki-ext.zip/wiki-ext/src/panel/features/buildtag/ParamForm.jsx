import React, { useState } from "react";

/* ============================================================================
   Form nhập tham số cho job "build with parameters" — render theo đúng kiểu Jenkins:
   - choice       → single-select (radio list + ô lọc)
   - multiselect  → nhiều checkbox (chọn nhiều)
   - boolean      → 1 checkbox
   - text         → textarea ; string/password → input
   Giá trị đọc/ghi qua props (paramVal/onChange) — không giữ state giá trị riêng.
   ============================================================================ */
function ChoiceField({ nm, p, value, onChange }) {
  const [q, setQ] = useState("");
  const list = q ? p.choices.filter((c) => c.toLowerCase().includes(q.toLowerCase())) : p.choices;
  return (
    <div className="g-paramchoice">
      {p.choices.length > 6 && (
        <input className="g-cellinp g-paramfilter" placeholder="Lọc…" value={q} onChange={(e) => setQ(e.target.value)} />
      )}
      <div className="g-radiolist">
        {list.map((c) => (
          <label key={c} className="g-radioitem">
            <input type="radio" name={"p-" + nm + "-" + p.name} checked={value === c} onChange={() => onChange(nm, p.name, c)} />
            <span>{c}</span>
          </label>
        ))}
        {!list.length && <span className="g-paramempty">Không có lựa chọn khớp.</span>}
      </div>
    </div>
  );
}

function MultiField({ nm, p, value, onChange }) {
  const arr = Array.isArray(value) ? value : [];
  const toggle = (c) => onChange(nm, p.name, arr.includes(c) ? arr.filter((x) => x !== c) : [...arr, c]);
  return (
    <div className="g-checklist">
      {p.choices.map((c) => (
        <label key={c} className="g-checkitem">
          <input type="checkbox" checked={arr.includes(c)} onChange={() => toggle(c)} />
          <span>{c}</span>
        </label>
      ))}
    </div>
  );
}

export function ParamForm({ nm, params, paramVal, onChange, disabled }) {
  if (!params.length) return <div className="g-paramempty">Job này không có tham số.</div>;
  return (
    <fieldset className="g-paramform" disabled={disabled}>
      {params.map((p) => {
        const v = paramVal(nm, p);
        return (
          <div key={p.name} className="g-paramrow" title={p.desc || p.name}>
            <span className="g-paramname mono">{p.name}</span>
            <div className="g-paramctrl">
              {p.kind === "hidden" ? (
                <span className="g-muted mono">{Array.isArray(v) ? v.join(",") : String(v)} (ẩn)</span>
              ) : p.kind === "file" ? (
                <span className="g-muted">Upload file — chưa hỗ trợ trong tool</span>
              ) : (p.kind === "choice" || p.kind === "multiselect") && !(p.choices && p.choices.length) ? (
                // Không lấy được danh sách lựa chọn → cho gõ tay (multiselect: nhập cách nhau dấu phẩy).
                <input className="g-cellinp mono" value={Array.isArray(v) ? v.join(",") : v}
                  placeholder={p.kind === "multiselect" ? "value1,value2…" : "Nhập giá trị…"}
                  onChange={(e) => onChange(nm, p.name, p.kind === "multiselect" ? e.target.value.split(",").map((s) => s.trim()).filter(Boolean) : e.target.value)} />
              ) : p.kind === "choice" ? (
                <ChoiceField nm={nm} p={p} value={v} onChange={onChange} />
              ) : p.kind === "multiselect" ? (
                <MultiField nm={nm} p={p} value={v} onChange={onChange} />
              ) : p.kind === "boolean" ? (
                <input type="checkbox" checked={v === true || v === "true"} onChange={(e) => onChange(nm, p.name, e.target.checked)} />
              ) : p.kind === "text" ? (
                <textarea className="g-cellinp" rows={2} value={v} onChange={(e) => onChange(nm, p.name, e.target.value)} />
              ) : (
                <input className="g-cellinp mono" type={p.kind === "password" ? "password" : "text"} value={v} onChange={(e) => onChange(nm, p.name, e.target.value)} />
              )}
            </div>
          </div>
        );
      })}
    </fieldset>
  );
}
