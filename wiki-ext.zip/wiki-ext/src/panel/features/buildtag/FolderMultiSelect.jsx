import React, { useMemo, useState } from "react";
import { SvgCheck, SvgX } from "../../shared/icons.jsx";

/* ============================================================================
   Multi-select folder cho cấu hình Jenkins: mục đã chọn hiện thành chip (tag),
   có ô filter, và danh sách lọc bên dưới (click 1 dòng để chọn/bỏ chọn).
   Thuần trình bày — nhận options/value qua props, báo thay đổi qua onChange.
   ============================================================================ */
export function FolderMultiSelect({ options, value, onChange, loading, onActivate, placeholder }) {
  const [q, setQ] = useState("");
  const selected = value || [];
  const opts = options || [];
  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? opts.filter((o) => o.toLowerCase().includes(t)) : opts;
  }, [opts, q]);

  const toggle = (f) => {
    const set = new Set(selected);
    if (set.has(f)) set.delete(f); else set.add(f);
    onChange(Array.from(set));
  };

  return (
    <div className="g-ms">
      <div className="g-ms-box">
        <div className="g-ms-chips">
          {selected.map((f) => (
            <span key={f} className="g-ms-chip">
              <span className="mono">{f}</span>
              <button type="button" title="Bỏ chọn" onClick={() => toggle(f)}><SvgX s={11} /></button>
            </span>
          ))}
          <input
            className="g-ms-inp"
            value={q}
            placeholder={selected.length ? "Lọc folder…" : (placeholder || "Lọc / chọn folder…")}
            onChange={(e) => setQ(e.target.value)}
            onFocus={onActivate}
          />
        </div>
      </div>
      <div className="g-ms-list">
        {loading ? (
          <div className="g-ms-empty">Đang tải danh sách folder…</div>
        ) : !opts.length ? (
          <div className="g-ms-empty">Chưa có folder — nhập Username/Token để tự tải.</div>
        ) : !filtered.length ? (
          <div className="g-ms-empty">Không có folder khớp “{q}”.</div>
        ) : (
          filtered.map((f) => {
            const on = selected.includes(f);
            return (
              <div key={f} className={"g-ms-item" + (on ? " on" : "")} onClick={() => toggle(f)}>
                <span className="ck">{on ? <SvgCheck s={13} /> : null}</span>
                <span className="mono">{f}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
