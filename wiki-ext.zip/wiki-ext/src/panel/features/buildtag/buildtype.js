/* ============================================================================
   Nhận diện loại build của 1 job (param | app | tag | plain) + đọc tham số.
   Ưu tiên: param → app → tag → plain. KHÔNG JSX.
   Chi tiết: docs/05-jenkins-api.md (mục Nhận diện loại build & tham số).
   ============================================================================ */
import { authHeader, jobApiUrl } from "./jenkins.js";
import { fetchJobAppNames } from "./appname.js";

const csv = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean);

// Chuẩn hoá 1 ParameterDefinition → kind dùng cho form. Bảng mapping (class/type):
//   boolean      ← BooleanParameterDefinition
//   text         ← TextParameterDefinition | PT_TEXTBOX
//   password     ← PasswordParameterDefinition
//   multiselect  ← PT_MULTI_SELECT | PT_CHECKBOX (Extended Choice) → gửi chuỗi nối phẩy
//   hidden       ← PT_HIDDEN (không render, vẫn gửi default)
//   file         ← FileParameterDefinition (không hỗ trợ upload qua URL → chỉ báo)
//   choice       ← Choice/ChoiceParameter/Cascade/DynamicReference/Git/Run/PT_SINGLE_SELECT/PT_RADIO
//   string       ← còn lại
// Active Choices/Extended Choice/Git KHÔNG trả danh sách qua api/json → choices lấy từ
//   choices → value (chuỗi tất cả) → default → (bổ sung từ form HTML ở detectBuildType).
const normalizeParam = (p) => {
  const cls = p._class || "";
  const ct = (p.choiceType || "") + " " + (p.type || ""); // Extended Choice để PT_* ở `type`
  const sig = cls + " " + ct;
  let kind;
  if (/BooleanParameterDefinition/i.test(cls)) kind = "boolean";
  else if (/TextParameterDefinition|PT_TEXTBOX/i.test(sig)) kind = "text";
  else if (/PasswordParameterDefinition/i.test(cls)) kind = "password";
  else if (/PT_MULTI_SELECT|PT_CHECKBOX/i.test(ct)) kind = "multiselect";
  else if (/PT_HIDDEN/i.test(ct)) kind = "hidden";
  else if (/FileParameterDefinition/i.test(cls)) kind = "file";
  else if (/Choice|GitParameter|RunParameter|PT_SINGLE_SELECT|PT_RADIO|CascadeChoice|DynamicReference/i.test(sig)) kind = "choice";
  else kind = "string";

  const def = p.defaultParameterValue && p.defaultParameterValue.value != null ? p.defaultParameterValue.value : "";
  let choices = Array.isArray(p.choices) ? p.choices : (p.choices && Array.isArray(p.choices.values) ? p.choices.values : []);
  if (!choices.length && typeof p.value === "string" && p.value.includes(",")) choices = csv(p.value); // Extended Choice
  if (!choices.length && kind === "multiselect" && typeof def === "string") choices = csv(def);          // suy từ default
  const defs = kind === "multiselect" ? csv(typeof def === "string" ? def : "") : undefined;
  return { name: p.name, kind, choices, def, defs, desc: p.description || "" };
};

// Đọc tham số build của job + cờ có job con (multibranch). Trả { params, hasChildren }.
export async function fetchJobParams(cfg, job) {
  const tree = "property[_class,parameterDefinitions[name,type,_class,choiceType,value,description,choices,defaultParameterValue[value]]],jobs[name]";
  const res = await fetch(`${jobApiUrl(cfg, job)}/api/json?tree=${tree}`, { headers: authHeader(cfg), credentials: "omit" });
  if (!res.ok) return { params: [], hasChildren: false };
  const d = await res.json();
  const defs = (d.property || []).flatMap((p) => p.parameterDefinitions || []);
  const params = defs.filter((p) => p && p.name).map(normalizeParam);
  return { params, hasChildren: (d.jobs || []).length > 0 };
}

// Nhận diện loại build của 1 job. Trả { type, params, apps }.
export async function detectBuildType(cfg, job) {
  if (!job) return { type: "plain", params: [], apps: [] };
  try {
    const { params, hasChildren } = await fetchJobParams(cfg, job);
    // Choices (Active Choices/Git…) lấy bổ sung khi mở form tham số (scrape tab), xem useGolive.
    if (params.length) return { type: "param", params, apps: [] };
    const apps = await fetchJobAppNames(cfg, job); // đọc replay (job con đã build nếu multibranch)
    if (apps.length) return { type: "app", params: [], apps };
    return { type: hasChildren ? "tag" : "plain", params: [], apps: [] };
  } catch {
    return { type: "plain", params: [], apps: [] };
  }
}
