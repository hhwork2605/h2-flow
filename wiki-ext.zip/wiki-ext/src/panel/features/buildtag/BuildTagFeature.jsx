import React from "react";
import { SvgGear, SvgFetch, SvgBolt, SvgTag, SvgRefresh } from "../../shared/icons.jsx";
import { BuildTag } from "./BuildTag.jsx";
import { isBuildDisabled } from "./jenkins.js";

/* ============================================================================
   Tính năng "Build tag" — build các tag qua Jenkins API + theo dõi trạng thái
   ============================================================================ */
export function BuildTagFeature({ g }) {
  const {
    loading, ready, error, isConfluenceTab, handleGet, setShowSettings,
    selectedNames, allNames, selected, buildStatus, buildUrl, building, isBuilding,
    projectMap, appMap, projectDisplay, handleProjectInput, tagMap, handleTagChange,
    tagsByProject, jobMeta, toggleSelect, typeOf, paramsOf, paramVal, setParam, loadParamChoices, isParamLoading,
    allSel, selectAll, deselectAll, selCount,
    jobs, jobsLoading, jobsError, reloadAll, runBuilds, retryOne,
  } = g;
  const buildCount = selectedNames.filter((nm) => !isBuildDisabled(nm)).length; // bỏ readonly

  return (
    <>
      {/* app bar */}
      <div className="g-bar">
        <div className="g-bar-tt">
          <div className="t">Build tag</div>
          <div className="s">Build các tag qua Jenkins API</div>
        </div>
        <button className="g-iconbtn" title="Làm mới toàn bộ (lấy lại components, job, tag, trạng thái)" onClick={() => reloadAll()} disabled={jobsLoading}>
          {jobsLoading ? <span className="g-spin brand" style={{ width: 16, height: 16 }} /> : <SvgRefresh s={16} />}
        </button>
        <button className="g-iconbtn" title="Cấu hình Jenkins" onClick={() => setShowSettings(true)}>
          <SvgGear s={18} />
        </button>
      </div>

      {/* body */}
      <div className="g-body">
        {loading && (
          <div className="g-empty">
            <span className="ill"><span className="g-spin brand" style={{ width: 30, height: 30, borderWidth: 3 }} /></span>
            <h3>Đang lấy components…</h3>
            <p>Đang đọc bảng kế hoạch go-live từ trang Confluence.</p>
          </div>
        )}

        {!loading && !ready && (
          <div className="g-empty">
            <span className="ill"><SvgFetch s={34} /></span>
            <h3>Lấy danh sách để build tag</h3>
            <p>Lấy các thành phần golive của sprint, sau đó chạy build các tag tương ứng trên Jenkins.</p>
            {error && <div className="err">{error}</div>}
            <button
              className="g-btn primary"
              onClick={handleGet}
              disabled={!isConfluenceTab}
              title={!isConfluenceTab ? "Hãy mở tab https://citigo.atlassian.net/" : ""}
              style={{ marginTop: 4 }}
            >
              <SvgBolt s={16} />Lấy Components
            </button>
          </div>
        )}

        {ready && !loading && (
          <>
            <div className="g-blurb" style={{ paddingBottom: 0 }}>
              Chọn <b>job Jenkins</b> ở cột Project rồi chọn <b>tag</b> cần build (tag thật của project, mặc định là tag mới nhất). Job có bước chọn app sẽ hiện thêm mục <b>job/app</b> để chọn app — build sẽ tự submit. Lựa chọn tự lưu để dùng lại.
              {jobsError && <span style={{ color: "var(--error)", display: "block", marginTop: 4 }}>⚠ {jobsError}</span>}
              {!jobsError && !jobsLoading && jobs.length === 0 && (
                <span style={{ display: "block", marginTop: 4 }}>Chưa có job — bấm ⚙ để cấu hình Jenkins (URL + token).</span>
              )}
            </div>
            <BuildTag
              names={selectedNames}
              allNames={allNames}
              selected={selected}
              buildStatus={buildStatus}
              buildUrl={buildUrl}
              building={building}
              isBuilding={isBuilding}
              jobs={jobs}
              jobsLoading={jobsLoading}
              tagsByProject={tagsByProject}
              jobMeta={jobMeta}
              projectMap={projectMap}
              appMap={appMap}
              projectDisplay={projectDisplay}
              onProjectInput={handleProjectInput}
              tagMap={tagMap}
              onTagChange={handleTagChange}
              onRetry={retryOne}
              toggleSelect={toggleSelect}
              toggleAll={() => (allSel ? deselectAll() : selectAll())}
              typeOf={typeOf}
              paramsOf={paramsOf}
              paramVal={paramVal}
              setParam={setParam}
              onLoadParams={loadParamChoices}
              isParamLoading={isParamLoading}
            />
          </>
        )}
      </div>

      {/* footer */}
      {ready && !loading && (
        <div className="g-foot">
          <div className="g-foot-row">
            <button className="g-btn primary grow2" onClick={runBuilds} disabled={!buildCount}>
              {building ? <span className="g-spin" /> : <SvgTag s={16} />}
              Build tag<span className="pill">{buildCount}</span>
            </button>
          </div>
          <div className="g-hint">
            Trigger job build qua Jenkins API và theo dõi trạng thái ngay tại cột Trạng thái.
          </div>
        </div>
      )}
    </>
  );
}
