import React from "react";
import { SvgRocket, SvgTableIcon, SvgTag, SvgMug } from "./icons.jsx";

/* ============================================================================
   Sidebar điều hướng giữa các tính năng
   ============================================================================ */
export function Sidebar({ feature, setFeature, isConfluenceTab, collapsed, onToggle, onSupport }) {
  return (
    <div className={"g-side" + (collapsed ? " collapsed" : "")}>
      <button
        className="g-side-toggle"
        onClick={onToggle}
        title={collapsed ? "Mở rộng menu" : "Thu gọn menu"}
        aria-label={collapsed ? "Mở rộng menu" : "Thu gọn menu"}
      >
        {collapsed ? "»" : "«"}
      </button>
      <div className="g-side-brand">
        <span className="g-logo"><SvgRocket s={18} /></span>
        <div className="g-side-bt">
          <div className="t">Wiki Ext</div>
          <div className="s">KiotViet Booking</div>
        </div>
      </div>
      <nav className="g-nav">
        <button className={"g-navitem" + (feature === "create" ? " on" : "")} onClick={() => setFeature("create")}>
          <SvgTableIcon s={18} /><span>Tạo component</span>
        </button>
        <button className={"g-navitem" + (feature === "tag" ? " on" : "")} onClick={() => setFeature("tag")}>
          <SvgTag s={18} /><span>Build tag</span>
        </button>
      </nav>
      <div className="g-side-foot">
        <button className="g-support-btn" onClick={onSupport} title="Ủng hộ tác giả">
          <SvgMug s={14} /><span>Ủng hộ tác giả</span>
        </button>
        <span className={"g-conn" + (isConfluenceTab ? "" : " off")}>
          <span className="dot" />
          <span>{isConfluenceTab ? "Đã kết nối Confluence" : "Chưa ở trang Confluence"}</span>
        </span>
      </div>
    </div>
  );
}
