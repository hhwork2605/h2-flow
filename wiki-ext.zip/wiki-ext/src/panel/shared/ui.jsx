import React from "react";
import { SvgMinus, SvgCheck, SvgApplyAll, SvgCircle, SvgClock, SvgCircleCheck, SvgCircleX } from "./icons.jsx";

/* ============================================================================
   Primitive UI dùng chung giữa các tính năng
   ============================================================================ */
export function Check({ on, mixed }) {
  return (
    <span className={"g-cb" + (on ? " on" : "") + (mixed ? " mixed" : "")}>
      {mixed ? <SvgMinus /> : on ? <SvgCheck /> : null}
    </span>
  );
}

export function Tickets({ tickets }) {
  if (!tickets || tickets.length === 0)
    return <div className="g-tickets"><span className="more">Không có ticket</span></div>;
  return (
    <div className="g-tickets">
      {tickets.map((t, i) => (
        <div className="g-ticket" key={i}>
          {t.href ? (
            <a className="key" href={t.href} target="_blank" rel="noopener noreferrer">↗</a>
          ) : (
            <span className="key none">•</span>
          )}
          <span>{t.text}</span>
        </div>
      ))}
    </div>
  );
}

// Control sửa trong ô bảng. onApplyAll(value): nếu có → hiện nút áp dụng cho tất cả
export function CellControl({ field, value, onChange, onApplyAll }) {
  if (field.type === "yn")
    return (
      <div className="g-yesno cell">
        <button className={"yes" + (value === true ? " on yes" : "")} onClick={() => onChange(value === true ? null : true)}>Yes</button>
        <button className={"no" + (value === false ? " on no" : "")} onClick={() => onChange(value === false ? null : false)}>No</button>
      </div>
    );
  if (field.type === "chk")
    return (
      <span className={"g-chk" + (value === true ? " on" : "")} onClick={() => onChange(value === true ? null : true)}>
        <span className="bx">{value === true ? <SvgCheck s={11} /> : null}</span>{field.on}
      </span>
    );
  return (
    <div className="g-cellwrap">
      <input
        className={"g-cellinp" + (field.mono ? " mono" : "")}
        placeholder={field.ph}
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
      />
      {onApplyAll && (value || "").trim() !== "" && (
        <button
          type="button"
          className="g-applyall"
          title="Áp dụng giá trị này cho tất cả component"
          onClick={() => onApplyAll(value)}
        >
          <SvgApplyAll s={14} />
        </button>
      )}
    </div>
  );
}

/* ---- Chip trạng thái build (Build tag) --------------------------------- */
export const BUILD_META = {
  idle:     { cls: "idle",   label: "Chưa build",     Icon: SvgCircle },
  queued:   { cls: "queued", label: "Trong hàng đợi", Icon: SvgClock },
  building: { cls: "build",  label: "Đang build",     Icon: null },
  success:  { cls: "ok",     label: "Thành công",     Icon: SvgCircleCheck },
  failed:   { cls: "fail",   label: "Thất bại",       Icon: SvgCircleX },
};
export function BuildChip({ status }) {
  const m = BUILD_META[status] || BUILD_META.idle;
  return (
    <span className={"g-bchip " + m.cls}>
      {status === "building"
        ? <span className="g-spin brand" style={{ width: 12, height: 12, borderWidth: 2 }} />
        : <m.Icon s={12} />}
      {m.label}
    </span>
  );
}
