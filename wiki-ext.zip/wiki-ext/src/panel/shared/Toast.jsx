import React from "react";
import { SvgCheck, SvgX, SvgInfo } from "./icons.jsx";

/* ============================================================================
   Toast thông báo (ok / err / info)
   ============================================================================ */
export function Toast({ toast, onClose }) {
  if (!toast) return null;
  return (
    <div className="g-toast-wrap">
      <div className={"g-toast " + (toast.type === "ok" ? "ok" : toast.type === "err" ? "err" : "")}>
        <span className={"ic " + (toast.type === "ok" ? "" : toast.type === "err" ? "" : "info")}>
          {toast.type === "ok" ? <SvgCheck s={15} /> : toast.type === "err" ? <SvgX s={15} /> : <SvgInfo s={16} />}
        </span>
        <div className="tx">
          <div className="t">{toast.t}</div>
          {toast.d && <div className="d">{toast.d}</div>}
        </div>
        <span className="x" onClick={onClose}><SvgX s={14} /></span>
      </div>
    </div>
  );
}
