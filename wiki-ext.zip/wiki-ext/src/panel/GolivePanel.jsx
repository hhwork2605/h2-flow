import React from "react";
import { useGolive } from "./useGolive.js";
import { Sidebar } from "./shared/Sidebar.jsx";
import { CreateFeature } from "./features/create/CreateFeature.jsx";
import { BuildTagFeature } from "./features/buildtag/BuildTagFeature.jsx";
import { JenkinsSettings } from "./features/buildtag/JenkinsSettings.jsx";
import { SupportModal } from "./features/support/SupportModal.jsx";
import { Toast } from "./shared/Toast.jsx";

/* ============================================================================
   GolivePanel — orchestrator: gọi useGolive() rồi ghép sidebar + feature view.
   Mọi state/handler nằm trong useGolive; UI từng tính năng nằm ở file riêng.
   ============================================================================ */
export default function GolivePanel() {
  const g = useGolive();
  const [collapsed, setCollapsed] = React.useState(false); // thu gọn sidebar chủ động

  return (
    <div className="g-stage">
      <div className="g-dock">
        <Sidebar
          feature={g.feature}
          setFeature={g.setFeature}
          isConfluenceTab={g.isConfluenceTab}
          collapsed={collapsed}
          onToggle={() => setCollapsed((v) => !v)}
          onSupport={() => g.setShowSupport(true)}
        />

        <div className="g-panel">
          {g.feature === "create" && <CreateFeature g={g} />}
          {g.feature === "tag" && <BuildTagFeature g={g} />}
        </div>
      </div>

      {g.showSettings && (
        <JenkinsSettings cfg={g.jenkinsCfg} onClose={() => g.setShowSettings(false)} onSave={g.handleSaveCfg} />
      )}

      {g.showSupport && (
        <SupportModal onClose={() => g.setShowSupport(false)} onCopy={g.copyAccount} />
      )}

      <Toast toast={g.toast} onClose={() => g.setToast(null)} />
    </div>
  );
}
