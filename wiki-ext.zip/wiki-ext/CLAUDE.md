# CLAUDE.md

Hướng dẫn cho Claude khi làm việc trong repo này (Wiki Extensions — Chrome side panel, React + Vite).

## Tài liệu trước, code sau — "First document" (BẮT BUỘC)

Trước khi code tính năng mới HOẶC sửa code hiện có, **luôn rà nghiệp vụ trong `docs/` trước**:

1. **Đọc `docs/`** để nắm nghiệp vụ liên quan (mục lục ở [docs/README.md](docs/README.md)).
2. **Cập nhật tài liệu TRƯỚC khi viết code**:
   - Thay đổi/ảnh hưởng nghiệp vụ đang có → **sửa** file `docs/*` tương ứng cho khớp.
   - Nghiệp vụ/tính năng mới chưa có tài liệu → **thêm file `docs/` mới trước**, rồi mới code.
3. Code xong phải đảm bảo `docs/` vẫn đúng (không để tài liệu lệch với code). Coi việc lệch docs ↔ code là lỗi.

> Quy tắc: **không commit thay đổi code mà bỏ quên cập nhật `docs/`.** Tài liệu là nguồn nghiệp vụ — đi trước và luôn đồng bộ với code.

Khi tạo tài liệu mới: chia file rõ ràng theo chủ đề, đặt trong `docs/`, và thêm dòng vào mục lục [docs/README.md](docs/README.md).

## Quy tắc tổ chức code (BẮT BUỘC)

- **Mỗi tính năng / mỗi khối trách nhiệm tách thành file riêng** — không dồn nhiều thứ vào một file lớn.
  Mục tiêu: các phần độc lập, sửa phần này không động đến phần kia.
- **Trần kích thước file**: nếu một file vượt ~300 dòng hoặc gom nhiều mối quan tâm khác nhau,
  hãy tách thành các module nhỏ hơn theo trách nhiệm.
- **Tổ chức theo thư mục: `shared/` cho dùng chung, `features/<tên>/` cho từng tính năng.**
  Cấu trúc hiện tại trong `src/panel/`:
  ```
  GolivePanel.jsx          # orchestrator: gọi useGolive() + ghép sidebar/feature/modal/toast
  main.jsx                 # mount React
  useGolive.js             # hook gom toàn bộ state + handler (không JSX)
  shared/                  # dùng chung nhiều tính năng
    icons.jsx              # icon SVG
    ui.jsx                 # primitive: Check, Tickets, CellControl, BuildChip
    Sidebar.jsx, Toast.jsx
  features/
    create/                # tính năng "Tạo component"
      CreateFeature.jsx    # view
      tables.jsx           # EditTable, ChecklistEdit
      config.js            # schema bảng golive/rollback/checklist
      injected.js          # hàm chạy trong tab Confluence (self-contained)
    buildtag/              # tính năng "Build tag"
      BuildTagFeature.jsx  # view
      BuildTag.jsx         # bảng
      JenkinsSettings.jsx  # modal cấu hình
      jenkins.js           # logic miền + chrome.storage (không JSX)
  ```
  - File dùng chung > 1 tính năng → đặt ở `shared/`. File chỉ phục vụ 1 tính năng → đặt trong `features/<tên>/`.
  - `injected.js` **phải self-contained** (không tham chiếu biến/import ngoài) vì được serialize bằng `.toString()`.
  - Thêm tính năng mới = tạo thư mục `features/<tên>/` mới với view + logic riêng, rồi gắn vào `GolivePanel.jsx` + `useGolive.js`.
- **Component UI** thuần trình bày, nhận dữ liệu qua props; **state/handler** đặt ở orchestrator hoặc hook riêng — tránh prop-drilling sâu thì cân nhắc tách hook (`useXxx`) thay vì nhồi vào component.
- **Logic miền (domain) không trộn JSX**: helper tính toán/đọc-ghi storage để ở file `.js` riêng, không lẫn vào component.
- Khi thêm tính năng mới: tạo file mới cho UI + (nếu cần) file logic riêng, rồi gắn vào orchestrator — **không sửa chèn vào tính năng khác**.

## Build / verify

- Build: `npm run build` (Vite). Luôn build lại sau khi sửa và kiểm tra không có lỗi.
- Sau khi build: vào `chrome://extensions/` → reload extension để thử.

## Lưu ý kỹ thuật

- Hàm trong `injected.js` chạy ở context trang web, **không dùng được import/closure** — khai báo mọi thứ cần dùng ngay bên trong hàm.
- Tính năng **Build tag** gọi **Jenkins API** trực tiếp (cần `user` + API token, lưu trong `chrome.storage.local`):
  - Lấy danh sách job (đệ quy folder; multibranch lấy chính project, không lấy nhánh/tag con) cho ô chọn "Project"; chọn tag thật của project ở ô "Tag". Lựa chọn component→job (`projectMap`) và component→tag (`tagMap`) lưu vào storage để dùng lại.
  - Build job-tag = `{project}/{tag}` qua `POST /build`; trước khi build sẽ `fetchTagStatus` kiểm tra đã build chưa (đã build thì báo luôn, đang build thì bám theo). Có nút **Retry** build lại.
  - Cần host permission tới Jenkins → khai báo `optional_host_permissions` trong manifest và `chrome.permissions.request` khi lưu cấu hình.
  - Chi tiết: [docs/04-tinh-nang-build-tag.md](docs/04-tinh-nang-build-tag.md), [docs/05-jenkins-api.md](docs/05-jenkins-api.md).
