# Golive Table Update — DOM Manipulation Plan

## Mô tả

Thay vì gọi Confluence REST API, extension inject script trực tiếp vào
trang Confluence đang mở ở chế độ **Edit**, thao tác DOM của editor để:

1. Tìm bảng "Kịch bản Golive"
2. Xóa toàn bộ rows cũ (giữ header)
3. Điền rows mới theo component list
4. User review trực tiếp trên editor rồi tự bấm Save

---

## Flow tổng thể

```
[Lấy Components]
      ↓
[Hiển thị list components trong popup]
      ↓
[Bấm "Preview bảng Golive"] → popup hiện bảng preview
      ↓
[Bấm "Xác nhận cập nhật"]
      ↓
[Inject script vào trang Confluence Editor đang mở]
      ↓
[Script tìm bảng → xóa rows cũ → điền rows mới vào DOM editor]
      ↓
[User thấy kết quả trực tiếp trên editor → tự bấm Save / Publish]
```

---

## Yêu cầu tiên quyết

- Trang Confluence phải đang mở ở chế độ **Edit**
  (URL dạng: `/wiki/spaces/.../pages/edit-v2/...`)
- Nếu đang ở chế độ View, extension cần điều hướng sang Edit trước

---

## Bước 0 — Kiểm tra và mở Edit mode

Trong `handleUpdateGoliveTable`, kiểm tra URL tab hiện tại:

```jsx
const handleUpdateGoliveTable = async () => {
  setStep("loading");
  setError("");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab.url;

  // Nếu đang ở View mode → chuyển sang Edit mode
  if (!url.includes("/edit-v2/") && !url.includes("/edit/")) {
    // Lấy pageId từ URL view: /wiki/spaces/.../pages/45505380601/...
    const pageIdMatch = url.match(/\/pages\/(\d+)/);
    if (!pageIdMatch) {
      setError("Không tìm thấy Page ID! Hãy mở trang Confluence trước.");
      setStep("preview");
      return;
    }

    const pageId = pageIdMatch[1];
    const spaceMatch = url.match(/\/spaces\/([^/]+)/);
    const space = spaceMatch ? spaceMatch[1] : "";

    // Điều hướng sang edit mode
    const editUrl = `https://citigo.atlassian.net/wiki/spaces/${space}/pages/edit-v2/${pageId}`;
    await chrome.tabs.update(tab.id, { url: editUrl });

    // Chờ trang load xong (3-5s tuỳ tốc độ mạng)
    await new Promise((res) => setTimeout(res, 5000));
  }

  // Lấy lại tab sau khi điều hướng
  const [updatedTab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  });

  // Inject script thao tác DOM
  const results = await chrome.scripting.executeScript({
    target: { tabId: updatedTab.id },
    func: manipulateGoliveTableDOM,
    args: [components],
  });

  const data = results[0].result;

  if (data.error) {
    setError(data.error);
    setStep("preview");
  } else {
    setStep("done");
  }
};
```

---

## Bước 1 — Function `manipulateGoliveTableDOM` (inject vào trang)

> ⚠️ Phải khai báo inline trong `Popup.jsx`, không dùng closure bên ngoài.
> Confluence Cloud dùng editor **ProseMirror** — DOM của editor là `contenteditable`.

```jsx
function manipulateGoliveTableDOM(components) {
  // 1. Tìm heading "Kịch bản Golive" trong editor
  // Editor Confluence nằm trong div có class chứa "ak-editor-content-area"
  // hoặc attribute contenteditable="true"
  const editor =
    document.querySelector(".ak-editor-content-area") ||
    document.querySelector('[contenteditable="true"]');

  if (!editor)
    return { error: "Không tìm thấy editor! Hãy mở trang ở chế độ Edit." };

  // 2. Tìm tất cả các heading/paragraph có text "Kịch bản Golive"
  let targetTable = null;
  const allElements = editor.querySelectorAll("h1, h2, h3, h4, p, span");

  for (const el of allElements) {
    if (el.innerText && el.innerText.trim() === "Kịch bản Golive") {
      // Tìm bảng TABLE gần nhất phía sau
      let next =
        el.closest("p, h1, h2, h3, h4")?.nextElementSibling ||
        el.nextElementSibling;
      let attempts = 0;
      while (next && attempts < 15) {
        if (next.tagName === "TABLE") {
          targetTable = next;
          break;
        }
        const tbl = next.querySelector("table");
        if (tbl) {
          targetTable = tbl;
          break;
        }
        next = next.nextElementSibling;
        attempts++;
      }
      if (targetTable) break;
    }
  }

  if (!targetTable)
    return { error: 'Không tìm thấy bảng "Kịch bản Golive" trong editor!' };

  // 3. Lấy tbody và header row
  const tbody = targetTable.querySelector("tbody") || targetTable;
  const rows = Array.from(tbody.querySelectorAll("tr"));
  if (rows.length === 0) return { error: "Bảng không có rows!" };

  const headerRow = rows[0];

  // 4. Xóa toàn bộ rows cũ (giữ lại header)
  rows.slice(1).forEach((row) => row.remove());

  // 5. Clone cấu trúc row mẫu từ row cũ (nếu còn row data)
  // Hoặc tự tạo mới nếu chỉ còn header
  // Dùng cấu trúc giống hệt các rows cũ của bảng

  components.forEach((comp, index) => {
    // Clone header row để giữ đúng cấu trúc cell của Confluence editor
    const newRow = document.createElement("tr");

    // Cell 1: STT
    const tdNum = document.createElement("td");
    tdNum.innerHTML = `<p>${index + 1}</p>`;

    // Cell 2: Tên component (dạng code block như bảng gốc)
    const tdComp = document.createElement("td");
    tdComp.innerHTML = `<p><code>"${comp}"</code></p>`;

    // Cell 3: Build? (Yes/No checkboxes)
    const tdBuild = document.createElement("td");
    tdBuild.innerHTML = `
      <p><input type="checkbox" /> Yes</p>
      <p><input type="checkbox" /> No</p>
    `;

    // Cell 4: Git branch (trống)
    const tdGit = document.createElement("td");
    tdGit.innerHTML = `<p></p>`;

    // Cell 5: Tag go-live (trống)
    const tdTag = document.createElement("td");
    tdTag.innerHTML = `<p></p>`;

    // Cell 6: Package created? (Yes/No checkboxes)
    const tdPackage = document.createElement("td");
    tdPackage.innerHTML = `
      <p><input type="checkbox" /> Yes</p>
      <p><input type="checkbox" /> No</p>
    `;

    // Cell 7: Thông tin Config/setting/script (trống)
    const tdConfig = document.createElement("td");
    tdConfig.innerHTML = `<p></p>`;

    newRow.appendChild(tdNum);
    newRow.appendChild(tdComp);
    newRow.appendChild(tdBuild);
    newRow.appendChild(tdGit);
    newRow.appendChild(tdTag);
    newRow.appendChild(tdPackage);
    newRow.appendChild(tdConfig);

    tbody.appendChild(newRow);
  });

  // 6. Trigger input event để Confluence editor nhận biết thay đổi
  editor.dispatchEvent(new Event("input", { bubbles: true }));

  return { success: true, count: components.length };
}
```

---

## Bước 2 — UI States & Buttons (giống plan API, chỉ đổi handler)

```jsx
const [step, setStep] = useState("idle");
// "idle" | "got" | "preview" | "loading" | "done"
```

```jsx
{
  /* Sau khi có components */
}
{
  step === "got" && components.length > 0 && (
    <button
      onClick={() => setStep("preview")}
      className="px-3 py-2 bg-green-600 text-white rounded hover:bg-green-700 font-medium"
    >
      👁️ Preview bảng Golive
    </button>
  );
}

{
  /* Ở bước preview */
}
{
  step === "preview" && (
    <div className="flex gap-2">
      <button
        onClick={handleUpdateGoliveTable}
        className="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium"
      >
        ✅ Xác nhận cập nhật
      </button>
      <button
        onClick={() => setStep("got")}
        className="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
      >
        ✏️ Huỷ
      </button>
    </div>
  );
}

{
  /* Done */
}
{
  step === "done" && (
    <div className="text-green-700 bg-green-50 border border-green-200 p-2 rounded">
      ✅ Đã cập nhật bảng trên editor! Nhớ bấm <strong>Publish</strong> để lưu.
    </div>
  );
}
```

---

## Bước 3 — Component `GoliveTablePreview` (preview trong popup)

```jsx
function GoliveTablePreview({ components }) {
  return (
    <div className="mt-3 overflow-x-auto">
      <p className="text-xs text-gray-500 mb-1 italic">
        Preview bảng Kịch bản Golive ({components.length} components):
      </p>
      <table className="w-full text-xs border border-gray-300 border-collapse">
        <thead className="bg-blue-50">
          <tr>
            <th className="border border-gray-300 px-2 py-1 text-center w-6">
              #
            </th>
            <th className="border border-gray-300 px-2 py-1">
              Thành phần golive
            </th>
            <th className="border border-gray-300 px-2 py-1 text-center">
              Build?
            </th>
            <th className="border border-gray-300 px-2 py-1 text-center">
              Git branch
            </th>
            <th className="border border-gray-300 px-2 py-1 text-center">
              Tag go-live
            </th>
            <th className="border border-gray-300 px-2 py-1 text-center">
              Package created?
            </th>
            <th className="border border-gray-300 px-2 py-1 text-center">
              Config/script
            </th>
          </tr>
        </thead>
        <tbody>
          {components.map((comp, i) => (
            <tr key={i} className="hover:bg-gray-50">
              <td className="border border-gray-300 px-2 py-1 text-center text-gray-400">
                {i + 1}
              </td>
              <td className="border border-gray-300 px-2 py-1 font-mono font-semibold text-gray-800">
                "{comp}"
              </td>
              <td className="border border-gray-300 px-2 py-1 text-center text-gray-400 text-[10px]">
                ☐ Yes
                <br />☐ No
              </td>
              <td className="border border-gray-300 px-2 py-1 bg-gray-50"></td>
              <td className="border border-gray-300 px-2 py-1 bg-gray-50"></td>
              <td className="border border-gray-300 px-2 py-1 text-center text-gray-400 text-[10px]">
                ☐ Yes
                <br />☐ No
              </td>
              <td className="border border-gray-300 px-2 py-1 bg-gray-50"></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

---

## Lưu ý quan trọng

| Vấn đề                       | Giải pháp                                                                                   |
| ---------------------------- | ------------------------------------------------------------------------------------------- |
| Editor chưa load xong        | Tăng `setTimeout` lên 5-8s hoặc poll kiểm tra `.ak-editor-content-area`                     |
| DOM thay đổi không được nhận | `dispatchEvent(new Event("input"))` hoặc thử `new InputEvent("input")`                      |
| Confluence dùng ProseMirror  | Nếu DOM manipulation không hoạt động, cần dùng ProseMirror API qua `window.ProseMirror`     |
| Checkbox không render đúng   | Confluence dùng task macro, không phải `<input type="checkbox">` — cần kiểm tra DOM thực tế |
| Trang đang ở View mode       | Extension tự động redirect sang `/edit-v2/{pageId}`                                         |

---

## Checklist implement

- [ ] Thêm state `step` vào `Popup.jsx`
- [ ] Thêm component `GoliveTablePreview`
- [ ] Thêm function `manipulateGoliveTableDOM` (inline, không closure)
- [ ] Thêm handler `handleUpdateGoliveTable` (kiểm tra edit mode → inject)
- [ ] Cập nhật `handleGet` để set `step = "got"`
- [ ] Cập nhật JSX render theo các step
- [ ] Test: mở trang Confluence ở Edit mode → bấm Xác nhận → kiểm tra DOM
- [ ] Tinh chỉnh selector nếu Confluence thay đổi class editor
- [ ] Build và reload extension
