# 06 — Tích hợp Confluence

Mọi tương tác với Confluence (`citigo.atlassian.net`) thực hiện bằng cách **inject hàm vào tab** qua
`chrome.scripting.executeScript({ target: { tabId }, func })`.

File: [`features/create/injected.js`](../src/panel/features/create/injected.js)

> ⚠️ **Quan trọng:** các hàm này chạy trong **context trang web**, được serialize bằng `.toString()` rồi inject.
> Vì vậy chúng **phải self-contained** — không tham chiếu import/biến/closure bên ngoài; mọi thứ cần dùng phải khai báo ngay trong hàm. Đây là lý do `customOrder` được lặp lại bên trong `extractComponents`.

Có 3 hàm inject:

---

## 1. `extractComponents()` — đọc danh sách component

Async (chờ bảng render + cuộn nạp hết dòng).

1. **Tìm bảng**: trong `#AkMainContent`, tìm `<h1>` có text đúng *"Danh sách ticket golive"*, lấy `<table>` ngay sau heading.
2. **Chờ render**: lặp tối đa ~6s tới khi thấy bảng.
3. **Cuộn nạp hết**: tìm scroll container, cuộn xuống đáy lặp lại tới khi số dòng ổn định (infinite loading) — tối đa 20 vòng, dừng khi 2 lần liên tiếp không tăng dòng.
4. **Trích xuất** mỗi dòng (bỏ header):
   - **Cột index 5** (`r.children[5]`) = danh sách Components (tách theo `,` hoặc xuống dòng; bỏ "Components", bỏ mục chứa "Mobile App").
   - **Ticket**: tìm anchor Jira (`browse/`, `selectedIssue`, `atlassian.net`…); summary = text dài nhất trong các ô khác (không phải mã kiểu `ABC-123`).
   - Gom ticket theo từng component, khử trùng lặp.
5. **Sắp xếp** theo `customOrder` (thứ tự ưu tiên các component KiotViet); ngoài danh sách xếp cuối.

Trả về: `{ components: [{ name, tickets: [{ text, href }] }] }` hoặc `{ error }`.

---

## 2. `extractChecklistBelow()` — đọc nhóm giữ nguyên trong Checklist

Bảng Checklist gồm nhiều nhóm "Công cụ". Tool chỉ thay nhóm **Opensearch**, nên cần đọc các dòng **bên dưới** nhóm Opensearch để hiển thị/bảo toàn.

1. Quét mọi `<table>` trong vùng editor (`.ak-editor-content-area` / `[contenteditable]` / `#AkMainContent`).
2. Tìm bảng có dòng cột đầu = "Opensearch".
3. `end` = dòng kế tiếp có cột "Công cụ" khác rỗng (biên nhóm).
4. Trả các dòng từ `end` trở đi: `{ below: [{ tool, comp, result, note }], debug }`.

---

## 2b. `extractGoliveTags()` — đọc tag sẵn có trên bảng Golive

Phục vụ tính năng **Build tag** (auto-select tag theo wiki). Tìm bảng dưới heading **"Kịch bản Golive"** (view mode, trong `#AkMainContent`), đọc từng dòng: cột 0 = component (chuẩn hoá bỏ nháy), cột 3 = **Tag**. Trả `{ tags: { [component]: tag } }`. Dùng để tự chọn tag/`Tag_Version` khớp khi đã tải danh sách (xem [04](04-tinh-nang-build-tag.md)).

---

## 3. `manipulateGoliveTableDOM(components, target)` — ghi vào editor

`target` ∈ `golive | rollback | checklist`. Yêu cầu trang đang ở chế độ **Edit** (có `.ak-editor-content-area` / `[contenteditable]`).

### Markup tạo ra (Confluence/ADF)
- **Ô component**: `<p><code>"Tên"</code></p>`.
- **Yes/No**: task-list 2 mục Yes/No, mục đúng được `data-task-state="DONE"`:
  ```html
  <div data-task-list-local-id="…">
    <div data-task-local-id="…" data-task-state="DONE|TODO">Yes</div>
    <div data-task-local-id="…" data-task-state="DONE|TODO">No</div>
  </div>
  ```
- **Checkbox đơn** (checklist "bình thường"): task-list 1 mục, DONE nếu tick.
- **Text** (branch/tag/config/note): `<p>…</p>`.

### Tìm bảng & điền
`findTable(headingText, headerMatch)` dò heading rồi tìm `<table>` kế tiếp có header khớp:
- **golive** → heading "Kịch bản Golive", header chứa "Thành phần".
- **rollback** → "Kịch bản Rollback", header "Thành phần rollback".
- **checklist** → "Checklist đánh giá hệ thống sau khi golive/rollback", header "Kết quả theo dõi".

Cách điền:
- **golive/rollback** (`fillTable`): xoá các dòng dữ liệu cũ (giữ header), append 1 dòng / component với 6 ô: component, build (Y/N), branch, tag, package (Y/N), config.
- **checklist** (`fillChecklistOpensearch`): tìm nhóm "Opensearch", xoá đúng các dòng của nhóm đó (tới biên nhóm kế tiếp), chèn lại 1 dòng / component (dòng đầu mang nhãn "Opensearch", các dòng sau để trống cột Công cụ) với cột "Kết quả theo dõi" = checkbox "bình thường" + ghi chú; **các nhóm khác giữ nguyên**.

Sau khi ghi: `editor.dispatchEvent(new Event("input", { bubbles: true }))` để Confluence nhận thay đổi. Trả `{ success, target, count }` hoặc `{ error }`.

> Người dùng vẫn phải bấm **Publish** trên Confluence để lưu chính thức.

---

## Điều hướng View → Edit

Trong [`useGolive.js`](../src/panel/useGolive.js) `handleUpdateTable`: nếu URL chưa phải `/edit-v2/` hoặc `/edit/`, tự `chrome.tabs.update` sang `…/wiki/spaces/{space}/pages/edit-v2/{pageId}` rồi chờ ~5s cho editor load, sau đó mới inject hàm ghi.
