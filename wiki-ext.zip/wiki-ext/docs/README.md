# Tài liệu dự án — Wiki Extensions (Golive)

Chrome Extension (side panel) hỗ trợ quy trình **go-live cuối sprint** cho KiotViet Booking:
lấy danh sách component từ Confluence, điền các bảng kế hoạch (Golive / Rollback / Checklist),
và build các tag tương ứng trên Jenkins.

> Đối tượng dùng: **Tester**. Dùng vào cuối sprint khi go-live.

## Mục lục

| # | Tài liệu | Nội dung |
|---|----------|----------|
| 01 | [Tổng quan](01-tong-quan.md) | Extension làm gì, 2 tính năng chính, luồng sử dụng |
| 02 | [Kiến trúc & công nghệ](02-kien-truc.md) | Tech stack, manifest MV3, cấu trúc thư mục, luồng dữ liệu |
| 03 | [Tính năng: Tạo component](03-tinh-nang-tao-component.md) | Lấy component từ Confluence → điền 3 bảng → đẩy lên Confluence |
| 04 | [Tính năng: Build tag](04-tinh-nang-build-tag.md) | Chọn job/tag Jenkins, build qua API, theo dõi trạng thái, retry |
| 05 | [Tham chiếu Jenkins API](05-jenkins-api.md) | Các endpoint, xác thực, quyền host, cách dựng URL job |
| 06 | [Tích hợp Confluence](06-confluence-integration.md) | Các hàm inject vào trang, cách scrape & sửa bảng editor |
| 07 | [Lưu trữ & cấu hình](07-luu-tru-cau-hinh.md) | `chrome.storage` keys, cấu hình Jenkins, mapping component→job/tag |
| 08 | [Phát triển](08-phat-trien.md) | Cài đặt, build, load extension, debug, quy ước code |
| 09 | [Tính năng: Ủng hộ tác giả](09-tinh-nang-xin-tien.md) | Nút ở chân sidebar mở modal donate (ảnh + thông tin chuyển khoản) |

## Tóm tắt nhanh

- **Công nghệ:** React 18 + Vite 4 + `@crxjs/vite-plugin` (Manifest V3). UI dùng CSS tự viết theo design token KiotViet (không dùng Tailwind cho panel).
- **2 tính năng chính** (sidebar trái): **Tạo component** và **Build tag**; ngoài ra có nút **Ủng hộ tác giả** ở chân sidebar mở modal donate.
- **Confluence:** đọc/ghi qua `chrome.scripting.executeScript` (inject hàm vào tab `citigo.atlassian.net`).
- **Jenkins:** gọi REST API trực tiếp bằng `user` + API token (Basic auth), cần quyền host động.
- **Quy ước code:** xem [CLAUDE.md](../CLAUDE.md) — mỗi tính năng/khối trách nhiệm tách file riêng.
