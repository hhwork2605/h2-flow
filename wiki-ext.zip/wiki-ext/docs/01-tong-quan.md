# 01 — Tổng quan

## Extension này là gì?

**Wiki Extensions** là một Chrome Extension hiển thị dưới dạng **Side Panel** (bảng bên phải trình duyệt),
hỗ trợ Tester thực hiện quy trình **go-live** cuối mỗi sprint của KiotViet Booking.

Bấm vào icon extension → side panel mở ra (cấu hình trong [`src/background.js`](../src/background.js)).

## Hai tính năng chính

Sidebar bên trái cho phép chuyển giữa 2 tính năng:

### 1. Tạo component
Toàn bộ luồng làm việc với trang Confluence:
1. **Lấy component**: đọc bảng *"Danh sách ticket golive"* trên trang Confluence của sprint, trích ra danh sách component kèm các ticket Jira liên quan.
2. **Chọn component**: tick các component cần go-live (có tìm kiếm, kéo sắp xếp, xoá, xem ticket).
3. **Điền 3 bảng**: Golive / Rollback / Checklist — nhập build/branch/tag/package/config… cho từng component.
4. **Đẩy lên Confluence**: chèn dữ liệu đã điền vào đúng bảng trong trang Confluence (tự chuyển trang sang chế độ Edit nếu cần).

→ Chi tiết: [03 — Tính năng Tạo component](03-tinh-nang-tao-component.md)

### 2. Build tag
Build các tag đã có trên **Jenkins** cho từng component:
1. Cấu hình Jenkins (URL + user + API token).
2. Mỗi component chọn **job Jenkins** (lấy từ danh sách job thật) và **tag** cần build (tag thật của job, mặc định tag mới nhất).
3. Bấm **Build tag** → tool kiểm tra tag đã build chưa; chưa build thì trigger qua API, theo dõi trạng thái realtime; đã build thì báo kết quả luôn.
4. **Retry** từng tag khi cần build lại.

→ Chi tiết: [04 — Tính năng Build tag](04-tinh-nang-build-tag.md)

## Luồng sử dụng điển hình (cuối sprint)

```
Mở trang Confluence "Golive Plan" của sprint
        │
        ▼
[Tạo component] Lấy Components → Chọn → Điền bảng Golive/Rollback/Checklist → Cập nhật vào Confluence → Publish
        │
        ▼
[Build tag] Chọn job + tag cho từng component → Build tag → theo dõi trạng thái → Retry nếu lỗi
```

## Phạm vi & ràng buộc

- Chỉ hoạt động với Confluence của **`citigo.atlassian.net`** (khai báo trong `host_permissions`).
- Bảng nguồn phải có heading đúng tên *"Danh sách ticket golive"*; component nằm ở **cột thứ 6** của bảng.
- Build tag cần **API token Jenkins** và quyền truy cập host Jenkins (cấp khi lưu cấu hình).
- Dữ liệu cấu hình & lựa chọn lưu cục bộ trong `chrome.storage.local` (không đồng bộ lên server).
