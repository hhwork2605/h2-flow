# 02 — Kiến trúc & công nghệ

## Tech stack

| Thành phần | Phiên bản | Vai trò |
|-----------|-----------|---------|
| React | ^18.2 | UI |
| Vite | ^4.3 | Bundler/dev server |
| @crxjs/vite-plugin | ^2.0.0-beta.23 | Build extension Manifest V3 từ Vite |
| @vitejs/plugin-react | ^4.0 | JSX/Fast-refresh |
| Tailwind + PostCSS + autoprefixer | ^3.3 / ^8.4 | **Có cấu hình nhưng panel KHÔNG dùng** (xem ghi chú) |

> **Ghi chú về CSS:** Panel dùng **CSS tự viết** trong [`src/styles/golive.css`](../src/styles/golive.css) cùng design token trong [`src/styles/colors_and_type.css`](../src/styles/colors_and_type.css) (bảng màu KiotViet `#0070F4`, bo góc, Inter/Roboto Mono…). [`src/index.css`](../src/index.css) chứa directive Tailwind nhưng **không được `main.jsx` import**, nên Tailwind không tác động tới UI panel. Icon dùng **SVG inline** (không phụ thuộc webfont).

## Manifest V3 (Chrome Extension)

File: [`public/manifest.json`](../public/manifest.json)

```jsonc
{
  "manifest_version": 3,
  "name": "Wiki Extensions",
  "permissions": ["activeTab", "scripting", "clipboardWrite", "sidePanel", "storage"],
  "host_permissions": ["https://citigo.atlassian.net/*"],
  "optional_host_permissions": ["*://*/*"],   // xin động cho host Jenkins
  "side_panel": { "default_path": "index.html" },
  "background": { "service_worker": "src/background.js", "type": "module" }
}
```

Giải thích quyền:
- **activeTab + scripting** — inject hàm vào tab Confluence để đọc/ghi bảng.
- **clipboardWrite** — (dự phòng) sao chép.
- **sidePanel** — chạy UI dạng side panel.
- **storage** — lưu cấu hình Jenkins + mapping component→job/tag.
- **host_permissions citigo.atlassian.net** — scripting trên Confluence.
- **optional_host_permissions `*://*/*`** — xin quyền truy cập **host Jenkins** lúc runtime (khi lưu cấu hình), để gọi API cross-origin (xem [05](05-jenkins-api.md)).

[`src/background.js`](../src/background.js): service worker chỉ làm 1 việc — `setPanelBehavior({ openPanelOnActionClick: true })` để bấm icon mở side panel.

## Điểm vào

```
index.html  →  src/panel/main.jsx  →  <GolivePanel />
                       │
                       ├── import styles/colors_and_type.css
                       └── import styles/golive.css
```

## Cấu trúc thư mục `src/panel/`

```
GolivePanel.jsx          # orchestrator: gọi useGolive() + ghép Sidebar/feature/modal/toast
main.jsx                 # mount React vào #root
config.js                # ⚙ CONFIG TẬP TRUNG: poll interval, timeout, BUILD_DISABLED, Jenkins mặc định…
useGolive.js             # HOOK: toàn bộ state + handler (không JSX)
shared/                  # dùng chung nhiều tính năng
  icons.jsx              # tất cả icon SVG
  ui.jsx                 # Check, Tickets, CellControl, BuildChip + BUILD_META
  Sidebar.jsx            # điều hướng 2 tính năng
  Toast.jsx              # thông báo
features/
  create/                # tính năng "Tạo component"
    CreateFeature.jsx    # view (app bar + stepper + step1/step2 + footer)
    tables.jsx           # EditTable, ChecklistEdit (bảng bước 2)
    config.js            # TABS, SCHEMA, BLURB, QUICK, isComplete
    injected.js          # hàm chạy trong tab Confluence (self-contained)
  buildtag/              # tính năng "Build tag"
    BuildTagFeature.jsx  # view
    BuildTag.jsx         # bảng Component·Project·Tag/Tham số·Trạng thái
    ParamForm.jsx        # form nhập tham số (single-select/multi-checkbox/text…)
    JenkinsSettings.jsx  # modal cấu hình Jenkins
    jenkins.js           # logic miền + chrome.storage + Jenkins API (không JSX)
    appname.js           # phát hiện APP_NAME + build kèm submit app (không JSX)
    buildtype.js         # nhận diện loại build (param/app/tag/plain) + đọc tham số (api/json)
    params.js            # fetch trực tiếp form Build-With-Parameters (đọc body kể cả 405) → parse choices
```

Nguyên tắc tách file: xem [CLAUDE.md](../CLAUDE.md). Tóm tắt:
- File dùng chung > 1 tính năng → `shared/`; chỉ phục vụ 1 tính năng → `features/<tên>/`.
- Component **thuần trình bày**, nhận dữ liệu qua props. **State/handler** tập trung ở `useGolive.js`.
- **Logic miền không trộn JSX** (`jenkins.js`, `config.js`, `injected.js` là `.js`).

## Luồng dữ liệu

```
                ┌──────────────── useGolive() (state + handlers) ────────────────┐
                │  components, selected, values, buildStatus, jenkinsCfg, ...     │
                └───────┬───────────────────────────────────────────┬────────────┘
                        │ g (object)                                 │ g (object)
                        ▼                                            ▼
              <CreateFeature g={g}/>                       <BuildTagFeature g={g}/>
                        │                                            │
        chrome.scripting.executeScript               fetch(...) Jenkins REST API
        (inject vào tab Confluence)                  (Basic auth + crumb)
                        │                                            │
            injected.js (page context)                      jenkins.js (panel context)
```

- `GolivePanel` gọi `useGolive()` **đúng 1 lần** → object `g` chứa mọi state/handler.
- Hai feature view nhận `g`, destructure phần cần dùng → không prop-drilling sâu.
- **Confluence**: thao tác qua hàm inject (page context, không có closure ngoài).
- **Jenkins**: gọi `fetch` trực tiếp từ panel (extension page) — có host permission nên không bị CORS.

## Build output

`npm run build` → thư mục `dist/` (manifest, `index.html`, `service-worker-loader.js`, assets). Load `dist/` vào Chrome (`chrome://extensions` → Load unpacked). Xem [08 — Phát triển](08-phat-trien.md).
