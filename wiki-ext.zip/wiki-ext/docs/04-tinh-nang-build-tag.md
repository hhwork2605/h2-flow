# 04 — Tính năng: Build tag

View: [`features/buildtag/BuildTagFeature.jsx`](../src/panel/features/buildtag/BuildTagFeature.jsx)
Bảng: [`features/buildtag/BuildTag.jsx`](../src/panel/features/buildtag/BuildTag.jsx)
Modal cấu hình: [`features/buildtag/JenkinsSettings.jsx`](../src/panel/features/buildtag/JenkinsSettings.jsx)
Logic + API: [`features/buildtag/jenkins.js`](../src/panel/features/buildtag/jenkins.js)
State/handler: [`useGolive.js`](../src/panel/useGolive.js)

Mục tiêu: với mỗi component go-live, **build tag tương ứng trên Jenkins** rồi theo dõi kết quả — gọi REST API trực tiếp, không mở tab.

> Dùng chung `components`/`selected` với tính năng Tạo component (cùng danh sách lấy từ Confluence).

---

## Bảng Build tag

Cột: ☑ · # · **Component** · **Project (job)** · **Tag** · **Trạng thái**.

> **Component chỉ hiển thị** (không thao tác/không build): `Database`, `Booking Core`, `booking mobile core` — hằng `BUILD_DISABLED`/`isBuildDisabled` trong [`jenkins.js`](../src/panel/features/buildtag/jenkins.js). Các dòng này render mờ, không có ô chọn/tag/retry và bị bỏ qua trong `runBuilds`. (Build tay ở nơi khác.)

- **Project (job)**: ô combobox (`<datalist>`) liệt kê **job Jenkins thật** mà token có quyền. Chọn xong **tự lưu** mapping `component → job` vào storage (`projectMap`).

### Nhận diện loại build (khi chọn/lấy job)

Khi một job được chọn (hoặc resolve cho component), tool **tự nhận diện** job đó build theo kiểu nào và hiện **badge** ở cột Project. Thứ tự ưu tiên (`detectBuildType` trong [`buildtype.js`](../src/panel/features/buildtag/buildtype.js)):

| # | Loại | Điều kiện nhận diện | Build bằng |
|---|------|---------------------|-----------|
| 1 | **param** | job có `parameterDefinitions` (Build with Parameters) | `buildWithParameters` (job, không tag) |
| 2 | **app** | pipeline có bước `input` "Choose APP_NAME" | `buildJobWithApp` (`project/tag` + submit app) |
| 3 | **tag** | multibranch có job con (tag/nhánh) | `buildJob` (`project/tag`) |
| 4 | **plain** | còn lại (job thường, không tag/param/app) | `buildJob`-trực-tiếp (`{job}/build`) |

> Ưu tiên param → app → tag → plain. Phát hiện **lazy** (chỉ job đang dùng, không quét toàn bộ ~1600 job), cache trong `jobMeta`.

- **param**: tool đọc danh sách tham số (`fetchJobParams`), hiện **form nhập từng tham số** (mở rộng dưới dòng): choice→dropdown, boolean→checkbox, string/text→ô text, prefill giá trị mặc định. Giá trị lưu vào `paramMap`.
- **app**: ô Project liệt kê thêm các mục **`tên-job/tên-app`** (mỗi app một lựa chọn). Chọn `job/app` = chọn job + app; app lưu vào `appMap`, `projectMap` vẫn chỉ lưu job gốc. App phát hiện qua `lastBuild/replay/` — xem [05](05-jenkins-api.md#app_name-job-pipeline-có-bước-chọn-app).
- **tag/plain**: hoạt động như cũ (chọn tag hoặc build thẳng).
- **Tag**: ô combobox liệt kê **tag thật của đúng project đó** (lấy qua API, version mới nhất xếp đầu, mặc định = tag mới nhất). Lựa chọn giữ trong `tagMap` (chỉ state phiên, không lưu storage).
- **Trạng thái**: chip + (khi success/failed) link tới build log; kèm nút **↻ Retry**.

> **Auto-select theo wiki:** khi lấy components, tool còn đọc bảng **"Kịch bản Golive"** trên trang (`extractGoliveTags`) → map `component → tag`. Sau khi tải tag của project (hoặc choices của tham số dạng `Tag_Version`), nếu tag wiki **có trong** danh sách và component **chưa chọn** → **tự chọn** tag đó; **không có thì để trống** (không ép về tag mới nhất). Người dùng đổi tay vẫn được giữ nguyên.

Tóm tắt phía trên bảng: *"Đã chọn x/n tag · a thành công · b thất bại"*.

---

## Cấu hình Jenkins (⚙)

Modal [`JenkinsSettings.jsx`] gồm: **Jenkins URL · Username · API Token**. Khi Lưu:
1. Validate URL + bắt buộc user/token.
2. **Xin quyền host** Jenkins qua `chrome.permissions.request` (origin lấy từ URL) — dùng `optional_host_permissions`.
3. Lưu vào `chrome.storage.local` key `jenkinsConfig`.
4. Tải lại danh sách job.

Mặc định `baseUrl = https://booking-jenkins-hub.citigo.net`. Token tạo tại *Jenkins → User → Configure → API Token*.

**Tự mở modal cấu hình** trong 2 trường hợp:
- **Vào tab Build tag mà chưa cấu hình** (thiếu URL/user/token) → mở luôn để nhập.
- **Gọi Jenkins API bị 401/403** (sai user/token) khi tải danh sách job → mở lại để nhập đúng. (`fetchJobs` gắn cờ `err.unauthorized`, `refetchJobs` bắt được thì `setShowSettings(true)`.)

Chi tiết các endpoint/xác thực: [05 — Jenkins API](05-jenkins-api.md).

---

## Lấy danh sách job (`fetchJobs`)

Duyệt đệ quy (tối đa 4 cấp) từ gốc Jenkins:
- **Folder / organization folder** → đi sâu vào trong.
- **Multibranch project** → **lấy chính project, KHÔNG đệ quy** vào nhánh/tag con (người dùng chọn tag riêng sau).
- **Job thường** (`buildable`) → lấy.
- **Loại trừ** mọi job/folder chứa `Hotel-Locale` hoặc `Booking-Autotags` (hằng `EXCLUDE_JOBS`).

Trả về danh sách `fullName` (vd `Hotel/MHQL`), sắp xếp alpha. Bấm **⟳** trên app bar để tải lại.

## Lấy tag của project (`fetchProjectTags`)

Với mỗi project đang dùng, GET các job con (tag/nhánh) → trả về tên (vd `2.144.2`, `3.6.1`, `development`…). Sắp xếp: **tag dạng version mới nhất lên đầu**, còn lại theo alpha. Cache trong `tagsByProject`.

> Multibranch của KiotViet đặt tag theo version số (vd `2.144.2`). Build job-tag = `{project}/{tag}` → URL `…/job/Hotel/job/MHQL/job/2.144.2/`.

---

## Trạng thái build

`BUILD_META` trong [`shared/ui.jsx`](../src/panel/shared/ui.jsx):

| status | Nhãn | Ý nghĩa |
|--------|------|---------|
| `idle` | Chưa build | Tag chưa có build nào |
| `queued` | Trong hàng đợi | Đang kiểm tra / vừa trigger |
| `building` | Đang build | Job đang chạy (có spinner) |
| `success` | Thành công | Kết quả SUCCESS |
| `failed` | Thất bại | Kết quả khác SUCCESS / lỗi |

**Khi vào tab Build tag** (đã cấu hình), tool tự lấy trạng thái cho từng dòng → cột Trạng thái phản ánh thực tế **trước cả khi bấm Build**. Dòng nào **đang build sẵn** (status `building`) sẽ được **bám theo** (`pollBuild`) tới khi xong, không kẹt ở "Đang build".

**Phân biệt theo app (quan trọng):** nhiều app dùng *chung* một job `project/tag` (app nộp qua input step, là các build number khác nhau). `lastBuild` không tách được theo app, nên mỗi lần build tool **lưu URL build cụ thể** theo khoá `project|tag|app` (`buildUrlMap`). Khi mở lại / get component lại, trạng thái mỗi app đọc **đúng build number** của app đó (`fetchBuildResult`), không bị lẫn sang app khác. Pre-check "đã build chưa" của app cũng chỉ dựa trên build đã lưu của đúng app (không dùng `lastBuild`).

---

## Build (kiểm tra trước khi build)

Nút **Build tag** (build nhiều project cùng lúc) chỉ **disable khi không component nào được chọn** (`buildCount === 0`) — vẫn bấm được trong khi đang có build chạy để thêm project mới.

Bấm **Build tag** → `runBuilds()`:
0. **Bỏ qua** dòng: chưa tích / chỉ-hiển-thị (`BUILD_DISABLED`) / **đang build** / **đang trong hàng chờ** (`isBuilding` hoặc status `queued`/`building`). Chỉ build các dòng còn lại.
1. Kiểm tra đã cấu hình Jenkins.
2. **Bỏ qua các component chưa chọn project (job)** — tức `projectMap[nm]` rỗng. Chỉ những dòng đã chọn job Jenkins mới được đưa vào danh sách build; số dòng bị bỏ qua được đếm và báo trong toast tổng kết (*"bỏ qua z chưa chọn project"*). Nếu **không có** dòng nào đã chọn project → báo lỗi và không build.
3. Các dòng còn lại phải đã có tag (thiếu thì báo "Thiếu tag").
4. Mỗi component chạy `runOne(nm, force=false)`:
   - **GET trạng thái tag trước** (`fetchTagStatus`).
   - Nếu **đã build** (success/failed) → báo kết quả luôn, **không trigger lại** (`already = true`).
   - Nếu **đang build** → bám theo (`pollBuild`) tới khi xong.
   - Nếu **chưa build** → trigger build theo **loại đã nhận diện**, poll queue → poll build:
     - **param** → `buildWithParameters` với giá trị trong `paramMap[nm]`.
     - **app** → `buildJobWithApp`: trigger → chờ pause ở "Choose APP_NAME" → **tự POST submit app** → poll. Chi tiết: [05](05-jenkins-api.md#submit-app_name-cho-pipeline-đang-pause).
     - **tag** → `buildJob` (`{project/tag}/build`).
     - **plain** → `buildJob` build thẳng `{job}/build`.

> Kiểm tra "đã build chưa" (`fetchTagStatus`) chỉ áp dụng cho **tag/app** (định danh artifact = tag). **param/plain** luôn trigger lại khi bấm build.
5. Toast tổng kết, có đếm *"(z đã build sẵn)"* và *"bỏ qua z chưa chọn project"* (nếu có).

## Retry (build lại)

Nút **↻** trên mỗi dòng đã chọn (status idle/success/failed) → `retryOne(nm)` = `runOne(nm, force=true)`: **build lại bất kể** đã build hay chưa. **Mỗi dòng build độc lập** — chỉ dòng đó bị khoá khi đang chạy (`isBuilding(nm)`), các dòng khác vẫn build/retry được song song. Dòng **chưa chọn project (job)** bị chặn (báo lỗi, không build).

Dùng khi: job lỗi cần chạy lại, hoặc muốn build lại bản mới.

---

## State liên quan (trong `useGolive`)

| State | Ý nghĩa |
|-------|---------|
| `projectMap` | `{ component: jobFullName }` — đã lưu (`projectMap` storage) |
| `appMap` | `{ component: app }` — app đã chọn cho job có APP_NAME (`appMap` storage) |
| `paramMap` | `{ component: { paramName: value } }` — giá trị tham số job param (**chỉ state, không lưu storage**) |
| `tagMap` | `{ component: tag }` — tag đã chọn (**chỉ state, không lưu storage**; tự fill theo wiki/default) |
| `tagsByProject` | `{ project: [tag] }` — cache tag theo project |
| `jobMeta` | `{ jobFullName: { type, params, apps } }` — kết quả nhận diện loại build (lazy) |
| `wikiTags` | `{ component: tag }` — tag đọc từ bảng "Kịch bản Golive" trên wiki (để auto-select) |
| `buildUrlByKey` | `{ "project\|tag\|app": buildUrl }` — URL build cụ thể (phân biệt app/lần build) |
| `jobs` / `jobsLoading` / `jobsError` | danh sách job + trạng thái tải |
| `buildStatus` | `{ component: idle\|queued\|building\|success\|failed }` |
| `buildUrl` | `{ component: URL build trên Jenkins }` |
| `buildingNames` | Set component đang build — **độc lập từng dòng** (`isBuilding(nm)`); `anyBuilding` chỉ khoá nút "Build tag" tổng |
| `jenkinsCfg` | `{ baseUrl, user, token }` |

`resolveProject(nm)` = `projectMap[nm]` → `PROJECT_MAP[nm]` (gợi ý cứng) → `slugify(name)`.
`resolveTag(nm)` = `tagMap[nm]` → tag mới nhất của project.
`resolveApp(nm)` = `appMap[nm]` (rỗng nếu job không có/chưa chọn APP_NAME).

> Ô Project hiển thị gộp: `projectMap[nm]` + (có app thì `/appMap[nm]`). `splitProjectApp(val)` tách ngược chuỗi nhập/chọn thành `{ project, app }` dựa trên `appsByJob` (so khớp `job/app` đã biết).
