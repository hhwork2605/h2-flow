# Tính năng: Ủng hộ tác giả

Mục donate trong panel — một **nút ở chân sidebar** mở **modal** hiển thị ảnh ủng hộ
kèm thông tin chuyển khoản và nút sao chép số tài khoản.
Không gọi Confluence, không gọi Jenkins, không lưu trữ gì.

> Thiết kế lấy từ Claude Design (bundle handoff). Đây là bản hoàn chỉnh của ý tưởng
> "Xin tiền" ban đầu — nay làm dạng popup donate theo style KiotViet.

## Cách hoạt động

- **Tự mở mỗi lần vào extension** — trừ khi user bị loại (xem mục jsonbin bên dưới).
  Khi mount, panel hỏi jsonbin rồi mới bật modal nếu user không nằm trong danh sách loại
  (bật sau khi check để tránh nháy popup với user đã loại). Đóng bằng ✕ / "Để sau" / bấm nền.
- Chân sidebar có nút gradient cam **"Ủng hộ tác giả"** (icon ly cà phê) để mở lại bất cứ lúc nào.
- Modal (`SupportModal.jsx`):
  - Trên cùng: ảnh `support.png` ("+1 đồng, +1 feature").
  - Tiêu đề + đoạn mô tả ngắn.
  - Khối thông tin chuyển khoản: **Chủ tài khoản / Số tài khoản / Ngân hàng**.
  - Hai nút: **Để sau** (đóng) và **Sao chép STK** (copy số tài khoản + toast cảm ơn, rồi đóng).
- Đóng modal bằng nút ✕, nút "Để sau", hoặc bấm ra vùng nền tối.
- Sidebar thu gọn / màn hình hẹp → nút co lại chỉ còn icon.

## Thông tin chuyển khoản

Khai báo tập trung ở [src/panel/features/support/config.js](../src/panel/features/support/config.js)
(`SUPPORT_ACCOUNT`) — cả modal (hiển thị) và `useGolive` (sao chép) dùng chung:

| Trường | Giá trị |
|--------|---------|
| Chủ tài khoản | NGUYEN XUAN HUNG |
| Số tài khoản | 1600581219 |
| Ngân hàng | BIDV — PGD Hồ Tây |

## Hình ảnh

- File ảnh: **`public/support.png`** (crxjs copy ra gốc extension), tham chiếu qua
  `chrome.runtime.getURL("support.png")`.
- Đổi tên/định dạng → sửa `SUPPORT_IMG_FILE` trong `config.js`.

## Tắt popup theo user (jsonbin.io)

Danh sách user **không hiện popup** lưu trên [jsonbin.io](https://jsonbin.io) dưới dạng:

```json
{ "notShowBonusPopup": ["jenkins-user-1", "jenkins-user-2"] }
```

- **Định danh user**: dùng **username Jenkins** trong config (`jenkinsCfg.user`, lưu ở
  `chrome.storage` qua modal ⚙). So khớp không phân biệt hoa/thường.
- **Đọc bin**: `GET https://api.jsonbin.io/v3/b/{BIN_ID}/latest` với header
  `X-Access-Key` (read-only). Khai báo `BIN_ID` + `accessKey` trong
  [src/panel/features/support/bonus.js](../src/panel/features/support/bonus.js) (`BONUS_BIN`).
- **Mặc định an toàn**: chưa cấu hình bin, lỗi mạng, hoặc chưa cấu hình Jenkins (user rỗng)
  → **vẫn hiện** popup.
- Cần host permission `https://api.jsonbin.io/*` (đã khai báo trong `public/manifest.json`).

## Liên quan code

| File | Vai trò |
|------|---------|
| `src/panel/features/support/SupportModal.jsx` | Modal donate (trình bày) |
| `src/panel/features/support/config.js` | Thông tin tài khoản + tên file ảnh |
| `src/panel/features/support/bonus.js` | Đọc jsonbin + kiểm tra user có bị loại popup |
| `src/panel/useGolive.js` | State `showSupport` + handler `copyAccount` + effect gating jsonbin |
| `public/manifest.json` | Host permission `https://api.jsonbin.io/*` |
| `src/panel/shared/Sidebar.jsx` | Nút "Ủng hộ tác giả" ở chân sidebar (`onSupport`) |
| `src/panel/GolivePanel.jsx` | Render `SupportModal` khi `showSupport` |
| `src/panel/shared/icons.jsx` | Icon `SvgMug`, `SvgCopy` |
| `public/support.png` | Ảnh hiển thị trong modal |
