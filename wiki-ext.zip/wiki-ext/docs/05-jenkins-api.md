# 05 — Tham chiếu Jenkins API

Toàn bộ ở [`features/buildtag/jenkins.js`](../src/panel/features/buildtag/jenkins.js). Gọi `fetch` **trực tiếp từ panel** (extension page).

## Xác thực

- **Basic auth**: header `Authorization: Basic base64("<user>:<apiToken>")` (`authHeader`).
- **CSRF crumb** (best-effort): GET `/crumbIssuer/api/json` → nếu có, thêm header `<crumbRequestField>: <crumb>` cho request POST. Jenkins có thể tắt crumb → bỏ qua nếu lỗi.
- `credentials: "omit"` — không gửi cookie, chỉ dùng token.

## Quyền host & CORS

- Host Jenkins **không** cố định trong manifest → khai báo `optional_host_permissions: ["*://*/*"]`.
- Khi lưu cấu hình, `requestJenkinsPermission(baseUrl)` gọi `chrome.permissions.request({ origins: ["<origin>/*"] })` (cần user-gesture = bấm Lưu).
- Khi đã có host permission, **extension page bỏ qua CORS** cho host đó → đọc được cả response header (vd `Location`).

## Dựng URL job

```js
jobApiUrl(cfg, "Hotel/MHQL")
// → https://.../job/Hotel/job/MHQL      (mỗi segment encodeURIComponent, nối bằng /job/)

tagJobUrl(cfg, "Hotel/MHQL", "2.144.2")
// → https://.../job/Hotel/job/MHQL/job/2.144.2   (tag là 1 segment, encode riêng)
```

> Tag chứa dấu `/` (vd nhánh `release/20260327`) vẫn đúng vì tag được `encodeURIComponent` thành **một** segment (`release%2F20260327`).

## Các endpoint sử dụng

| Mục đích | Method | Endpoint | Ghi chú |
|----------|--------|----------|---------|
| Lấy CSRF crumb | GET | `/crumbIssuer/api/json` | best-effort |
| Liệt kê job (đệ quy) | GET | `{folder}/api/json?tree=jobs[name,fullName,url,buildable,_class]` | `fetchJobs` |
| Liệt kê tag của project | GET | `{project}/api/json?tree=jobs[name]` | `fetchProjectTags` |
| Trạng thái build gần nhất | GET | `{tagJob}/lastBuild/api/json?tree=building,result,number,url` | `fetchTagStatus`; 404 = chưa build |
| Trigger build | POST | `{tagJob}/build` | `buildJob`; kỳ vọng 201 + header `Location` (queue) |
| Đọc tham số job | GET | `{job}/api/json?tree=property[parameterDefinitions[name,type,_class,choiceType,value,choices,defaultParameterValue[value]]],jobs[name]` | `fetchJobParams`; `jobs[]` có con = multibranch |
| Build with parameters | POST | `{job}/buildWithParameters` | `buildWithParameters`; body `application/x-www-form-urlencoded` các `PARAM=value` |
| Poll hàng đợi | GET | `{queueUrl}/api/json` | đợi `executable.url` (URL build thật) |
| Poll kết quả build | GET | `{buildUrl}/api/json?tree=building,result` | tới khi `!building && result` |

## Các hàm chính

```js
fetchJobs(cfg) -> string[]                       // fullName các job (lọc multibranch/folder/exclude)
fetchProjectTags(cfg, project) -> string[]       // tên tag/nhánh, version mới nhất trước
fetchTagStatus(cfg, project, tag) -> { status, url?, number? }
                                                 // status: idle | building | success | failed
buildJob(cfg, project, tag, onPhase) -> { result, buildUrl }
                                                 // trigger + poll queue + poll build
pollBuild(cfg, buildUrl) -> { result }           // poll 1 build đang chạy tới khi xong
```

### Quy trình `buildJob`
1. (Tuỳ chọn) lấy crumb.
2. `POST {tagJob}/build` → đọc header `Location` = queue item URL.
3. Poll queue (`/api/json`) tới khi có `executable.url` → đó là URL build → gọi `onPhase("building", url)`.
4. `pollBuild` URL đó tới khi `result` xuất hiện (`SUCCESS` / `FAILURE` / …).
5. Trả `{ result, buildUrl }`. Map `SUCCESS` → success, còn lại → failed.

> **Không "fake success":** `triggerBuild` đọc số `lastBuild` TRƯỚC khi POST; nếu POST không trả `Location` (hay gặp ở `buildWithParameters` do redirect) → **dò `lastBuild` tới khi number khác lúc trước** (build mới) rồi poll build đó. Không tìm được build mới → **ném lỗi** (không báo thành công khống).

## Lọc job (`fetchJobs`)

```
multibranch project        → lấy chính nó, KHÔNG đệ quy (tránh kéo tag/nhánh con)
organization folder/folder → đi sâu vào trong
job buildable thường       → lấy
tên chứa Hotel-Locale | Booking-Autotags → BỎ
```
Loại trừ chỉnh ở hằng `EXCLUDE_JOBS` (regex) trong `jenkins.js`.

## Nhận diện loại build & tham số

Logic ở [`features/buildtag/buildtype.js`](../src/panel/features/buildtag/buildtype.js). `detectBuildType(cfg, job)` trả `{ type, params, apps }` theo ưu tiên:

1. **param** — `fetchJobParams` (api/json, tree `parameterDefinitions[name,type,_class,choiceType,value,choices,defaultParameterValue[value]]`) thấy `parameterDefinitions`. Phân loại `kind`: `Boolean`→boolean; `choiceType` PT_CHECKBOX/PT_MULTI_SELECT (Extended Choice/Active Choices)→`multiselect`; `Choice`/PT_*→`choice`; Password/Text tương ứng; còn lại `string`.
   - **Choices** theo thứ tự: `choices` (param chuẩn) → `value` (Extended Choice = chuỗi tất cả lựa chọn) → suy từ `default` (multiselect). Nếu vẫn thiếu (Active Choices như `Tag_Version`, Git… không lộ danh sách qua **bất kỳ API** nào, và GET `/build` là **POST-only → 405**) → **fetch trực tiếp** trang form `{job}/build?delay=0sec` (header `Authorization: Basic <token>`) rồi `DOMParser` parse radio/checkbox/select theo từng `input[name="name"]` ([`params.js`](../src/panel/features/buildtag/params.js) `fetchParamForm`). **KHÔNG mở tab, KHÔNG cần cookie.**

   > Mấu chốt: GET `/build` trả **HTTP 405** (POST-only) **nhưng body vẫn chứa nguyên form** (Active Choices render radio sẵn). Vì vậy cứ đọc `res.text()` **bất kể status** rồi parse — không cần `res.ok`.

   **Chỉ chạy khi người dùng mở form tham số** (`loadParamChoices` trong `useGolive`). Không parse được → ô **gõ/sửa tay** prefill bằng `default`.
   - **Mặc định:** `defaultParameterValue.value` (vd `Run_Steps`=`Build,Upload` → tick sẵn cả hai).
   - **Bảng phân loại `kind`** (theo class/type Jenkins):

   | Class / type | kind | UI | Giá trị gửi |
   |---|---|---|---|
   | StringParameterDefinition | string | input 1 dòng | string |
   | TextParameterDefinition · PT_TEXTBOX | text | textarea | string |
   | BooleanParameterDefinition | boolean | checkbox | `true`/`false` |
   | PasswordParameterDefinition | password | input masked | string |
   | ChoiceParameterDefinition · ChoiceParameter · CascadeChoiceParameter · DynamicReferenceParameter · GitParameterDefinition · RunParameterDefinition · PT_SINGLE_SELECT · PT_RADIO | choice | radio+lọc (có list) / input (không list) | string |
   | PT_MULTI_SELECT · PT_CHECKBOX | multiselect | nhiều checkbox | chuỗi nối phẩy |
   | PT_HIDDEN | hidden | không render | gửi default |
   | FileParameterDefinition | file | báo "chưa hỗ trợ" | (bỏ qua) |
2. **app** — `fetchJobAppNames` (replay) thấy bước APP_NAME → kèm danh sách app.
3. **tag** — job có con (multibranch) nhưng không param/app.
4. **plain** — còn lại (job thường, build thẳng).

`buildWithParameters(cfg, job, values, onPhase)`: POST `{job}/buildWithParameters` với body `PARAM=value` (URLSearchParams); nếu không có tham số nào thì fallback `{job}/build`. Poll queue → build như `buildJob`.

> `multiselect` gửi **lặp key** `Run_Steps=Build&Run_Steps=BuildProduction&Run_Steps=Deploy` (đúng cách Jenkins nhận checkbox group); `boolean` gửi `"true"/"false"`.

## APP_NAME (job pipeline có bước chọn app)

Logic ở [`features/buildtag/appname.js`](../src/panel/features/buildtag/appname.js). Một số job multibranch có `input` step "Choose APP_NAME" — pause chờ chọn app rồi mới deploy. Danh sách app do Active Choices Groovy script trong Jenkinsfile sinh ra (`return["app-a","app-b",...]`).

### Phát hiện job có chọn APP_NAME

| Mục đích | Method | Endpoint | Ghi chú |
|----------|--------|----------|---------|
| Đọc Jenkinsfile (replay) | GET | `{job}/lastBuild/replay/` | trả HTML chứa nguyên script pipeline |

`fetchJobAppNames(cfg, job)`:
1. **Tìm base có lastBuild để đọc replay** (`replayBaseOf`): pipeline + Jenkinsfile nằm ở **job con (tag/nhánh)** chứ không ở project multibranch gốc → GET `{job}/api/json?tree=jobs[name,lastBuild[number]]`, lấy 1 con **đã có build**. Nếu job là pipeline thường (không có con) → dùng chính nó. Multibranch mà chưa con nào build → `[]`.
2. GET `{base}/lastBuild/replay/` → decode HTML entities (`&quot;`→`"`, `&#39;`→`'`).
3. Có APP_NAME khi chứa **cả** `input message` lẫn `APP_NAME`. Không có → `[]`.
4. Lấy danh sách: cắt nội dung trong `return[ … ]` rồi tách theo dấu phẩy, bỏ nháy (chấp nhận **cả nháy đơn lẫn nháy kép** — Groovy hay dùng nháy đơn nên không dùng `JSON.parse`).

> Quét 1–2 request/job nên **chỉ gọi lazy** cho các job đang dùng (kết quả cache trong `appsByJob`), KHÔNG quét toàn bộ Jenkins.

### Submit APP_NAME cho pipeline đang pause

| Mục đích | Method | Endpoint | Ghi chú |
|----------|--------|----------|---------|
| Đọc input đang chờ | GET | `{buildUrl}/wfapi/nextPendingInputAction` | 404/null khi build chưa pause; trả `{ id, proceedUrl, inputs[], ... }` (hoặc mảng) khi đang chờ |
| Submit app (cách 1) | POST | `{base}{proceedUrl}` (vd `…/wfapi/inputSubmit?inputId=<id>`) | body `json={"parameter":[{"name":"APP_NAME","value":"<app>"}]}`, `Content-Type: application/x-www-form-urlencoded`, kèm crumb |
| Submit app (cách 2, fallback) | POST | `{buildUrl}/input/{id}/submit` | body `proceed=<proceedText>&json=…` (dùng khi cách 1 lỗi) |

`buildJobWithApp(cfg, project, tag, app, onPhase)`:
1. Trigger + poll queue như `buildJob` → có `buildUrl`, gọi `onPhase("building", buildUrl)`.
2. Lặp: GET `nextPendingInputAction`. Nếu build kết thúc trước khi tới input (không có bước app trên nhánh đó) → trả kết quả luôn.
3. Khi có input đang chờ → `submitInput` POST `app` vào tham số (tên lấy từ `inputs[0].name`, mặc định `APP_NAME`). **Thử lần lượt cách 1 rồi cách 2**, cách nào trả OK/302 thì dừng; cả hai lỗi mới ném lỗi.
4. `pollBuild` tới khi xong → `{ result, buildUrl }`.

> Endpoint/định dạng submit của Jenkins thay đổi theo version (`wfapi/inputSubmit` vs `input/<id>/submit`) nên `submitInput` tự thử cả hai. **Vẫn nên build thử 1 lần thật** để xác nhận chạy đúng với Jenkins của KiotViet (vd format tham số của Active Choices `PT_CHECKBOX`).

## Lỗi thường gặp

| Hiện tượng | Nguyên nhân |
|-----------|-------------|
| 401/403 khi tải job | Sai user/token hoặc không có quyền |
| 404 khi build | Job-tag `{project}/{tag}` không tồn tại (tag sai tên, hoặc chọn nhầm project không phải multibranch) |
| Không gọi được API (CORS/blocked) | Chưa cấp quyền host Jenkins → mở ⚙ lưu lại để xin quyền |
| Crumb 403 | Crumb hết hạn/tắt — thường vẫn build được nhờ token; thử lại |
