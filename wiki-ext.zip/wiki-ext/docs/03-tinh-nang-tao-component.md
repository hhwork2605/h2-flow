# 03 — Tính năng: Tạo component

View: [`features/create/CreateFeature.jsx`](../src/panel/features/create/CreateFeature.jsx)
Logic/state: [`useGolive.js`](../src/panel/useGolive.js)
Bảng bước 2: [`features/create/tables.jsx`](../src/panel/features/create/tables.jsx)
Cấu hình bảng: [`features/create/config.js`](../src/panel/features/create/config.js)
Hàm inject: [`features/create/injected.js`](../src/panel/features/create/injected.js)

Luồng 2 bước: **① Chọn components → ② Điền bảng**.

---

## Lấy components từ Confluence

Khi panel mở (hoặc bấm "Lấy Components"), `handleGet()`:
1. Lấy tab đang active, kiểm tra URL có thuộc `https://citigo.atlassian.net/` không.
2. `chrome.scripting.executeScript` inject hàm `extractComponents` vào tab.
3. Hàm này tìm bảng dưới heading **"Danh sách ticket golive"**, cuộn để nạp hết dòng (infinite-loading), rồi trích **cột thứ 6** (index 5) làm tên component + gom ticket Jira liên quan.
4. Trả về `{ components: [{ name, tickets: [{text, href}] }] }`, sắp xếp theo `customOrder`.

Chi tiết hàm scrape: [06 — Tích hợp Confluence](06-confluence-integration.md).

> **Nút ⟳ trên app bar** (`reloadCreate`): làm mới toàn bộ — **xoá dữ liệu đã điền** (golive/rollback/checklist) + ô tìm kiếm rồi gọi `handleGet()` (đặt lại components/selected/step/expanded). Khác nút ↻ ở footer (chỉ `handleGet`, giữ dữ liệu đã điền).

### Cơ chế retry
Bảng Jira render chậm → nếu chưa thấy component, tự thử lại **tối đa 5 lần, mỗi 5 giây** (`MAX_RETRY`, `RETRY_MS`). Hiển thị "Thử lại lần x/5".

### Theo dõi tab
Effect lắng nghe `chrome.tabs.onActivated` / `onUpdated`:
- Đổi sang trang Confluence khác (khác `pageId`) → tự lấy lại component.
- Rời khỏi Confluence → báo nhắc mở lại đúng tab.
- Cập nhật chip **View/Edit** theo URL (`/edit-v2/` hoặc `/edit/` ⇒ Edit).

---

## Bước 1 — Chọn components

UI bảng (list) gồm các cột: chọn-tất-cả · # · Component · Ticket · xoá. Tính năng:
- **Tìm kiếm** lọc theo tên (`query`).
- **Chọn / bỏ chọn** từng dòng hoặc tất cả (`selected` là map `{ [name]: true }`).
- **Kéo–thả** sắp xếp lại thứ tự component (`dragIndex`/`overIndex`).
- **Xoá** component khỏi danh sách (`handleRemove`).
- **Bung ticket**: bấm pill "n ticket" để xem danh sách ticket (link Jira mở tab mới).

Bấm **Tiếp tục — điền bảng** chuyển bước 2 (`goStep2`).

---

## Bước 2 — Điền 3 bảng

3 tab: **Golive / Rollback / Checklist** (`TABS` trong `config.js`). Mỗi bảng có schema cột riêng (`SCHEMA`):

| Bảng | Cột (field) | Kiểu |
|------|-------------|------|
| **golive** | Build?, Git branch, Tag go-live, Package created?, Config/script | yn, text, text, yn, text |
| **rollback** | Build?, Git branch, Tag rollback, Package created?, Config/script | yn, text, text, yn, text |
| **checklist** | Kết quả theo dõi ("bình thường"), Ghi chú | chk, text |

Kiểu field:
- `yn` — nút **Yes/No** (giá trị `true`/`false`/`null`).
- `chk` — 1 checkbox (vd "bình thường" = `true`).
- `text` — ô nhập (một số là mono: branch/tag).

Tiện ích:
- **Thanh tiến độ**: đếm số component đã điền đủ (`isComplete`) / tổng đã chọn.
- **Điền nhanh** (`QUICK`): vd Golive "Điền nhanh branch & tag mặc định", Checklist "Đánh dấu tất cả bình thường".
- **Áp dụng cho tất cả** (`applyToAll`): với ô text, áp giá trị vừa nhập cho mọi component đang chọn.
- Giá trị lưu trong state `values = { golive: {}, rollback: {}, checklist: {} }` theo từng component.

### Checklist đặc biệt
Bảng Checklist trên Confluence có nhiều nhóm công cụ; tool **chỉ thay nhóm "Opensearch"**, giữ nguyên các nhóm khác. Trước khi điền, `extractChecklistBelow` đọc các dòng nằm **dưới** nhóm Opensearch để hiển thị (read-only) và bảo toàn khi ghi.

---

## Đẩy lên Confluence

`handleUpdateTable(target)` với `target` ∈ `golive | rollback | checklist`:
1. Nếu trang đang ở chế độ **View** → tự điều hướng tab sang URL `…/pages/edit-v2/{pageId}` và chờ ~5s cho editor load.
2. Ghép dữ liệu đã nhập thành `rows` (mỗi component 1 dòng).
3. Inject `manipulateGoliveTableDOM(rows, target)` vào editor để chèn/ghi đè đúng bảng:
   - **golive** → bảng dưới heading "Kịch bản Golive".
   - **rollback** → bảng "Kịch bản Rollback".
   - **checklist** → thay nhóm Opensearch trong bảng "Checklist đánh giá hệ thống sau khi golive/rollback".
4. Hiển thị toast: *"Đã cập nhật … · trang đã chuyển sang Edit. Nhớ bấm Publish."*

> Tool chỉ điền vào **editor**; người dùng phải tự bấm **Publish** trên Confluence để lưu.

Chi tiết markup chèn (task-list `DONE/TODO`…): [06 — Tích hợp Confluence](06-confluence-integration.md).
