# 07 — Lưu trữ & cấu hình

Mọi dữ liệu cấu hình/lựa chọn lưu **cục bộ** trong `chrome.storage.local` (không đồng bộ, không gửi server).
Helper đọc/ghi nằm trong [`features/buildtag/jenkins.js`](../src/panel/features/buildtag/jenkins.js).

> **Tham số tinh chỉnh (build-time)** — KHÁC với storage — gom ở **[`src/panel/config.js`](../src/panel/config.js)**: chu kỳ/timeout poll build (`POLL`), độ sâu + loại trừ khi quét job (`JOBS`), Jenkins mặc định (`DEFAULT_JENKINS_CFG`), số build quét khi dò "đã build" của param/app (`PARAM_MATCH_MAX`, `APP_MATCH_MAX`), component chỉ-hiển-thị (`BUILD_DISABLED`), retry lấy component & thời gian toast (`FETCH`, `TOAST_MS`). Sửa số ở đây rồi build lại; không lưu vào storage.

## Các key trong `chrome.storage.local`

| Key | Kiểu | Nội dung | Helper |
|-----|------|----------|--------|
| `jenkinsConfig` | `{ baseUrl, user, token, folders }` | Cấu hình Jenkins (URL + tài khoản + API token + folder quét job) | `loadJenkinsCfg` / `saveJenkinsCfg` |
| `projectMap` | `{ [componentName]: jobFullName }` | Component nào ứng với job Jenkins nào | `loadProjectMap` / `saveProjectMap` |

> **`appMap`, `tagMap` và `paramMap` KHÔNG lưu storage** — chỉ giữ trong state phiên panel. Mỗi lần vào sẽ trống rồi **tự điền/chọn lại**: tag/`Tag_Version` auto-select theo bảng golive trên wiki + giá trị mặc định của tham số; app chọn lại theo job. Lý do: tag/version/app đổi theo mỗi lần go-live nên không nên nhớ giá trị cũ.

Các state khác (component lấy từ Confluence, giá trị bảng golive/rollback/checklist, trạng thái build…) **không lưu** — chỉ tồn tại trong phiên panel.

## `jenkinsConfig`

```js
DEFAULT_JENKINS_CFG = {
  baseUrl: "https://booking-jenkins-hub.citigo.net",
  user: "",
  token: "",
  folders: [], // folder được chọn để quét job (rỗng = quét tất cả job có quyền)
}
```

- `isCfgReady(cfg)` = có đủ `baseUrl && user && token`.
- Lưu qua modal ⚙ (xem [04](04-tinh-nang-build-tag.md)); khi lưu sẽ xin quyền host Jenkins.
- **`folders`**: mảng fullName các folder đã chọn để giới hạn phạm vi quét job. Trong modal ⚙ là **multi-select có filter** (`FolderMultiSelect`); danh sách folder (`fetchFolders`) **tự tải khi nhập/đổi Username·Token**, chọn folder → hiện thành chip → lưu. `fetchJobs` chỉ quét trong các folder này (đỡ tải toàn bộ ~1600 job). **Rỗng = quét từ gốc như cũ** (tương thích ngược; cấu hình cũ chưa có `folders` mặc định rỗng).
- **Bảo mật:** API token lưu plaintext trong storage cục bộ của trình duyệt. Coi như thông tin nhạy cảm — không chia sẻ máy/profile; thu hồi token trên Jenkins nếu lộ.

## `projectMap` — mapping component → job

- Khi chọn job ở cột "Project (job)", lưu ngay (`handleProjectChange`).
- Thứ tự ưu tiên khi build (`resolveProject`): `projectMap[name]` → `PROJECT_MAP[name]` (gợi ý cứng trong `jenkins.js`) → `slugify(name)`.
- `PROJECT_MAP` chỉ là **gợi ý mặc định** (tên repo kiểu `kv-…`); người dùng nên chọn job thật từ danh sách để đúng path Jenkins (vd `Hotel/MHQL`).

## `appMap` — mapping component → app (APP_NAME) — *chỉ state phiên, không lưu storage*

- Chỉ dùng cho job có bước "Choose APP_NAME". Khi chọn mục `job/app` ở cột "Project (job)", `handleProjectInput` dùng `splitProjectApp` tách app ra rồi đặt vào `appMap` (state phiên; job gốc lưu vào `projectMap`).
- **Không persist** — mỗi lần mở panel chọn lại app (giống `tagMap`/`paramMap`).
- Đổi project (job gốc) sẽ **xoá tag cũ**; chọn job không có app thì `appMap` của component đó được xoá.
- `resolveApp(name)` = `appMap[name]` (rỗng nếu không có app). Khi build, dòng có app dùng `buildJobWithApp` để tự submit app.

## `tagMap` / `paramMap` — chỉ trong state, KHÔNG lưu storage

- `tagMap` (component → tag) và `paramMap` (component → `{ paramName: value }`) **không** ghi vào `chrome.storage`; chỉ tồn tại trong phiên panel.
- Mỗi lần vào Build tag → trống → **tự điền**: auto-select tag/`Tag_Version` theo bảng golive trên wiki (xem [04](04-tinh-nang-build-tag.md)) + giá trị mặc định của tham số. Đổi project sẽ xoá tag/param cũ của component đó.
- `resolveTag(name)` = `tagMap[name]` → tag mới nhất của project (`tagsByProject[project][0]`).

## Xoá / reset cấu hình

Chưa có nút reset trong UI. Khi cần xoá thủ công, mở DevTools của side panel (xem [08](08-phat-trien.md)) và chạy:

```js
chrome.storage.local.remove(["jenkinsConfig", "projectMap"]);
// hoặc xoá tất cả:
chrome.storage.local.clear();
```

Xem nội dung đang lưu:

```js
chrome.storage.local.get(null, console.log);
```
