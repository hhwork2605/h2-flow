# 08 — Phát triển

## Yêu cầu
- Node.js (khuyến nghị ≥ 18) + npm.
- Google Chrome (hoặc Chromium) hỗ trợ Manifest V3 + Side Panel.

## Cài đặt & build

```bash
npm install        # cài dependencies
npm run build      # build production → thư mục dist/
npm run dev        # (tuỳ chọn) Vite dev server — xem ghi chú bên dưới
```

> Với extension, luồng chuẩn là **`npm run build` → load `dist/`**. `npm run dev` chủ yếu phục vụ phát triển nhanh; tính năng đụng `chrome.*` (scripting, sidePanel, storage…) chỉ chạy đúng khi đã load như extension.

## Load extension vào Chrome

1. `npm run build`.
2. Mở `chrome://extensions/`.
3. Bật **Developer mode** (góc trên phải).
4. **Load unpacked** → chọn thư mục **`dist/`**.
5. Sau mỗi lần `npm run build`, bấm **Reload** (⟳) trên thẻ extension để cập nhật.
6. Bấm icon extension → side panel mở ra.

## Debug

- **Side panel UI**: chuột phải trong panel → *Inspect* để mở DevTools riêng cho panel (xem console, chạy `chrome.storage.local.get(null, console.log)`…).
- **Service worker** (`background.js`): tại `chrome://extensions/` → thẻ extension → *Inspect views: service worker*.
- **Hàm inject vào Confluence**: log của `extractComponents` / `manipulateGoliveTableDOM` xuất hiện ở **DevTools của tab Confluence** (không phải panel).
- **Gọi Jenkins API**: kiểm tra tab Network của DevTools panel; lỗi quyền host → mở ⚙ lưu lại để xin permission.

## Quy ước code (bắt buộc)

Xem đầy đủ trong [CLAUDE.md](../CLAUDE.md). Tóm tắt:

- **Mỗi tính năng / khối trách nhiệm 1 file**; trần ~300 dòng. Vượt thì tách nhỏ.
- **Tổ chức thư mục**: dùng chung → `src/panel/shared/`; riêng 1 tính năng → `src/panel/features/<tên>/`.
- **Component thuần trình bày**, nhận props; **state/handler gom ở `useGolive.js`** (truyền object `g` xuống).
- **Logic miền không trộn JSX**: để ở file `.js` (`jenkins.js`, `config.js`, `injected.js`).
- **Hàm trong `injected.js` phải self-contained** (không import/closure ngoài) — sẽ bị `.toString()` rồi inject vào trang.
- Thêm tính năng mới = tạo `features/<tên>/` (view + logic riêng) rồi gắn vào `GolivePanel.jsx` + `useGolive.js`; **không sửa chèn** vào tính năng khác.

## Thêm một tính năng mới (ví dụ)

1. Tạo `src/panel/features/<ten>/`:
   - `<Ten>Feature.jsx` (view, nhận `g`).
   - file logic `.js` nếu cần (gọi API / xử lý dữ liệu).
2. Khai báo state/handler trong [`useGolive.js`](../src/panel/useGolive.js), thêm vào object trả về.
3. Thêm mục nav trong [`shared/Sidebar.jsx`](../src/panel/shared/Sidebar.jsx) + nhánh render trong [`GolivePanel.jsx`](../src/panel/GolivePanel.jsx).
4. Thêm CSS (nếu cần) vào [`src/styles/golive.css`](../src/styles/golive.css) theo token có sẵn.
5. `npm run build` và kiểm tra không lỗi.

## Sửa các giá trị cấu hình thường gặp

| Muốn đổi | Sửa ở |
|----------|-------|
| URL Jenkins mặc định | `DEFAULT_JENKINS_CFG.baseUrl` trong [`features/buildtag/jenkins.js`](../src/panel/features/buildtag/jenkins.js) |
| Danh sách job bị loại trừ | `EXCLUDE_JOBS` (regex) trong `jenkins.js` |
| Gợi ý mapping component→repo | `PROJECT_MAP` trong `jenkins.js` |
| Thứ tự / cột các bảng golive… | `config.js` (`TABS`, `SCHEMA`, `QUICK`) |
| Thứ tự ưu tiên component khi scrape | `customOrder` trong [`features/create/injected.js`](../src/panel/features/create/injected.js) |
| Số lần / nhịp retry khi lấy component | `MAX_RETRY`, `RETRY_MS` trong [`useGolive.js`](../src/panel/useGolive.js) |

## Lưu ý vận hành

- Token Jenkins lưu cục bộ (xem [07](07-luu-tru-cau-hinh.md)). Không commit token vào repo.
- Bảng Confluence phụ thuộc cấu trúc DOM/heading; nếu Atlassian đổi giao diện, các hàm trong `injected.js` có thể cần cập nhật selector.
