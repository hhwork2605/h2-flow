# Golive Components Chrome Extension

## Mô tả

Chrome Extension dùng React + Vite + Tailwind CSS để lấy danh sách components từ bảng "Danh sách ticket golive" trên Confluence (citigo.atlassian.net).

---

## Yêu cầu implement

Tạo đầy đủ các file sau với nội dung chính xác như bên dưới. KHÔNG thay đổi logic, KHÔNG bỏ bớt code.

---

## Cấu trúc thư mục

```
my-extension/
├── public/
│   └── manifest.json
├── src/
│   ├── popup/
│   │   ├── Popup.jsx
│   │   └── main.jsx
│   └── index.css
├── popup.html
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── package.json
```

---

## File: `package.json`

```json
{
  "name": "my-extension",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@crxjs/vite-plugin": "^2.0.0-beta.23",
    "@vitejs/plugin-react": "^4.0.0",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.24",
    "tailwindcss": "^3.3.2",
    "vite": "^4.3.9"
  }
}
```

---

## File: `public/manifest.json`

```json
{
  "manifest_version": 3,
  "name": "Golive Components",
  "version": "1.0.0",
  "description": "Lấy danh sách components từ bảng Danh sách ticket golive",
  "permissions": ["activeTab", "scripting", "clipboardWrite"],
  "host_permissions": ["https://citigo.atlassian.net/*"],
  "action": {
    "default_popup": "popup.html",
    "default_title": "Golive Components"
  }
}
```

---

## File: `vite.config.js`

```js
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { crx } from "@crxjs/vite-plugin";
import manifest from "./public/manifest.json";

export default defineConfig({
  plugins: [react(), crx({ manifest })],
  build: {
    rollupOptions: {
      input: {
        popup: "popup.html",
      },
    },
  },
});
```

---

## File: `tailwind.config.js`

```js
export default {
  content: ["./src/**/*.{js,jsx}", "./popup.html"],
  theme: { extend: {} },
  plugins: [],
};
```

---

## File: `postcss.config.js`

```js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
```

---

## File: `popup.html`

```html
<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <title>Golive Components</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/popup/main.jsx"></script>
  </body>
</html>
```

---

## File: `src/index.css`

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

---

## File: `src/popup/main.jsx`

```jsx
import React from "react";
import { createRoot } from "react-dom/client";
import Popup from "./Popup";
import "../index.css";

createRoot(document.getElementById("root")).render(<Popup />);
```

---

## File: `src/popup/Popup.jsx`

```jsx
import React, { useState } from "react";

const customOrder = [
  "Feature Management",
  "Database",
  "MHQL",
  "Mobile Api",
  "Booking Authorization",
  "Booking Auth Mobile",
  "Audit Trail Api",
  "Audit Trail",
  "Report Api",
  "Promotion Api",
  "LoyaltySmsService",
  "Loyalty Api",
  "KatScanChangedDataService",
  "TaxDeclarationExportService",
  "Booking Partner Api",
  "Booking Inventory Api",
  "Booking Identity Api",
  "Whats App Api",
  "Booking Integration Service",
  "Booking Integration API",
  "EInvoice-Api",
  "Analytic API",
  "Sync Event Api",
  "Command Worker",
  "Booking Schedule Web",
  "Booking Schedule Service",
  "Booking Process",
  "Zalo Service",
  "Booking Clear Data Service",
  "Whats App Service",
  "Online Booking Api",
  "Notification Service",
  "Mqtt Broker",
  "Mqtt Bridge",
  "Mqtt Auth",
  "Sms Service",
  "Update CRM",
  "Redis Multi Cache Service",
  "Tracking Service",
  "Import/Export",
  "AutoCustomerService",
  "MHQL_V2",
  "MHBH",
  "MHBH_V2",
  "Sale online",
  "Cpanel",
  "AdministrativeAreaService",
  "Booking Cpanel Core",
  "Booking Core",
  "booking mobile core",
  "Kat Integration Api",
  "TaxDeclarationExportService",
  "KatScanChangedDataService",
];

// Hàm này được inject thẳng vào trang web, KHÔNG dùng import/export bên trong
function extractComponents() {
  function onlyUnique(value, index, self) {
    return self.indexOf(value) === index && value;
  }

  const customOrder = [
    "Feature Management",
    "Database",
    "MHQL",
    "Mobile Api",
    "Booking Authorization",
    "Booking Auth Mobile",
    "Audit Trail Api",
    "Audit Trail",
    "Report Api",
    "Promotion Api",
    "LoyaltySmsService",
    "Loyalty Api",
    "KatScanChangedDataService",
    "TaxDeclarationExportService",
    "Booking Partner Api",
    "Booking Inventory Api",
    "Booking Identity Api",
    "Whats App Api",
    "Booking Integration Service",
    "Booking Integration API",
    "EInvoice-Api",
    "Analytic API",
    "Sync Event Api",
    "Command Worker",
    "Booking Schedule Web",
    "Booking Schedule Service",
    "Booking Process",
    "Zalo Service",
    "Booking Clear Data Service",
    "Whats App Service",
    "Online Booking Api",
    "Notification Service",
    "Mqtt Broker",
    "Mqtt Bridge",
    "Mqtt Auth",
    "Sms Service",
    "Update CRM",
    "Redis Multi Cache Service",
    "Tracking Service",
    "Import/Export",
    "AutoCustomerService",
    "MHQL_V2",
    "MHBH",
    "MHBH_V2",
    "Sale online",
    "Cpanel",
    "AdministrativeAreaService",
    "Booking Cpanel Core",
    "Booking Core",
    "booking mobile core",
    "Kat Integration Api",
    "TaxDeclarationExportService",
    "KatScanChangedDataService",
  ];

  const mainContent = document.querySelector("#AkMainContent") || document.body;
  let targetTable = null;

  mainContent.querySelectorAll("h1").forEach((h) => {
    if (h.innerText.trim() === "Danh sách ticket golive") {
      let next = h.nextElementSibling;
      let attempts = 0;
      while (next && attempts < 10) {
        if (next.tagName === "TABLE") {
          targetTable = next;
          return;
        }
        const tbl = next.querySelector("table");
        if (tbl) {
          targetTable = tbl;
          return;
        }
        next = next.nextElementSibling;
        attempts++;
      }
    }
  });

  if (!targetTable)
    return { error: 'Không tìm thấy bảng "Danh sách ticket golive"!' };

  let rs2 = "";
  targetTable.querySelectorAll("tr").forEach((r, i) => {
    if (i === 0) return;
    if (r.children[5]) rs2 += r.children[5].innerText + ",";
  });

  const components = rs2
    .split(/[,\n]/)
    .map((c) => c.trim())
    .filter(onlyUnique)
    .filter((c) => c && c !== "Components" && !c.includes("Mobile App"))
    .sort((a, b) => {
      const ia = customOrder.indexOf(a);
      const ib = customOrder.indexOf(b);
      return (ia === -1 ? 9999 : ia) - (ib === -1 ? 9999 : ib);
    });

  return { components };
}

export default function Popup() {
  const [components, setComponents] = useState([]);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleGet = async () => {
    setLoading(true);
    setError("");
    setCopied(false);
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractComponents,
    });
    const data = results[0].result;
    setLoading(false);
    if (data.error) {
      setError(data.error);
      setComponents([]);
    } else {
      setComponents(data.components);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(components.join("\n"));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-[400px] p-4 font-sans text-sm bg-white">
      <h2 className="text-base font-bold text-blue-700 mb-3">
        🚀 Golive Components
      </h2>

      <div className="flex gap-2 mb-3">
        <button
          onClick={handleGet}
          disabled={loading}
          className="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 font-medium transition-colors"
        >
          {loading ? "⏳ Đang lấy..." : "🔍 Lấy Components"}
        </button>
        {components.length > 0 && (
          <button
            onClick={handleCopy}
            className="px-3 py-2 bg-gray-100 text-gray-700 border border-gray-300 rounded hover:bg-gray-200 transition-colors"
          >
            {copied ? "✅ Đã copy!" : "📋 Copy"}
          </button>
        )}
      </div>

      {error && (
        <div className="text-red-600 bg-red-50 border border-red-200 p-2 rounded mb-3">
          ❌ {error}
        </div>
      )}

      {components.length > 0 && (
        <>
          <p className="text-gray-500 mb-2">
            Tìm thấy{" "}
            <strong className="text-gray-800">{components.length}</strong>{" "}
            components{" "}
            <span className="text-xs text-green-600">(🟢 có sẵn)</span>{" "}
            <span className="text-xs text-yellow-600">(🟡 mới)</span>
          </p>
          <ul className="border border-gray-200 rounded max-h-[400px] overflow-y-auto divide-y divide-gray-100">
            {components.map((comp, i) => {
              const inOrder = customOrder.includes(comp);
              return (
                <li
                  key={i}
                  className={`flex items-center gap-2 px-3 py-1.5 ${
                    inOrder
                      ? "bg-green-50 hover:bg-green-100"
                      : "bg-yellow-50 hover:bg-yellow-100"
                  } transition-colors`}
                >
                  <span className="text-gray-400 text-xs w-5 shrink-0">
                    {i + 1}
                  </span>
                  <span className="flex-1">{comp}</span>
                  {!inOrder && (
                    <span className="text-[10px] bg-orange-400 text-white px-1.5 py-0.5 rounded-full shrink-0">
                      new
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
}
```

---

## Lệnh chạy sau khi tạo xong file

```bash
# 1. Cài packages
npm install

# 2. Build extension
npm run build

# 3. Mở Chrome → chrome://extensions/
# 4. Bật Developer mode
# 5. Nhấn "Load unpacked" → chọn thư mục dist/
```

---

## Lưu ý quan trọng

- Hàm `extractComponents` phải được khai báo **đầy đủ inline** trong `Popup.jsx` (kể cả `customOrder` bên trong), vì Chrome inject hàm này dưới dạng string vào trang web, không dùng được closure từ bên ngoài.
- Sau mỗi lần sửa code: chạy lại `npm run build` → vào `chrome://extensions/` → nhấn nút reload extension.
- Nếu muốn dùng cho domain khác ngoài `citigo.atlassian.net`, đổi `host_permissions` thành `"<all_urls>"` trong `manifest.json`.
