# Tài liệu API Jenkins — Phát hiện job có "Choose APP_NAME" và lấy danh sách APP_NAME

## Bối cảnh

- Base URL: https://booking-jenkins-hub.citigo.net
- Xác thực: dùng session cookie của trình duyệt (fetch credentials:'include'),
  hoặc Basic Auth user:API_TOKEN khi gọi từ server/curl. KHÔNG hardcode credential.
- Một số job là Pipeline (multibranch) có một `input` step tên APP_NAME. Pipeline chạy
  tới stage "Choose APP_NAME" thì PAUSE chờ người dùng chọn app rồi mới deploy.
  Danh sách app do một Active Choices Groovy script trong Jenkinsfile sinh ra
  (dạng: return["app-a","app-b",...]).
- Các job KHÔNG có input này thì không có APP_NAME.

==================================================================

## PHẦN A — Lấy tất cả job buildable (để biết cần quét những job nào)

==================================================================

GET /api/json?tree=jobs[name,url,buildable,jobs[name,url,buildable,jobs[name,url,buildable,jobs[name,url,buildable,jobs[name,url,buildable,jobs[name,url,buildable]]]]]]

- Folder cũng là "job" nhưng buildable=false. Duyệt đệ quy, chỉ lấy node buildable===true.
- Có thể giới hạn theo folder bằng cách thêm path, ví dụ:
  GET /job/Hotel/api/json?tree=jobs[name,url,buildable,jobs[name,url,buildable,...]]
- Nên quét theo từng folder (Hotel, Salon-v2, ...) vì tổng số job rất lớn (1600+).

==================================================================

## PHẦN B — Kiểm tra một job CÓ phần chọn APP_NAME hay không

==================================================================

### Cách chính (đáng tin nhất): đọc Jenkinsfile qua endpoint replay

GET /job/.../<jobPath>/lastBuild/replay/

- Trả về HTML có chứa nguyên script pipeline (Jenkinsfile).
- Job CÓ chọn app khi script chứa CẢ hai: chuỗi "input message" VÀ chuỗi "APP_NAME".
- Lưu ý decode HTML entities trước khi tìm: &quot; -> " , &#39; -> '
- Nếu lastBuild/replay/ trả lỗi (job chưa từng build, hoặc không phải pipeline có replay),
  job đó coi như không có input dạng này.

### Cách phụ (nhanh, nhưng phụ thuộc build cuối): kiểm tra stage view

GET /job/.../<jobPath>/lastBuild/wfapi/describe (Accept: application/json)

- Trả về { stages: [{ name, status, pauseDurationMillis }, ...] }.
- Job CÓ chọn app nếu tồn tại stage có name khớp /APP_NAME|Choose App/i.
- Hạn chế: nếu build cuối fail TRƯỚC khi tới stage đó, stage sẽ không xuất hiện ->
  có thể bỏ sót. Vì vậy ưu tiên Cách chính (replay), dùng Cách phụ để lọc nhanh.

==================================================================

## PHẦN C — Lấy danh sách APP_NAME khả dụng của một job

==================================================================

GET /job/.../<jobPath>/lastBuild/replay/

- Trong HTML trả về, tìm đoạn Groovy: return[ "app-1", "app-2", ... ]
- Cắt từ "return[" tới dấu "]" gần nhất, JSON.parse để ra mảng tên app.
- Nhớ decode &quot; -> " và &#39; -> ' trước khi parse.

Lưu ý: đây là Active Choices (PT_CHECKBOX) — về lý thuyết danh sách do script tạo nên có
thể đổi theo điều kiện/thời điểm. replay cho ra danh sách như script đã commit (đủ dùng).
Nếu cần danh sách CHÍNH XÁC tại runtime, đọc khi build đang PAUSE chờ input:
GET /job/.../<jobPath>/<BUILD_NUMBER>/wfapi/nextPendingInputAction
(endpoint này trả 404 nếu build không đang chờ input).

==================================================================

## VÍ DỤ CODE (JavaScript, fetch, dùng cookie session)

==================================================================

const BASE = ''; // dùng đường dẫn tương đối khi chạy trên domain Jenkins

// B. job có chọn app?
async function hasAppChoice(jobPath) {
const r = await fetch(`${jobPath}lastBuild/replay/`, { credentials: 'include' });
if (!r.ok) return false;
const t = (await r.text()).replace(/&quot;/g, '"').replace(/&#39;/g, "'");
return /input\s+message/.test(t) && t.includes('APP_NAME');
}

// C. lấy danh sách app của job
async function getAppNames(jobPath) {
const r = await fetch(`${jobPath}lastBuild/replay/`, { credentials: 'include' });
if (!r.ok) return [];
const t = (await r.text()).replace(/&quot;/g, '"').replace(/&#39;/g, "'");
const i = t.indexOf('return[');
if (i < 0) return [];
try { return JSON.parse(t.substring(i + 6, t.indexOf(']', i) + 1)); }
catch { return []; }
}

// A+B. quét 1 folder, trả về các job có chọn app (kèm danh sách app)
async function scanFolder(folderPath = '') {
const tree = 'jobs[url,buildable,jobs[url,buildable,jobs[url,buildable,jobs[url,buildable,jobs[url,buildable]]]]]';
const data = await fetch(`${folderPath}/api/json?tree=${tree}`,
{ credentials: 'include', headers: { Accept: 'application/json' } }).then(r => r.json());
const jobs = [];
(function walk(js){ if(!js) return; for(const j of js){ if(j.buildable===true) jobs.push(j.url.replace(location.origin,'')); if(j.jobs) walk(j.jobs);} })(data.jobs);

const results = [];
for (let k = 0; k < jobs.length; k += 8) { // 8 request song song mỗi đợt
const batch = jobs.slice(k, k + 8);
const checked = await Promise.all(batch.map(async p => {
const r = await fetch(`${p}lastBuild/replay/`, { credentials: 'include' }).catch(() => null);
if (!r || !r.ok) return null;
const t = (await r.text()).replace(/&quot;/g, '"').replace(/&#39;/g, "'");
if (!(/input\s+message/.test(t) && t.includes('APP_NAME'))) return null;
const i = t.indexOf('return[');
let apps = [];
if (i >= 0) { try { apps = JSON.parse(t.substring(i + 6, t.indexOf(']', i) + 1)); } catch {} }
return { job: p, apps };
}));
results.push(...checked.filter(Boolean));
}
return results; // [{ job: '/job/.../', apps: ['app-a', ...] }, ...]
}

// Ví dụ: scanFolder('/job/Hotel').then(list => console.log(list.length, list));

==================================================================

## LƯU Ý KHI DÙNG

==================================================================

- Quét toàn bộ 1600+ job rất nặng (mỗi job 1 request replay). Nên quét theo từng folder
  và điều chỉnh số request song song (mặc định 8/đợt).
- Job freestyle hoặc job chưa từng build sẽ không có lastBuild/replay/ -> tự bị bỏ qua.
- Mọi thao tác trên CHỈ ĐỌC (GET), không trigger build. Việc trigger build + submit app là
  bước riêng (POST, cần CSRF crumb từ /crumbIssuer/api/json).
