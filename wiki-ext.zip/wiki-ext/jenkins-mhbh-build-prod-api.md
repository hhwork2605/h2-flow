# Tài liệu: Jenkins API cho job MHBH-Build-Prod

## 1. Thông tin chung

**Base URL của job:**
```
https://booking-jenkins-hub.citigo.net/job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod
```

Job thuộc loại Pipeline (`WorkflowJob`) và yêu cầu 2 build parameters.

## 2. Danh sách Parameters

| Name | Type | Plugin | Default |
|------|------|--------|---------|
| `Tag_Version` | `ChoiceParameter` | Active Choices (org.biouno.unochoice) | `2.9.0` |
| `Run_Steps` | `PT_CHECKBOX` | Extended Choice Parameter | `Build,Upload` |

Trong đó `Tag_Version` là single-choice (chọn 1 version), còn `Run_Steps` là multi-select checkbox (chọn `Build`, `Upload` hoặc cả hai, ngăn cách bằng dấu phẩy).

## 3. Authentication

Mọi request cần dùng **username + API token** (không dùng password). Tạo token tại:
```
Jenkins → đăng nhập → góc phải tên user → Configure → API Token → Add new Token
```
Cú pháp xác thực HTTP Basic: `--user "username:api_token"`.

## 4. Các Endpoint chính

### 4.1 Lấy định nghĩa parameters
```
GET /job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/api/json?tree=property[parameterDefinitions[name,type,defaultParameterValue[value]]]
```
Trả về JSON chứa tên, type và giá trị mặc định của mỗi parameter.

### 4.2 Lấy toàn bộ thông tin job
```
GET /job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/api/json
```
Thêm `?pretty=true` để JSON dễ đọc, hoặc dùng `.../api/xml` và `.../api/python` cho định dạng khác.

### 4.3 Lấy thông tin một build cụ thể
```
GET /job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/{buildNumber}/api/json
```
Dùng `lastBuild`, `lastSuccessfulBuild`, hoặc `lastFailedBuild` thay cho `{buildNumber}` để lấy build mới nhất tương ứng.

### 4.4 Lấy crumb (CSRF protection)
```
GET /crumbIssuer/api/json
```
Jenkins thường bật CSRF, nên các request POST cần kèm header crumb.

### 4.5 Trigger build với parameters
```
POST /job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/buildWithParameters?Tag_Version=<version>&Run_Steps=<steps>
```

## 5. Ví dụ cụ thể

### Lấy parameters (curl)
```bash
curl -s --user "username:api_token" \
  "https://booking-jenkins-hub.citigo.net/job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/api/json?tree=property[parameterDefinitions[name,type,defaultParameterValue[value]]]"
```

### Trigger build (curl, kèm crumb)
```bash
# 1) Lấy crumb
CRUMB=$(curl -s --user "username:api_token" \
  "https://booking-jenkins-hub.citigo.net/crumbIssuer/api/json" | jq -r .crumb)

# 2) Trigger build
curl -X POST --user "username:api_token" \
  -H "Jenkins-Crumb: $CRUMB" \
  "https://booking-jenkins-hub.citigo.net/job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod/buildWithParameters?Tag_Version=2.9.0&Run_Steps=Build,Upload"
```

### Ví dụ Python (requests)
```python
import requests
from requests.auth import HTTPBasicAuth

BASE = "https://booking-jenkins-hub.citigo.net/job/Hotel/job/Hotel-MHBH/job/MHBH-Build-Prod"
auth = HTTPBasicAuth("username", "api_token")

# Lấy crumb
crumb = requests.get(
    "https://booking-jenkins-hub.citigo.net/crumbIssuer/api/json", auth=auth
).json()
headers = {crumb["crumbRequestField"]: crumb["crumb"]}

# Trigger build
resp = requests.post(
    f"{BASE}/buildWithParameters",
    params={"Tag_Version": "2.9.0", "Run_Steps": "Build,Upload"},
    headers=headers,
    auth=auth,
)
print(resp.status_code)  # 201 = đã đưa vào hàng đợi build
```

## 6. Lưu ý

Build trigger thành công sẽ trả HTTP `201 Created` kèm header `Location` trỏ tới item trong queue. Với `Run_Steps`, truyền nhiều giá trị dạng `Build,Upload` (phân tách bằng dấu phẩy) đúng như format của Extended Choice Parameter. Phần `username:api_token` cần tự điền.
